// 工具箱文档 http://doc.zjh336.cn/#/integrate/hz_autojs_tools_box

// autojs文档 http://tool.zjh336.cn/docs/v8/app.html

toastLog("这是一个空白项目");