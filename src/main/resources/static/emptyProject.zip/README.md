# 这是一个空项目

项目与资源文件，请参考

http://tool.zjh336.cn/docs/guide/using-project.html



项目配置文件，请参考

http://tool.zjh336.cn/docs/guide/project.html



完整项目配置文件，请参考

https://gitee.com/zjh336/hz_autojs_toolbox/raw/master/project.json



开发文档，请参考

http://tool.zjh336.cn/docs/v8/app.html



工具箱文档，请参考

http://doc.zjh336.cn/#/integrate/hz_autojs_tools_box