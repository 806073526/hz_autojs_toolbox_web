console.show();

var i = {
    name: "小明",
    age: 18,
    height: 1.72
};

console.log("大家好, 我叫%s, 今年%d岁, 身高%d米", i.name, i.age, i.height);
console.log("实际上我是一个对象啦，长这样子: %j", i);