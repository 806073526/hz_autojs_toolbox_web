var name = rawInput("请输入名字");
alert("(•́へ•́╬)", "你好~ " + name);