var handsome = confirm("你帅吗？");
if (handsome) {
    toast("真不要脸！");
    toast("真不要脸！");
    toast("真不要脸！");
    alert("真不要脸！");
} else {
    toast("嗯");
}