var path = $files.path("./被运行的脚本文件.js");
engines.execScriptFile(path);