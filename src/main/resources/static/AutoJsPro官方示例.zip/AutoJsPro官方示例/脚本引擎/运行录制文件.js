var path = files.path("./test.auto");
engines.execAutoFile(path);