while (true) {
    toast("Test");
    sleep(5000);
}