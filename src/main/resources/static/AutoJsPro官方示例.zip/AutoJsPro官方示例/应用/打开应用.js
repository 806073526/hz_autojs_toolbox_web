var appName = rawInput("请输入应用名称");
launchApp(appName);