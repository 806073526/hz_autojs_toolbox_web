
while (true) {
    toastLog("代码运行中");
    sleep(2000);
}
