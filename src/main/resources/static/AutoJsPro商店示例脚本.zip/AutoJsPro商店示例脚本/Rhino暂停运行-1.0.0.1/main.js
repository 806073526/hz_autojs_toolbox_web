"ui";

$ui.layout( 
    <vertical h="*" gravity="center|center_horizontal|center_vertical">
        <card gravity="center|center_horizontal|center_vertical" margin="20" cardCornerRadius="8dp" cardElevation="5dp" >
            <vertical padding="20 10" gravity="center|center_horizontal|center_vertical">
                <linear>
                    <text textSize="16sp">运行结果: </text>
                    <input id="runResult" inputType="text" singleLine="true" gravity="center"  w="*" h="60" textSize="18sp" />
                </linear>
                <linear gravity="center" >
                    <button id="startBtn" w="100dp" >运 行</button>
                    <button id="stopBtn" w="100dp" >结 束</button>
                </linear>
                
            </vertical>
        </card>
    </vertical>
);

const CONTROL = require('./modules/processControl');

let startBtn = $ui.startBtn;
let stopBtn = $ui.stopBtn;
let runResult = $ui.runResult;


startBtn.click( () => { 
    let startBtnText = startBtn.getText().toString();
    //代码少时,可以用if else,代码多时,用switch case
    if ( startBtnText == "运 行" ) {
        CONTROL.RunScript( mainFunc );
        startBtn.setText( "暂 停" );
    }
    if ( startBtnText == "暂 停" ) {
        CONTROL.Pause();
        startBtn.setText( "继 续" );
    }
    if ( startBtnText == "继 续" ) {
        CONTROL.Pause();
        startBtn.setText( "暂 停" );
    }
} );
stopBtn.click( () => {
    CONTROL.SetPauseState( false );
    CONTROL.Stop();
    startBtn.setText( "运 行" );
    runResult.setText( "已结束" );
} );

/**
 * 假设这是脚本函数
 */
function mainFunc() {
    let i = 0;
    while ( true ) {
        i++;
        runResult.setText( i.toString() );
        sleep( 200 );
    }
}
