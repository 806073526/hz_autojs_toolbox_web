"ui";
var shape = require("./Drawable.js");
ui.layout(
    <LinearLayout layout_width="match_parent" layout_height="match_parent" orientation="vertical">
        <toolbar layout_width="match_parent" background="?attr/colorPrimaryDark" title="UI样式2.0" />
        <ScrollView w="*" h="*" >
            <LinearLayout layout_width="match_parent" layout_height="match_parent" orientation="vertical" padding="10">
                <text id="tip" gravity="center" w="*" h="auto" text="不再嵌套控件的UI样式，让布局层级更简洁" textSize="18" paddingTop="5" paddingBottom="5" />

                <View w="*" h="2" id="line0" marginTop="10" />

                <text id="new1" gravity="center" w="auto" h="auto" text="新增部分位置圆角及添加一条虚线" textColor="#6200ee" textSize="15" paddingTop="5" paddingBottom="5" />

                <LinearLayout w="*" h="auto" paddingTop="10" paddingBottom="15">
                    <text w="auto" textColor="#FFFFFF" text="Hello,Auto" id="n1" padding="5" />
                    <text w="auto" textColor="#6200ee" text="Hello,Auto" id="n2" padding="5" marginLeft="20" />
                    <text w="auto" textColor="#FFFFFF" text="Hello,Auto" id="n3" padding="5" marginLeft="20" />
                </LinearLayout>
                <LinearLayout w="*" h="auto" paddingBottom="15">
                    <text w="auto" textColor="#6200ee" text="Hello,Auto" id="n4" padding="5" />
                    <text w="auto" textColor="#FFFFFF" text="Hello,Auto" id="n5" padding="5" marginLeft="20" />
                    <text w="auto" textColor="#6200ee" text="Hello,Auto" id="n6" padding="5" marginLeft="20" />
                </LinearLayout>

                <LinearLayout w="*" h="40" id="nll1" >
                    <text w="0" layout_weight="1" gravity="center" textColor="#FFFFFF" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#FFFFFF" text="Auto" h="*" background="?android:selectableItemBackground" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#FFFFFF" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>
                <LinearLayout w="*" h="40" id="nll2" marginTop="10">
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackground" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>
                <LinearLayout w="*" h="40" id="nll3" marginTop="10">
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackground" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>
                <View w="*" h="2" id="line" marginTop="10" />
                <View w="*" h="5" id="line2" marginTop="10" />

                <LinearLayout w="*" h="auto" paddingTop="15" paddingBottom="15">
                    <text w="auto" textColor="#FFFFFF" text="Hello,Auto" id="t1" padding="5" />
                    <text w="auto" textColor="#FFFFFF" text="Hello,Auto" id="t2" padding="5" marginLeft="20" />
                    <text w="auto" textColor="#FFFFFF" text="Hello,Auto" id="t3" padding="5" marginLeft="20" />
                </LinearLayout>
                <LinearLayout w="*" h="auto" paddingTop="10" paddingBottom="15">
                    <text w="auto" textColor="#FFFFFF" text="上下渐变" id="t4" padding="5" />
                    <text w="auto" textColor="#FFFFFF" text="左右渐变" id="t5" padding="5" marginLeft="20" />
                    <text w="auto" textColor="#FFFFFF" text="左下右上" id="t6" padding="5" marginLeft="20" />
                    <text w="auto" textColor="#FFFFFF" text="左上右下" id="t7" padding="5" marginLeft="20" />
                </LinearLayout>
                <LinearLayout w="*" h="auto" paddingTop="10" paddingBottom="15">
                    <text w="auto" textColor="#6200ee" text="Hello,Auto" id="t8" padding="5" />
                    <text w="auto" textColor="#6200ee" text="Hello,Auto" id="t9" paddingTop="5" paddingBottom="5" paddingLeft="10" paddingRight="10" marginLeft="20" />
                    <text w="auto" textColor="#6200ee" text="Hello,Auto" id="tt9" paddingTop="5" paddingBottom="5" paddingLeft="10" paddingRight="10" marginLeft="20" />
                </LinearLayout>

                <LinearLayout w="*" h="40" id="ll1" marginTop="10" >
                    <text w="0" layout_weight="1" gravity="center" textColor="#FFFFFF" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#FFFFFF" text="Auto" h="*" background="?android:selectableItemBackground" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#FFFFFF" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>

                <LinearLayout w="*" h="40" id="ll2" marginTop="15">
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackground" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>
                <LinearLayout w="*" h="40" id="ll" marginTop="15">
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackground" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>
                <LinearLayout w="*" h="40" id="ll3" marginTop="15">
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" layout_weight="1" gravity="center" textColor="#6200ee" text="Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>

                <LinearLayout w="*" h="40" id="ll4" marginTop="15">
                    <text w="0" id="t10" layout_weight="1" gravity="center" textColor="#6200ee" text="Hello,Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" id="t11" layout_weight="1" gravity="center" textColor="#6200ee" text="Hello,Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" id="t12" layout_weight="1" gravity="center" textColor="#6200ee" text="Hello,Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>

                <LinearLayout w="*" h="40" id="ll5" marginTop="15">
                    <text w="0" id="t13" layout_weight="1" gravity="center" textColor="#6200ee" text="Hello,Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" id="t14" layout_weight="1" gravity="center" textColor="#6200ee" text="Hello,Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                    <text w="0" id="t15" layout_weight="1" gravity="center" textColor="#6200ee" text="Hello,Auto" h="*" background="?android:selectableItemBackgroundBorderless" clickable="true" />
                </LinearLayout>

                <TextView layout_margin="10" id="text" text="hello,123456789" textColor="#ef4e4f" layout_height="wrap_content" layout_width="wrap_content" padding="5" />
            </LinearLayout>
        </ScrollView>
    </LinearLayout>
);

shape.withGradientDrawable(activity)
    .setColor("#6200ee")
    .setCornerRadii([10, 10, 10, 10, 0, 0, 0, 0])
    .into(ui.n1);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setCornerRadii([0, 0, 0, 0, 10, 10, 10, 10])
    .into(ui.n2);

shape.withGradientDrawable(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setOrientation("left_right")
    .setCornerRadii([15, 15, 0, 0, 15, 15, 0, 0])
    .into(ui.n3);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setCornerRadii([0, 0, 15, 15, 15, 15, 0, 0])
    .into(ui.n4);

shape.withGradientDrawable(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setOrientation("left_right")
    .setCornerRadii([0, 0, 15, 15, 0, 0, 15, 15])
    .intos([ui.n5, ui.nll1]);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setStrokeDashWidth(4)
    .setStrokeDashGap(2)
    .setCornerRadii([15, 15, 0, 0, 15, 15, 0, 0])
    .intos([ui.n6, ui.nll2]);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setCornerRadii([0, 0, 20, 20, 20, 20, 0, 0])
    .into(ui.nll3);

shape.withLine(activity)
    .setStrokeColor("#6200ee")
    .setStrokeDashWidth(3)
    .setStrokeDashGap(5)
    .intos([ui.line, ui.line0]);

shape.withLine(activity)
    .setStrokeColor("#ef4e4f")
    .setStrokeDashWidth(10)
    .setStrokeDashGap(6)
    .into(ui.line2);

shape.withGradientDrawable(activity)
    .setColor("#6200ee")
    .into(ui.t1);

shape.withGradientDrawable(activity)
    .setColor("#6200ee")
    .setCornerRadius(5)
    .into(ui.t2);

shape.withGradientDrawable(activity)
    .setColor("#6200ee")
    .setCornerRadius(40)
    .into(ui.t3);


shape.withGradientDrawable(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .into(ui.t4);

shape.withGradientDrawable(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setOrientation("left_right")
    .setCornerRadius(40)
    .into(ui.t5);


shape.withGradientDrawable(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setOrientation("bl_tr")
    .setCornerRadius(5)
    .into(ui.t6);

shape.withGradientDrawable(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setOrientation("tl_br")
    .setCornerRadius(5)
    .into(ui.t7);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .into(ui.t8);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setCornerRadius(50)
    .into(ui.t9);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setCornerRadius(50)
    .setStrokeDashWidth(4)
    .setStrokeDashGap(2)
    .into(ui.tt9);

shape.withGradientDrawable(activity)
    .setCornerRadius(50)
    .setOrientation("left_right")
    .setColors(["#6200ee", "#ef4e4f"])
    .into(ui.ll1);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .into(ui.ll2);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setStrokeDashWidth(4)
    .setStrokeDashGap(2)
    .into(ui.ll);

shape.withGradientDrawable(activity)
    .setStrokeColor("#6200ee")
    .setStrokeWidth(2)
    .setCornerRadius(30)
    .into(ui.ll3);

shape.withLinearGradient(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setStrokeWidth(2)
    .setOrientation("right_left")
    .into(ui.ll4);

shape.withLinearGradient(activity)
    .setColors(["#6200ee", "#ef4e4f"])
    .setStrokeWidth(2)
    .setCornerRadius(30)
    .setOrientation("tl_br")
    .into(ui.ll5);

text(ui.t10);
text(ui.t11);
text(ui.t11);
text(ui.t12);
text(ui.t13);
text(ui.t14);
text(ui.t15);

shape.withText()
    .setColors(["#6200ee", "#ff00ff", "#462afe"])
    .into(ui.text);

shape.withText()
    .setColors(["#6200ee", "#ff00ff", "#462afe"])
    .into(ui.tip);

function text(t) {
    shape.withText()
        .setColors(["#6200ee", "#ff00ff", "#462afe"])
        // .setColors(["#0000ff", "#6200ee", "#ef4e4f"])
        .into(t);
}