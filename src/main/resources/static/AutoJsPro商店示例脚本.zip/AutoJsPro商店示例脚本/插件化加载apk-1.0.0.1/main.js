"ui";

/**
 * 屁话先说一下
 * 作者：无名小姐 QQ:1352183717
 * 功能：实现了不用安装apk就能调用及使用本地apk安装包的类和资源
 * 原理：通过反射解析apk中的资源及dex,so并实现调用
 * 目的：对主apk的功能增强，插件不用再次安装，插件远程更新
 * 外话：这只是一个Rhino版本轮子，别的版本群友已提供,
 * 实际上还有很多的补充地方，比如加载一个插件中的Activity，大家自行研究啦
 * 本测试用安装包为方便上传已经精简，
 * */
importClass(android.view.ContextThemeWrapper);
importClass(android.content.res.Resources);
var assetManagerCls = java.lang.Class.forName("android.content.res.AssetManager", true, context.getClass().getClassLoader());
assetManagerObj = assetManagerCls.newInstance();
addAssetPathMethod = assetManagerCls.getDeclaredMethod("addAssetPath", java.lang.String);
addAssetPathMethod.setAccessible(true);
addAssetPathMethod.invoke(assetManagerObj,files.path("./XPopup_1.0.apk"));
resources = activity.getResources();
resources = new Resources(assetManagerObj, resources.getDisplayMetrics(), resources.getConfiguration());
mContext = new ContextThemeWrapper(activity, 0);
mResourcesField = mContext.getClass().getDeclaredField("mResources");
mResourcesField.setAccessible(true);
mResourcesField.set(mContext, resources);

ui.layout(
    <vertical>
        <button text="测试" id="aa"/>
    </vertical>);

ui.aa.click(function() {
    showXPopupView("测试弹窗", "我是1", "我是2", "我是3");
});


function showXPopupView(title, content, cancelBtnText, confirmBtnText) {
    runtime.loadDex("./XPopup_1.0.apk");
    importClass("com.lxj.xpopup.XPopup");
    popupView = new XPopup.Builder(mContext)
        .setPopupCallback({
            onCreated: function(pv) {},
            onShow: function(popupView) {
                log("tag", "onShow");
            },
            onDismiss: function(popupView) {
                log("tag", "onDismiss");
            },
            beforeDismiss: function(popupView) {},
            onBackPressed: function(popupView) {
                return true;
            },
        }).asConfirm(new java.lang.String(title), new java.lang.String(content),
            new java.lang.String(cancelBtnText), new java.lang.String(confirmBtnText), {
                onConfirm: function() {
                    toastLog("click confirm");
                }
            }, null, false);
    popupView.show();
}