"ui";
runtime.loadDex("x5.dex");
importClass(com.scave.X5WebView);
importClass(com.tencent.smtt.sdk.WebViewClient);
importClass(com.tencent.smtt.sdk.WebSettings);
//importClass(com.tencent.smtt.sdk.TbsVideo);
importClass(android.content.Intent);
importClass(android.net.Uri);
importClass(com.tencent.smtt.sdk.VideoActivity);
importClass(android.widget.FrameLayout);
ui.useAndroidResources();
ui.layoutFile("main");
let x5WebView = new X5WebView(activity, null);
x5WebView.init();
//let bj = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT);
//x5WebView.setLayoutParams(bj);
//let x5WebSettings = new WebSettings(x5WebViewClient);
ui.layouts.addView(x5WebView);
var x5WebViewClient = new JavaAdapter(com.tencent.smtt.sdk.WebViewClient, {
            onPageStarted: (webView, url, bitmap) => {
                console.log('页面正在加载');
            },
            onPageFinished: (webView, curUrl) => {
                console.log('页面加载完成');
            },
            shouldOverrideUrlLoading: (webView, request) => {
                try {
                    if (request.startsWith("http://") || request.startsWith("https://")) {
                            webView.loadUrl(request);
                            return false;
                        } else {
                            confirm("允许网页打开APP？").then(value => {
                                //当点击确定后会执行这里, value为true或false, 表示点击"确定"或"取消"
                                if (value) {
                                    importPackage(android.net);
                                    let uri = Uri.parse(request);
                                    app.startActivity(new Intent(Intent.ACTION_VIEW).setData(uri).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
                                }
                            });
                        }
                        // 返回true代表自定义处理，返回false代表触发webview加载
                        return true;
                    }
                    catch (e) {
                        if (e.javaException instanceof android.content.ActivityNotFoundException) {
                            webView.loadUrl(url);
                        } else {
                            console.trace(e);
                            //toastLog('无法打开URL: ' + url);
                        }
                    }

                }
            });

        x5WebView.setWebViewClient(x5WebViewClient);
        let x5Settings = x5WebView.getSettings();
        x5Settings.setJavaScriptEnabled(true);
        x5Settings.setJavaScriptCanOpenWindowsAutomatically(true);
        //x5Settings.setAllowFileAccess(true);
        x5Settings.setSupportZoom(true);
        x5Settings.setBuiltInZoomControls(true);
        x5Settings.setUseWideViewPort(true); 
        x5Settings.setSupportMultipleWindows(true); 
        x5Settings.setAppCacheEnabled(true); 
        x5Settings.setDomStorageEnabled(true); 
        x5Settings.setGeolocationEnabled(true); 
        x5WebView.loadUrl("http://www.baidu.com");
        ui.go_web.on("click",function(){
            x5WebView.loadUrl(ui.web_url.getText());
        });