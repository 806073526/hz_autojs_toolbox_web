"ui";
/*
 * @version: 1.0
 * @Date: 2022-01-03 16:34:02
 * @LastEditTime: 2022-05-11 18:29:10
 * @LastEditors: 牙叔
 * @Description:
 * @FilePath: \ji-ni-tai-mei\main.js
 * @名人名言: 牙叔教程 简单易懂
 * @bilibili: 牙叔教程
 * @公众号: 牙叔教程
 * @QQ群: 747748653
 */
engines.all().map((ScriptEngine) => {
  if (engines.myEngine().toString() !== ScriptEngine.toString()) {
    ScriptEngine.forceStop();
  }
});
importClass(android.content.res.ColorStateList);
importClass(android.view.View);
importClass(android.graphics.Color);
importClass(com.google.android.material.chip.ChipGroup);
importClass(com.google.android.material.chip.Chip);
importClass(android.graphics.drawable.BitmapDrawable);

/* -------------------------------------------------------------------------- */
// 'Theme_MaterialComponents',
// 'Theme_MaterialComponents_BottomSheetDialog',
// 'Theme_MaterialComponents_Bridge',
// 'Theme_MaterialComponents_CompactMenu',
// 'Theme_MaterialComponents_DayNight',
// 'Theme_MaterialComponents_DayNight_BottomSheetDialog',
// 'Theme_MaterialComponents_DayNight_Bridge',
// 'Theme_MaterialComponents_DayNight_DarkActionBar',
// 'Theme_MaterialComponents_DayNight_DarkActionBar_Bridge',
// 'Theme_MaterialComponents_DayNight_Dialog',
// 'Theme_MaterialComponents_DayNight_DialogWhenLarge',
// 'Theme_MaterialComponents_DayNight_Dialog_Alert',
// 'Theme_MaterialComponents_DayNight_Dialog_Alert_Bridge',
// 'Theme_MaterialComponents_DayNight_Dialog_Bridge',
// 'Theme_MaterialComponents_DayNight_Dialog_FixedSize',
// 'Theme_MaterialComponents_DayNight_Dialog_FixedSize_Bridge',
// 'Theme_MaterialComponents_DayNight_Dialog_MinWidth',
// 'Theme_MaterialComponents_DayNight_Dialog_MinWidth_Bridge',
// 'Theme_MaterialComponents_DayNight_NoActionBar',
// 'Theme_MaterialComponents_DayNight_NoActionBar_Bridge',
// 'Theme_MaterialComponents_Dialog',
// 'Theme_MaterialComponents_DialogWhenLarge',
// 'Theme_MaterialComponents_Dialog_Alert',
// 'Theme_MaterialComponents_Dialog_Alert_Bridge',
// 'Theme_MaterialComponents_Dialog_Bridge',
// 'Theme_MaterialComponents_Dialog_FixedSize',
// 'Theme_MaterialComponents_Dialog_FixedSize_Bridge',
// 'Theme_MaterialComponents_Dialog_MinWidth',
// 'Theme_MaterialComponents_Dialog_MinWidth_Bridge',
// 'Theme_MaterialComponents_Light',
// 'Theme_MaterialComponents_Light_BarSize',
// 'Theme_MaterialComponents_Light_BottomSheetDialog',
// 'Theme_MaterialComponents_Light_Bridge',
// 'Theme_MaterialComponents_Light_DarkActionBar',
// 'Theme_MaterialComponents_Light_DarkActionBar_Bridge',
// 'Theme_MaterialComponents_Light_Dialog',
// 'Theme_MaterialComponents_Light_DialogWhenLarge',
// 'Theme_MaterialComponents_Light_Dialog_Alert',
// 'Theme_MaterialComponents_Light_Dialog_Alert_Bridge',
// 'Theme_MaterialComponents_Light_Dialog_Bridge',
// 'Theme_MaterialComponents_Light_Dialog_FixedSize',
// 'Theme_MaterialComponents_Light_Dialog_FixedSize_Bridge',
// 'Theme_MaterialComponents_Light_Dialog_MinWidth',
// 'Theme_MaterialComponents_Light_Dialog_MinWidth_Bridge',
// 'Theme_MaterialComponents_Light_LargeTouch',
// 'Theme_MaterialComponents_Light_NoActionBar',
// 'Theme_MaterialComponents_Light_NoActionBar_Bridge',
// 'Theme_MaterialComponents_NoActionBar',
// 'Theme_MaterialComponents_NoActionBar_Bridge',
// activity.setTheme(com.google.android.material.R$style.Theme_MaterialComponents_DayNight_DarkActionBar);
activity.setTheme(com.google.android.material.R$style.Theme_MaterialComponents_NoActionBar);
/* -------------------------------------------------------------------------- */
ui.layout(
  <vertical margin="50 0 50 50">
    <text
      id="title"
      margin="20"
      text="鸡你太美 - 牙叔教程"
      textSize="22sp"
      textColor="#fbfbfe"
      bg="#00afff"
      w="*"
      gravity="center"
    ></text>
    <LinearLayout
      layout_width="match_parent"
      layout_height="match_parent"
      gravity="center"
      orientation="vertical"
      context=".SecondFragment"
    >
      <com.google.android.material.chip.ChipGroup
        layout_width="wrap_content"
        layout_height="wrap_content"
        id="chipGroup"
        singleSelection="true"
      >
        <com.google.android.material.chip.Chip
          layout_width="wrap_content"
          layout_height="wrap_content"
          text="牙叔教程"
          id="firstChip"
          checkable="true"
          clickable="true"
          focusable="true"
        />
      </com.google.android.material.chip.ChipGroup>
    </LinearLayout>
  </vertical>
);
let dirPath = files.path("./audio");
let filePathList = getFilePathList(dirPath);
log(filePathList);
addChip(filePathList, ui.chipGroup);
function addChip(filePathList, chipGroup) {
  var len = filePathList.length;
  for (var i = 0; i < len; i++) {
    let filePath = filePathList[i];
    let fileName = files.getNameWithoutExtension(filePath);
    let chip = createChip(fileName);
    chipGroup.addView(chip, chipGroup.childCount - 1);
  }
}
function createChip(name) {
  let chip = new Chip(activity);
  chip.attr("bg", "#2196f3");
  chip.setCheckable(true);
  chip.text = name;
  chip.setCloseIconVisible(false);
  chip.setOnClickListener(
    new View.OnClickListener({
      onClick: function (v) {
        v.attr("bg", "#2ef3f3");
      },
    })
  );
  return chip;
}

ui.chipGroup.setSingleSelection(true);
ui.chipGroup.setOnCheckedChangeListener(
  new ChipGroup.OnCheckedChangeListener({
    onCheckedChanged: function (chipGroup, i) {
      let chip = chipGroup.findViewById(i);

      if (chip != null) {
        let name = chip.getText().toString();
        if (name === "牙叔教程") {
          toastLog("公众号: 牙叔教程");
          return;
        }
        let audioPath = files.path("./audio/" + chip.getText().toString() + ".mp3");
        //播放音乐
        media.playMusic(audioPath);
        //让音乐播放完
        // sleep(media.getMusicDuration());
      }
    },
  })
);

function getFilePathList(dirPath, filePathList) {
  filePathList = filePathList || [];
  var fileNameList = files.listDir(dirPath);
  var len = fileNameList.length;
  for (var i = 0; i < len; i++) {
    let filepath = files.join(dirPath, fileNameList[i]);
    if (files.isFile(filepath)) {
      filePathList.push(filepath);
    } else {
      // 文件夹, 继续向下递
      getFilePathList(filepath, filePathList);
    }
  }
  // 文件遍历完成, 终止条件, 返回结果
  return filePathList;
}

/* -------------------------------------------------------------------------- */
function getColorStateList() {
  var colorList = [rndColor(), rndColor(), rndColor(), rndColor()];
  var colorStateList = createColorStateList(colorList[0], colorList[1], colorList[2], colorList[3]);
  return colorStateList;
}
function createColorStateList(normal, pressed, focused, unable) {
  var colors = [pressed, focused, normal, focused, unable, normal];
  var states = new Array();
  states[0] = [android.R.attr.state_pressed, android.R.attr.state_enabled];
  states[1] = [android.R.attr.state_enabled, android.R.attr.state_focused];
  states[2] = [android.R.attr.state_enabled];
  states[3] = [android.R.attr.state_focused];
  states[4] = [android.R.attr.state_window_focused];
  states[5] = [];
  var colorList = new ColorStateList(states, colors);
  return colorList;
}

function rndColor() {
  return colors.rgb(random(0, 255), random(0, 255), random(0, 255));
}
function printObj(obj) {
  var arr = [];
  for (var k in obj) {
    arr.push(k);
  }
  arr.sort();
  log(arr);
}
