//main.js
/*
* 注意：
* 点击实时坐标后实时更新的ARGB值会自动跟随 *
* 跟随后移开实时坐标，获取ARGB值 *
* 实时更新显示的坐标为实时坐标与实际位置不符 *
* 是为了方便观察以及更准确获取ARGB值 *

*/

sleep(500);
engines.execScriptFile("获取指定位置的坐标.js");
sleep(500);
engines.execScriptFile("获取指定位置的ARGB值.js");