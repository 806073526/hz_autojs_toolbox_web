"ui";

var themeJs = require("./theme.js");

dialogs.setDefaultDialogType("app");

var settingStorage = storages.create("wordbook45qq_setting");
var current_sort = settingStorage.get("sort", "none");

var sort = {};

//加入工作区对话框
let sortView = ui.inflate(
    <vertical padding="16 0">
        <radiogroup id="radio">
            <radio id="none" text="无" w="*" marginBottom="10"/>
            <radio id="nameUp" text="按名称 ▲" w="*"/>
            <radio id="nameUnder" text="按名称 ▼" w="*"/>
            <radio id="countUnder" text="按标记 ▼" w="*"/>
            <radio id="random" text="随机排序" w="*" marginTop="10"/>
        </radiogroup>
    </vertical>, null, false);

sortView.radio.check(ui.findByStringId(sortView, current_sort).getId());

// 显示对话框
var sortDialogs = dialogs.build({
    customView: sortView,
    title: "排序方式",
    positive: "确定",
    negative: "取消",
    titleColor: themeJs.text,
    // view高度超过对话框时是否可滑动
    wrapInScrollView: false,
    // 按下按钮时是否自动结束对话框
    autoDismiss: true
}).on("positive", (dialog) => {
    var parent = sortView.radio;
    var selectView = sortView.radio.findViewById(sortView.radio.getCheckedRadioButtonId());
    var wordList = sort.getList();
    var select = selectView.getText();
    switch (select) {
        case "无":
            settingStorage.put("sort", "none");
            return;
        case "按名称 ▲":
            settingStorage.put("sort", "nameUp");
            sortByNameUp(wordList);
            return;
        case "按名称 ▼":
            settingStorage.put("sort", "nameUnder");
            sortByNameUnder(wordList);
            return;
        case "按标记 ▼":
            settingStorage.put("sort", "countUnder");
            sortByCountUnder(wordList);
            return;
        case "随机排序":
            settingStorage.put("sort", "random");
            threads.start(function() {
                sleep(500);
                let i = wordList.length;
                while (i) {
                    let j = Math.floor(Math.random() * i--);
                    [wordList[j], wordList[i]] = [wordList[i], wordList[j]];
                }
            });
            return;
    }
});

function sortByNameUp(list) {
    list.sort((a, b) => {
        return new java.lang.String(a.word).compareToIgnoreCase(b.word);;
    });
}

function sortByNameUnder(list) {
    list.sort((a, b) => {
        return new java.lang.String(b.word).compareToIgnoreCase(a.word);
    });
}

function sortByCountUnder(list) {
    list.sort((a, b) => {
        ac = a.count == null ? 0: a.count;
        bc = b.count == null ? 0: b.count;
        return bc - ac;
    });
}

function sortByAny(list, start) {
    let array = [];
    current_sort = settingStorage.get("sort", "none");
    if (current_sort == "nameUp") {
        for (let i = start, j = start - 1; i > 0; i--, j--) {
            if (new java.lang.String(list[i].word).compareToIgnoreCase(list[j].word) < 0) {
                [list[i], list[j]] = [list[j], list[i]];
            } else return i;
        }
    } else if (current_sort == "nameUnder") {
        for (let i = start, j = start - 1; i > 0; i--, j--) {
            if (new java.lang.String(list[i].word).compareToIgnoreCase(list[j].word) > 0) {
                [list[i], list[j]] = [list[j], list[i]];
            } else return i;
        }
    } else if (current_sort == "countUnder") {
        for (let i = start, j = start - 1; i > 0; i--, j--) {
            let iitem = list[i];
            let jitem = list[j];
            ic = iitem.count == null ? 0 : iitem.count;
            jc = jitem.count == null ? 0 : jitem.count;
            if (ic > jc) {
                [list[i], list[j]] = [list[j], list[i]];
            } else return i;
        }
    }
    return list.length - 1;
}

events.broadcast.on("update_count_sort", (array) => {
    if (settingStorage.get("sort", "none") == "countUnder") {
        sortByCountUnder(array[0]);
    }
});

sortView.getParent().getParent().attr("bg", themeJs.layout);

sort.sortByNameUp = sortByNameUp;
sort.sortByNameUnder = sortByNameUnder;
sort.sortByAny = sortByAny;

sort.show = function(list) {
    sort.getList = function() {
        return list;
    };
    sortDialogs.show();
}

module.exports = sort;