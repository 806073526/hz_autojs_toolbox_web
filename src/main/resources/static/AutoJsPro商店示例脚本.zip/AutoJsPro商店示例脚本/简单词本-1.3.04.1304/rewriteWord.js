"ui";

var themeJs = require("./theme.js");
var coloringJs = require("./coloring.js");

dialogs.setDefaultDialogType("app");

var rewriteWord = {};

//修改释义对话框
let rewriteView = ui.inflate(
    <vertical padding="16 0">
        <View w="*" h="0"/>
        <horizontal gravity="center_vertical">
            <text text="单词" textColor="{{themeJs.text2}}"/>
            <horizontal w="*" gravity="right">
                <text text="粗体显示" textColor="{{themeJs.text2}}"/>
                <checkbox id="bold" marginLeft="4" checked="true" />
            </horizontal>
        </horizontal>
        <input id="reword" textColor="{{themeJs.text}}"/>
        <text text="释义" textColor="{{themeJs.text2}}"/>
        <input textSize="16" id="rewrite" textColor="{{themeJs.text}}"/>
    </vertical>, null, false);

var countDialog = dialogs.build({
    title: "标记",
    items: ["增加标记", "减少标记", "清除标记"],
    negative: "取消",
    titleColor: themeJs.text,
    itemsColor: themeJs.text2,
    // view高度超过对话框时是否可滑动
    wrapInScrollView: false,
}).on("item_select", (index, item, dialog)=>{
    rewriteWord.countFun(index, item);
});

countDialog.getView().setBackgroundColor(android.graphics.Color.parseColor(themeJs.layout));

// 显示对话框
var rewriteDialogs = dialogs.build({
    customView: rewriteView,
    title: "编辑",
    positive: "确定",
    neutral: "标记",
    negative: "取消",
    titleColor: themeJs.text,
    // view高度超过对话框时是否可滑动
    wrapInScrollView: false,
}).on("positive", (dialog) => {
    threads.start(function() {
        rewriteWord.fun(rewriteView.reword.text(), rewriteView.bold.isChecked(), rewriteView.rewrite.text());
    });
}).on("neutral", (dialog) => {
    countDialog.show();
});

rewriteView.getParent().getParent().attr("bg", themeJs.layout);

rewriteWord.show = function(word, isBold, meaning, fun, countFun) {
    rewriteDialogs.title = "编辑" + word;
    rewriteView.reword.setText(word);
    rewriteView.bold.setChecked(isBold == null ? true : isBold)
    rewriteView.rewrite.setText(coloringJs.getColoringStr(meaning));
    rewriteWord.fun = fun;
    rewriteWord.countFun = countFun;
    rewriteDialogs.show();
}

module.exports = rewriteWord;