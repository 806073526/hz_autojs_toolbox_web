"ui";
var settingStorage = storages.create("wordbook45qq_setting");

var themes = {
    day: {
        bar: "#009788",
        parent_layout: "#FAFAFA",
        layout: "#FFFFFF",
        text: "#212121",
        text2: "#666666",
        text3: "#999999"
    },
    night: {
        bar: "#212121",
        parent_layout: "#303030",
        layout: "#424242",
        text: "#DDDDDD",
        text2: "#999999",
        text3: "#666666"
    }
};

function setTheme(theme_name) {
    let current_theme = themes[theme_name];
    for (let i in current_theme)
        theme[i] = current_theme[i];
    theme["current"] = theme_name;
    settingStorage.put("theme", theme_name);
    
    ui.statusBarColor(theme.bar);
}

function updateTheme() {
    setTheme(settingStorage.get("theme", "day"));
}

var theme = {};
theme.setTheme = setTheme;
theme.updateTheme = updateTheme;

updateTheme();

module.exports = theme;