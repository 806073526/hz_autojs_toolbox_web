"ui";

var addJs = require("./add.js");
var themeJs = require("./theme.js");

dialogs.setDefaultDialogType("app");

var addWork = {};

//加入工作区对话框
let addView = ui.inflate(
    <vertical padding="16 0">
        <text textColor="{{themeJs.text2}}">名称</text>
        <input id="workname" textColor="{{themeJs.text}}"/>
        <text textColor="{{themeJs.text2}}">概要</text>
        <input id="worksummary" textColor="{{themeJs.text}}"/>
    </vertical>, null, false);

// 显示对话框
var addDialogs = dialogs.build({
    customView: addView,
    title: "新建单词本",
    positive: "确定",
    negative: "取消",
    titleColor: themeJs.text,
    // view高度超过对话框时是否可滑动
    wrapInScrollView: false,
    // 按下按钮时是否自动结束对话框
    autoDismiss: false
}).on("positive", (dialog) => {
    if (addView.workname.text() == "") {
        addView.workname.setError("单词不能为空");
        return;
    }
    let list = addWork.getList();
    addJs.addWork(list, addView.workname.text(), addView.worksummary.text());
    if (addWork.fun != null) addWork.fun(list[list.length - 1], list.length - 1);
    dialog.dismiss();
}).on("negative", (dialog) => {
    dialog.dismiss();
});

addView.getParent().getParent().attr("bg", themeJs.layout);

addWork.show = function(list, title, summary, fun) {
    addWork.getList = function() {
        return list;
    };
    addWork.fun = fun;
    addView.workname.setText(title);
    addView.worksummary.setText(summary);
    addDialogs.show();
};

module.exports = addWork;