"ui";

var themeJs = require("./theme.js");

dialogs.setDefaultDialogType("app");

let rewriteView = ui.inflate(
    <vertical padding="16 0">
        <text textColor="{{themeJs.text2}}">工作区名称</text>
        <input id="wordname" textColor="{{themeJs.text}}"/>
        <text textColor="{{themeJs.text2}}">概要</text>
        <input id="wordsummary" textColor="{{themeJs.text}}"/>
    </vertical>, null, false);

var rewriteDialogs = dialogs.build({
    customView: rewriteView,
    title: "编辑单词本",
    positive: "确定",
    negative: "取消",
    titleColor: themeJs.text,
    wrapInScrollView: false,
    autoDismiss: true
}).on("positive", (dialog) => {
    rewriteWork.fun(rewriteView.wordname.text(), rewriteView.wordsummary.text());
});

rewriteView.getParent().getParent().attr("bg", themeJs.layout);

var rewriteWork = {
    show: function(title, summary, fun) {
        rewriteView.wordname.setText(title);
        rewriteView.wordsummary.setText(summary);
        rewriteWork.fun = fun;
        rewriteDialogs.show();
    }
}

module.exports = rewriteWork;