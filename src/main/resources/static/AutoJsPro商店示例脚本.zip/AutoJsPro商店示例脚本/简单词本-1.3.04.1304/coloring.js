importClass(android.text.Html);

var coloring = {}

//设置单词词性颜色
var meaningColor = "#29B6F6";

coloring.canColor = function(str) {
    if (str == null)
        return false;
    return str.match(/\./) != null;
}

//返回从html着色时文本
coloring.getStrFromHtml = function(str) {
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N)
        return Html.fromHtml(str, Html.FROM_HTML_MODE_LEGACY);
    else
        return Html.fromHtml(str);
}

//将文本着色颜色改变
coloring.getStrAfterColor = function(str, color) {
    if (str == null)
        return "";
    return new java.lang.String(str.replace(/ /g, "&nbsp;"))
        .replaceAll("(?<=(\\b[a-z]{1,6}\\.))", "</b></font>")
        .replace(/(?=(\b[a-z]{1,6}\.))/g, "<font color='" + (color == null ? meaningColor : color) + "'><b>")
        .replace(/\n/g, "<br/>");
}

coloring.getColoringStr = function(str, color) {
    return coloring.getStrFromHtml(coloring.getStrAfterColor(str, color));
}

coloring.setStrColor = function(color) {
    meaningColor = color;
}        

module.exports = coloring;