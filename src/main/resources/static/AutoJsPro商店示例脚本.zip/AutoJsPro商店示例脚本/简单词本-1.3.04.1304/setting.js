"ui";

var themeJs = require("./theme.js");

dialogs.setDefaultDialogType("app");

var settingStorage = storages.create("wordbook45qq_setting");

//创造其它设置自定义对话框
let otherSettingView = ui.inflate(
    <vertical padding="26 10">
        <horizontal>
            <text text="在单词没有音标时隐藏播放按钮" textColor="{{themeJs.text2}}"/>
            <checkbox id="hideVudioIcon" checked="true" />
        </horizontal>
        <View bg="{{themeJs.text3}}" h="1" w="*" marginTop="10"/>
        <horizontal>
            <text text="使用网络源" w="*" textColor="{{themeJs.text2}}" layout_weight="1"/>
            <spinner id="source" textColor="{{themeJs.text}}" entries="金山源|有道源"/>
        </horizontal>
        <View bg="{{themeJs.text3}}" h="1" w="*"/>
        <horizontal>
            <text text="音标显示" w="*" textColor="{{themeJs.text2}}" layout_weight="1"/>
            <spinner id="phShow" textColor="{{themeJs.text}}" entries="只显示英音|只显示美音|显示英音和美音"/>
        </horizontal>
        <View bg="{{themeJs.text3}}" h="1" w="*"/>
    </vertical>, null, false);
    
otherSettingView.hideVudioIcon.attr("checked", settingStorage.get("hideVudioIcon", true));
otherSettingView.source.setSelection(settingStorage.get("netFrom", 0));
otherSettingView.phShow.setSelection(settingStorage.get("phShow", 2));
//设置空音标隐藏监听
otherSettingView.hideVudioIcon.on("check", (checked) => {
    settingStorage.put("hideVudioIcon", checked);
});

//切换网络源监听
otherSettingView.source.setOnItemSelectedListener({
    onItemSelected: function(adapterView, view, i, l) {
        let i = otherSettingView.source.getSelectedItemPosition();
        settingStorage.put("netFrom", i);
    }
});

otherSettingView.phShow.setOnItemSelectedListener({
    onItemSelected: function(adapterView, view, i, l) {
        settingStorage.put("phShow", i);
        if (i != 2)
            if (i == 0)
                settingStorage.put("phType", "en");
            else settingStorage.put("phType", "an");
    }
});

//设置对话框
var otherSettingDialogs = dialogs.build({
    customView: otherSettingView,
    title: "设置",
    titleColor: themeJs.text,
    wrapInScrollView: false,
    autoDismiss: false
})

otherSettingView.getParent().getParent().attr("bg", themeJs.layout);

var setting = {
    show: function() {
        otherSettingDialogs.show();
    }
}

module.exports = setting;