"ui";

var themeJs = require("./theme.js");

dialogs.setDefaultDialogType("app");

var rewardView = ui.inflate(
    <vertical padding="16 5">
        <text textColor="{{themeJs.text}}">感谢打赏！您的支持是我前进的动力。
            (打赏请备注名字或昵称)</text>
            <horizontal>
                <card id="ws" w="auto" h="auto" margin="5 10" cardCornerRadius="32" cardBackgroundColor="#22AB38" cardElevation="5dp" foreground="?selectableItemBackground">
                    <text text="微信支持" h="*" margin="5 5" textColor="#ffffff" textStyle="bold" gravity="center"/>
                </card>
                <card id="zfb" w="auto" h="auto" margin="5 10" cardCornerRadius="32" cardBackgroundColor="#019FE8" cardElevation="5dp" foreground="?selectableItemBackground">
                    <text text="支付宝支持" h="*" margin="5 5" textColor="#ffffff" textStyle="bold" gravity="center"/>
                </card>
            </horizontal>
            <img id="sfk" src="file://./res/rewardws.jpg" h="300" radius="40"/>
        </vertical>, null, false);

rewardView.ws.on("click", ()=> {
    rewardView.sfk.attr("src", "file://./res/rewardws.jpg");
});

rewardView.zfb.on("click", ()=> {
    rewardView.sfk.attr("src", "file://./res/rewardzfb.jpg");
});

var rewardDialogs = dialogs.build({
    customView: rewardView,
    title: "打赏作者💰",
    positive: "返回",
    titleColor: themeJs.text,
    wrapInScrollView: false,
    autoDismiss: true
});

rewardView.getParent().getParent().attr("bg", themeJs.layout);

module.exports = rewardDialogs;