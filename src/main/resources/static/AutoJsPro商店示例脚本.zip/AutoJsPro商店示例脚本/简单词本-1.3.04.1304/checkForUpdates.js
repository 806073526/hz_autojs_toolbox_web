function updateDiolog(version, log) {
    dialogs.build({
        title: "发现新版本v" + version,
        content: log,
        positive: "下载",
        negative: "取消",
        neutral: "到浏览器下载",
        checkBoxPrompt: "不再提示"
    }).on("positive", () => {
        toast("开始下载....");
    }).on("neutral", () => {
        app.openUrl("https://www.autojs.org");
    }).on("check", (checked) => {
        log(checked);
    }).show();
}

function check() {

}

let checkForUpdates = {
    check: check,
};

module.exports = checkForUpdates;