var materialColors = ["#e91e63", "#ab47bc", "#5c6bc0", "#7e57c2", "#2196f3", "#00bcd4",
    "#26a69a", "#4caf50", "#8bc34a", "#ffeb3b", "#ffa726", "#78909c", "#8d6e63"
];

var sdn = 0;

function addWord(list, word, meaning, en, am, bold) {
    let item = {
        word: word,
        meaning: meaning,
        en: en,
        am: am,
        bold: bold,
        updateFlag: true,
        color: materialColors[random(0, materialColors.length - 1)],
    };
    list.push(item);
    return item;
}

function addWork(list, title, summary) {
    let sd = java.lang.System.currentTimeMillis() + "" + sdn++;
    list.push({
        title: title,
        summary: summary,
        color: materialColors[random(0, materialColors.length - 1)],
        sdcard: sd,
    });
    return sd;
}

var add = {
    addWork: addWork,
    addWord: addWord,
}

module.exports = add;