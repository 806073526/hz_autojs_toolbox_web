module.exports = (main.toString()).replace(/function main\(\) \{/g, "{");

function main() {
    importClass(android.view.View);
    importClass(android.widget.ScrollView);
    importClass(android.graphics.Typeface);
    var themeJs = require("./theme.js");
    var coloringJs = require("./coloring.js");
    var networkSourceJs = require("./networkSource.js");
    var playMusicJs = require("./playMusic.js");

    var settingStorage = storages.create("wordbook45qq_setting");

    //是否隐藏单词
    var hideWord = settingStorage.get("hideWord", false);
    //隐藏释义
    var hideMean = settingStorage.get("hideMean", false);
    //音标显示
    var phShow = 2; //settingStorage.get("phShow", 0);
    //播放偏好
    var phType = settingStorage.get("phType", "en");

    var list = [];
    
    dialogs.setDefaultDialogType("app");
    ui.statusBarColor(themeJs.bar);

    ui.layout(
        <vertical bg="{{themeJs.parent_layout}}">
            <appbar bg="{{themeJs.bar}}">
                <toolbar id="toolbar" title="放映模式"/>
            </appbar>
            <frame layout_weight="1">
                <androidx.viewpager.widget.ViewPager id="viewpager"/>
                <text id="prompt" textColor="{{themeJs.text2}}" gravity="center" h="*"/>
            </frame>
            <text id="index" text="0/0" textColor="{{themeJs.text}}" gravity="center" h="80"/>
            <card id="last" w="*" h="64" margin="15 0" cardCornerRadius="32" cardBackgroundColor="{{themeJs.layout}}" cardElevation="5dp" foreground="?selectableItemBackground">
                <text text="上一个" h="*" textColor="{{themeJs.text}}" textSize="16" textStyle="bold" gravity="center"/>
            </card>
            <card id="next" w="*" h="64" margin="15 10 15 25" cardBackgroundColor="#9CCC65" cardCornerRadius="32" cardElevation="5dp" foreground="?selectableItemBackground">
                <text text="下一个" h="*" textColor="#ffffff" textSize="16" textStyle="bold" gravity="center"/>
            </card>
        </vertical>
    );

    ui.last.on("click", () => {
        ui.viewpager.setCurrentItem(ui.viewpager.getCurrentItem() - 1, true);
    });

    ui.next.on("click", () => {
        ui.viewpager.setCurrentItem(ui.viewpager.getCurrentItem() + 1, true);
    });

    ui.last.setAlpha(0.5);
    ui.last.setClickable(false);

    var viewList = [];
    var timing = 0;
    var currentItem = {};
    var old_time = 0;

    function addView() {
        let view = ui.inflate(
            <frame>
                <vertical gravity="center_horizontal">
                    <card w="*" h="auto" id="card" margin="15 25 15 10" cardBackgroundColor="{{themeJs.layout}}" minHeight="120" cardCornerRadius="10dp" cardElevation="5dp">
                        <frame id="l_bookmark" foreground="?selectableItemBackground">
                            <img id="bookmark" src="@drawable/ic_bookmark_black_48dp" layout_gravity="right|top" w="15" h="15" marginRight="8" visibility="gone"/>
                            
                            <ScrollView id="scroll">
                                <vertical margin="15 10">
                                    <vertical id="l_word">
                                        <text id="word" text="xxx" gravity="center" textColor="{{themeJs.text}}" textSize="20" textStyle="bold"/>
                                        <horizontal gravity="center_vertical" marginTop="10">
                                            <horizontal id="l_en" w="auto">
                                                <text id="en" text="英[en]" textColor="{{themeJs.text3}}" textSize="12" maxLines="1" />
                                                <img id="enVudio" src="@drawable/ic_volume_up_black_48dp" layout_gravity="bottom" marginLeft="5" w="16" h="16"/>
                                            </horizontal>
                                            <horizontal id="l_am" w="auto" marginLeft="15">
                                                <text id="am" text="美[am]" textColor="{{themeJs.text3}}" textSize="12" maxLines="1" />
                                                <img id="amVudio" src="@drawable/ic_volume_up_black_48dp" layout_gravity="bottom" marginLeft="5" w="16" h="16"/>
                                            </horizontal>
                                        </horizontal>
                                    </vertical>
                                    <horizontal id="l_meaning" marginTop="10" marginTop="5">
                                        <text text="释义：" textColor="{{themeJs.text}}"/>
                                        <text id="meaning" text="XXX XXX" textColor="{{themeJs.text2}}"/>
                                    </horizontal>
                                    <vertical id="moreMeaning">
                                        <horizontal id="l_web_trans" marginTop="5" visibility="gone">
                                            <text text="网络释义" textColor="{{themeJs.text}}" marginRight="10"/>
                                            <text id="web_trans" textColor="{{themeJs.text2}}"/>
                                        </horizontal>
                                        <text id="exam_type" text="" w="*" textSize="12" textColor="{{themeJs.text2}}" marginTop="10" marginBottom="10" gravity="center_horizontal"/>
                                        <list id="wfs">
                                            <horizontal>
                                                <text text="{{this.name}}" textColor="{{themeJs.text}}" marginRight="10"/>
                                                <text text="{{this.value}}" textColor="{{themeJs.text2}}"/>
                                            </horizontal>
                                        </list>
                                        <vertical id="l_sentencepair" marginTop="10" visibility="gone">
                                            <text text="双语例句" textColor="{{themeJs.text}}"/>
                                            <list id="sentencepair" marginLeft="10">
                                                <vertical w="*">
                                                    <text id="sentence" text="{{this.sentence}}" textColor="{{themeJs.text2}}"/>
                                                    <text id="sentence_eng" text="{{this.sentence_eng}}" visibility="gone"/>
                                                    <text text="{{this.sentence_translation}}" textColor="{{themeJs.text2}}" marginTop="5"/>
                                                    <text text="{{this.source==null ? '' : this.source}}" textColor="{{themeJs.text3}}" visibility="{{this.source==null ? 'gone' : 'visible'}}" w="*" gravity="right"/>
                                                    <View w="0" h="10"/>
                                                </vertical>
                                            </list>
                                        </vertical>
                                        <vertical id="l_synos" marginTop="10" marginBottom="25" visibility="gone">
                                            <text text="同近义词" textColor="{{themeJs.text}}"/>
                                            <list id="synos" marginLeft="10">
                                                <horizontal>
                                                    <text text="{{this.pos}}" textColor="{{themeJs.text3}}"/>
                                                    <vertical marginLeft="10">
                                                        <text text="{{this.tran}}" textColor="{{themeJs.text2}}" marginLeft="10"/>
                                                        <text text="{{this.ws}}" textColor="{{themeJs.text2}}" marginLeft="10"/>
                                                    </vertical>
                                                </horizontal>
                                            </list>
                                        </vertical>
                                    </vertical>
                                </vertical>
                            </ScrollView>
                        </frame>
                        <View id="bg" layout_gravity="bottom" h="10" w="*"/>
                    </card>
                </vertical>
            </frame>
        );

        view.scroll.setVerticalScrollBarEnabled(false);

        view.l_bookmark.on("click", () => {
            let new_time = java.lang.System.currentTimeMillis();
            if (new_time - old_time <= 300) {
                old_time = 0;
                let item = list[ui.viewpager.getCurrentItem()];
                if (item.hasMark) {
                    item.hasMark = null;
                    view.bookmark.setVisibility(View.GONE);
                } else {
                    item.hasMark = true;
                    view.bookmark.attr("tint", item.color);
                    view.bookmark.setVisibility(View.VISIBLE);
                }
                events.broadcast.emit("slideshow_hasMark_return", {
                    id: item.id == null ? ui.viewpager.getCurrentItem() : item.id,
                    hasMark: item.hasMark
                });
            } else {
                old_time = new_time;
            }
        });

        view.l_bookmark.on("long_click", () => {
            let item = list[ui.viewpager.getCurrentItem()];
            showView.word.setText(item.word);
            showView.word.setTypeface(item.bold == null || item.bold ? Typeface.DEFAULT_BOLD : Typeface.SERIF);
            showView.mean.setText(coloringJs.getColoringStr(item.meaning));
            if (item.hasMark) {
                showView.bookmark.attr("tint", item.color);
                showView.bookmark.setVisibility(View.VISIBLE);
            } else showView.bookmark.setVisibility(View.GONE);
            showDialogs.show();
        });

        view.scroll.on("touch", (m, v) => {
            view.l_bookmark.onTouchEvent(m);
        });

        view.enVudio.on("click", () => {
            threads.start(function() {
                playMusicJs.playMusicFromWord(viewList[ui.viewpager.getCurrentItem() % 5].enVudio, list[ui.viewpager.getCurrentItem()].word, "en");
            });
        });

        view.amVudio.on("click", () => {
            threads.start(function() {
                playMusicJs.playMusicFromWord(viewList[ui.viewpager.getCurrentItem() % 5].amVudio, list[ui.viewpager.getCurrentItem()].word, "am");
            });
        });

        view.wfs.setNestedScrollingEnabled(false);

        //监听item刷新，并为文本着色
        view.sentencepair.addOnChildAttachStateChangeListener({
            onChildViewAttachedToWindow: function(view) {
                let text = view.sentence_eng.text();
                if (!hideMean && view.sentence.getVisibility() == View.VISIBLE && coloringJs.canColor(text))
                    ui.post(() => {
                        view.sentence.setText(coloringJs.getStrFromHtml(text));
                    }, ((timing++) % 5) * 25);
            },
            onChildViewDetachedFromWindow: function(view) {}
        });

        view.sentencepair.setNestedScrollingEnabled(false);

        viewList.push(view);

        return view;
    }

    //显示释义对话框
    let showView = ui.inflate(
        <frame>
            <img id="bookmark" src="@drawable/ic_bookmark_black_48dp" layout_gravity="right|top" w="15" h="15" marginRight="8" visibility="gone"/>
            <vertical padding="16 20">
                <text id="word" textSize="20" textColor="{{themeJs.text}}"/>
                <text id="mean" textColor="{{themeJs.text}}" marginTop="10"/>
            </vertical>
        </frame>, null, false);

    // 显示对话框
    var showDialogs = dialogs.build({
        customView: showView,
        titleColor: themeJs.text,
        wrapInScrollView: false,
        autoDismiss: true
    });

    showView.getParent().getParent().attr("bg", themeJs.layout);

    addView();

    ui.viewpager.setOnPageChangeListener(new Packages.androidx.viewpager.widget.ViewPager.OnPageChangeListener({
        onPageScrolled: function(x, y, z) {},
        onPageSelected: function(i) {
            ui.index.setText((i + 1) + "/" + list.length);
            if (i == 0) {
                ui.last.setAlpha(0.5);
                ui.last.setClickable(false);
            } else {
                ui.last.setAlpha(1);
                ui.last.setClickable(true);
            }

            if (i == list.length - 1) {
                ui.next.setAlpha(0.5);
                ui.next.setClickable(false);
            } else {
                ui.next.setAlpha(1);
                ui.next.setClickable(true);
            }
        },
        onPageScrollStateChanged: function(i) {}
    }));

    let adapter = new Packages.androidx.viewpager.widget.PagerAdapter({
        getCount: function() {
            return list.length;
        },
        destroyItem: function(viewGroup, i, obj) {
            viewGroup.removeView(viewList[i % 5]);
        },
        instantiateItem: function(viewGroup, i) {
            let view = viewList[i % 5];
            set(view, i);
            viewGroup.addView(view);
            return view;
        },
        isViewFromObject: function(view, obj) {
            return view == obj;
        }
    });

    var moreMeaningJson = {};

    function set(view, i) {
        let word = list[i];
        for (let i in word)
            if (word[i] != null) word[i]["themeJs"] = themeJs;

        if (hideWord)
            view.l_word.setVisibility(View.INVISIBLE);
        else {
            view.l_word.setVisibility(View.VISIBLE);
            view.word.setText(word.word);
            if (phShow == 1 || isNull(word.en))
                view.l_en.setVisibility(View.GONE);
            else {
                view.l_en.setVisibility(View.VISIBLE);
                view.en.setText("英[" + word.en + "]");
            }
            if (phShow == 0 || isNull(word.am))
                view.l_am.setVisibility(View.GONE);
            else {
                view.l_am.setVisibility(View.VISIBLE);
                view.am.setText("美[" + word.am + "]");
            }
        }

        view.bg.attr("bg", word.color);
        if (!hideMean && !hideWord) {
            if (word.hasMark) {
                view.bookmark.attr("tint", word.color);
                view.bookmark.setVisibility(View.VISIBLE);
            } else view.bookmark.setVisibility(View.GONE);

            if (word.bold != null && !word.bold) {
                view.word.setTypeface(Typeface.SERIF);
            }
        }

        if (hideMean)
            view.l_meaning.setVisibility(View.INVISIBLE);
        else {
            view.l_meaning.setVisibility(View.VISIBLE);
            view.meaning.setText(coloringJs.canColor(word.meaning) ? coloringJs.getColoringStr(word.meaning) : word.meaning);

            let title = word.word;
            view.moreMeaning.setVisibility(View.GONE);
            threads.start(function() {
                let json = moreMeaningJson[i];
                let moreMeaning = {};
                if (json == null) {
                    moreMeaning = networkSourceJs.getMoreMeaning(word.word);
                    moreMeaningJson[i] = moreMeaning;
                } else moreMeaning = json;

                ui.run(() => {
                    if (view.word.text() == title) {
                        view.exam_type.setText(notNull(view.exam_type, moreMeaning.exam_type));
                        view.web_trans.setText(notNull(view.l_web_trans, moreMeaning.web_trans));
                        view.wfs.setDataSource(notNull(view.wfs, moreMeaning.wfs));
                        view.sentencepair.setDataSource(notNull(view.l_sentencepair, moreMeaning.sentencepair));
                        view.synos.setDataSource(notNull(view.l_synos, moreMeaning.synos));
                        view.moreMeaning.setVisibility(View.VISIBLE);
                    }
                });
            });
        }
    }

    function isNull(str) {
        return str == null || str == "";
    }

    function notNull(view, str) {
        if (str instanceof Array && str.length == 0) {
            view.setVisibility(View.GONE);
            return [];
        }
        if (isNull(str)) {
            view.setVisibility(View.GONE);
            return "";
        } else {
            view.setVisibility(View.VISIBLE);
            return str;
        }
    }

    function enter(list) {
        this.list = list;
        ui.run(() => {
            addView();
            addView();
            addView();
            addView();
            ui.viewpager.setAdapter(adapter);
            ui.index.setText(1 + "/" + list.length);

            if (list.length == 0) {
                ui.prompt.setText("这里一个单词也没有╮(￣▽￣\")╭ \n请先去添加一些吧！");
                ui.prompt.setVisibility(View.VISIBLE);
            } else ui.prompt.setVisibility(View.GONE);

            if (list.length == 0 || list.length == 1) {
                ui.next.setAlpha(0.5);
                ui.next.setClickable(false);
            }
        });
    }
}