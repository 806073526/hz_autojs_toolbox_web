//抠脚本人
//qq:742374184
"ui";
ui.useAndroidResources();
ui.layout(
    <horizontal padding="15">
        <text paddingRight="10dp" text="输入框:"/>
        <input padding="10dp" layout_weight="1" text="抠脚本人" bg="@drawable/black_border"/>
    </horizontal>
)