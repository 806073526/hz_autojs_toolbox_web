"ui";

//设置对话框为应用对话框，不需要悬浮窗权限,设置成什么类型的对话框都无所谓，看个人
$dialogs.setDefaultDialogType("app");

//返回键点击事件
ui.emitter.on("back_pressed", function (e) {
//点击返回键不退出
  e.consumed = true;
//点击返回键之后弹出对话框，点击确定就执行exit()进行退出
  confirm("确认退出吗？")
        .then(yes => {
        if(yes){
//可以使用exit()或者engines.stopAll()，看个人需要
          exit();
        }
        });
});