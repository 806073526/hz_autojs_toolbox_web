"nodejs";
/**
 * 作者：唱跳rap打篮球 QQ：565947467 时间:2022年10月14日15:46:47
 */

const { setClip } = require('clip_manager');
const os = require("os");
const express = require("express")
const {WebSocketServer} = require("ws");
const {performGlobalAction} = require("accessibility")
const {openUrl} = require("app")
const {showToast} = require("toast")
const app = express()

app.use(express.static("./static"))
app.get("/",(req,res)=>{
    res.send("OK")
   if(Number(req._parsedUrl.query) == 0){
    showToast("弹个气泡")
   return }
   if(Number(req._parsedUrl.query)==1){
       setClip(os.networkInterfaces().wlan0[3].address+":3030/home.html")
       showToast("已经复制页面地址")
       return
   }
   performGlobalAction(Number(req._parsedUrl.query))
})

app.listen(3030,()=>{
    openUrl("http://127.0.0.1:3030/home.html")
})




