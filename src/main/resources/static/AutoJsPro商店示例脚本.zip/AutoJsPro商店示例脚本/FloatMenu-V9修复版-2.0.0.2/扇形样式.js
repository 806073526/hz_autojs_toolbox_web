"nodejs ui-thread";

const { showToast } = require("toast");
const FloatMenu = require("./@se7en/float_menu");

let fm = new FloatMenu();

let item = fm.addItem('按钮1');
item.setColors('#0076ff', '#ff3824')
    .setTints('#fafafa')
    .setIcons('ic_play_arrow_black_48dp', 'ic_stop_black_48dp')
    //设置控件样式为复选框样式
    .setStyle(FloatMenu.TYPE_ITEM_STYLE_CHECKBOX)
    .onClick(view => {
        showToast(`点击了 ${view.name} 是否选中 ${view.getChecked()}`);
        //是否保持菜单开启 没有返回值或者true保持开启 返回false菜单关闭
        return true;
    });

fm.addItem('按钮2').setColors('#00ff00').setIcons('icon_autojs_logo');
fm.addItem('按钮3').setColors('#00ff00').setIcons('icon_autojs_logo');
fm.addItem('按钮4').setColors('#00ff00').setIcons('icon_autojs_logo');
fm.addItem('按钮5').setColors('#00ff00').setIcons('icon_autojs_logo');

fm.addItem('退出')
    .setColors('#0000ff')
    .setTints('#fafafa')
    .setIcons('ic_exit_to_app_black_48dp')
    .onClick(view => {
        fm.close();
        showToast('软件退出');
        $autojs.cancelKeepRunning(id);
        process.exit();
    });

//设置菜单控件到logo的间距为80;
fm.config.menu_item_gap = 80;
//设置菜单样式为扇形菜单
fm.setMenuStyle(FloatMenu.TYPE_MENU_CIRCULAR);

fm.on('item_click', view => {
    showToast('item_click 点击了' + view.name);
});

fm.show();

let id = $autojs.keepRunning();