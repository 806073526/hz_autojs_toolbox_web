"nodejs ui";

const { showToast } = require("toast");
const FloatMenu = require("./@se7en/float_menu");

let fm = new FloatMenu();

//设置logo按钮
fm.getLogoView().setIcons('https://pro.autojs.org/images/logo.png').setColors('#FFFFFF');

let item = fm.addItem('按钮1');
//设置背景色
item.setColors('#7a0076ff', '#7aff3824')
    //设置图标颜色
    .setTints('#fafafa')
    //设置图标
    .setIcons('ic_play_arrow_black_48dp', 'ic_stop_black_48dp')
    //设置item样式
    .setStyle(FloatMenu.TYPE_ITEM_STYLE_CHECKBOX)
    //选中item
    .setChecked(true)
    //设置圆角
    .setRadius(10)
    //设置边框
    .setStroke(1, '#000000')
    .onClick(view => {
        showToast(`点击了 ${view.name} 是否选中 ${view.getChecked()}`);
        //是否保持菜单开启 没有返回值或者true保持开启 返回false菜单关闭
        return true;
    });

fm.addItem('按钮2').setColors('#00ff00').setIcons('icon_autojs_logo')
    .onClick(view => {
        showToast(`点击了 ${view.name} 菜单关闭`);
        return false;
    });

fm.addItem('按钮3').setColors('#00ff00').setIcons('icon_autojs_logo')
fm.addItem('按钮4').setColors('#00ff00').setIcons('icon_autojs_logo')

fm.addItem('退出')
    .setColors('#0000ff')
    .setTints('#fafafa')
    .setIcons('ic_exit_to_app_black_48dp')
    .onClick(view => {
        fm.close();
        showToast('软件退出');
        $autojs.cancelKeepRunning(id);
        process.exit();
    });

//fm.config.menu_item_gap = 80;
//fm.setMenuStyle(FloatMenu.TYPE_MENU_CIRCULAR);

fm.show();

let id = $autojs.keepRunning();
