'nodejs';

const FloatMenu = require("../index.node");
const AnimationFloat = require("../modules/animation_foat.node");
const { dp2px, status_bar_height, navigation_bar_height, float1 } = require("../modules/__util__.node");
const Window = require("../modules/__window__..node");
const MotionEvent = android.view.MotionEvent
const View = android.widget.View;

class LogoWindow extends Window {

    /**
     * logo悬浮球
     * @param {FloatMenu} fm 
     */
    constructor(fm) {
        super(fm);
        this.fm = fm;
        /** @type {AnimationFloat} */
        this.animator = null;
        init(this);
    }

    onViewCreated() {
        initLogoTouchEvent(this);
        return this.fm.getLogoViewGroup();
    }

    onWindowCreated() {
        initWindow(this);
    }

    show() {
        let that = this;
        return new Promise(function (resolve, reject) {
            that.animator.onAnimationEnd(function () {
                resolve(true);
            });
            that.fm.getLogoView().post(function () {
                that.animator.start();
            });
        });
    }

    hide() {
        let that = this;
        return new Promise(function (resolve, reject) {
            that.animator.onAnimationEnd(function () {
                resolve(true);
            })
            that.animator.reverse();
        });
    }

    updateWindowPosition() {
        initWindow(this);
    }
}

/**
 * 
 * @param {LogoWindow} scope 
 */
function init(scope) {
    let view = scope.fm.getLogoView();
    view.attr('visibility', 'invisible');
    view.post(function () {
        view.setTranslationX(-view.getWidth());
    });
    initAnimator(scope);
    initMarginAnimator(scope);
}

/**
 * 悬浮球显示隐藏动画
 * @param {LogoWindow} scope 
 */
function initAnimator(scope) {
    let animator = new AnimationFloat(scope.fm);
    let f, width, view;
    animator.onAnimationStart((animator, isReveres) => {
        view = scope.fm.getLogoView()
        width = -view.getWidth();
        if (!isReveres) {
            view.attr('visibility', 'visible');
        }
        scope.setTouchable(!isReveres);
    });
    animator.onAnimatoinUpdate(animator => {
        f = animator.getAnimatedValue();
        view.setTranslationX(width * (1 - f));
    })
    scope.animator = animator;
}

/**
 * 贴边动画
 * @param {LogoWindow} scope 
 */
function initMarginAnimator(scope) {
    let animator = new AnimationFloat(scope.fm);
    animator.setDuration(scope.fm.config.animator_duration_margin);
    //设置动画插值器
    animator.setInterpolator(new AnimationFloat.BounceInterpolator());
    let f, sx, sy, ex, ey, w, h, p, s, y;
    animator.onAnimationStart(() => {
        scope.fm.config.isAnimatedStart = true;
        sx = scope.getX();
        sy = scope.getY();
        p = dp2px(scope.fm.config.all_item_padding);
        s = dp2px(scope.fm.config.all_item_size);
        //计算在要贴边在哪个方向
        w = -scope.fm.config.width + s - p * 2;
        if (scope.fm.config.isLeftMargin = scope.fm.config.width / 2 > sx + s / 2) w = 0;
        //计算y轴是否超出屏幕范围或不可点击区域
        h = scope.fm.config.height - status_bar_height - navigation_bar_height;
        if (status_bar_height > sy) {
            y = -(status_bar_height * 2 - sy);
        } else if (h < sy + s) {
            y = sy + s - h;
        } else {
            y = 0;
        }
        ex = w + sx + p;
        ey = y;
        scope.fm.getLogoView().setAlpha(scope.fm.config.logoAlpha);
    });
    animator.onAnimationEnd(() => {
        //记录logo当前位置比例
        scope.fm.config.logoY = scope.getY() / scope.fm.config.height;
        scope.fm.config.isAnimatedStart = false;
        //贴边动画播放完后 更新menu菜单位置
        scope.fm.menuWindow.__style__.updateMenuWindow();
    })
    animator.onAnimatoinUpdate(animator => {
        f = animator.getAnimatedValue();
        scope.setPosition(sx - ex * f, sy - ey * f);
    });
    scope.margin_animator = animator;
}

/**
 * 
 * @param {LogoWindow} scope 
 */
function initWindow(scope) {
    if (!scope.isInit) return;
    scope.setSize(-2, -2);
    scope.setTouchable(true);
    console.log('initLogoWindow');
    let p = dp2px(scope.fm.config.all_item_padding);
    let s = dp2px(scope.fm.config.all_item_size);
    let w = scope.fm.config.width - s + p * 2;
    if (scope.fm.config.isLeftMargin) w = 0;
    //设置logo悬浮窗位置
    scope.setPosition(w - p, scope.fm.config.height * scope.fm.config.logoY);
    //更新menu悬浮窗位置;
    scope.fm.menuWindow.__style__.updateMenuWindow();
    //设置logo透明度
    scope.fm.getLogoView().setAlpha(scope.fm.config.logoAlpha);
}

/**
 * @param {LogoWindow} scope 
 */
function initLogoTouchEvent(scope) {
    let wx, wy, rx, ry, isMove;
    let lv = scope.fm.getLogoView();
    lv.setOnTouchListener((view, e) => {
        //如果动画正在播放 则跳过此次操作;
        if (scope.fm.config.isAnimatedStart) return true;
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN://手指按下
                isMove = false;
                rx = e.getRawX();
                ry = e.getRawY();
                wx = scope.getX();
                wy = scope.getY();
                lv.setAlpha(float1);
                break;
            case MotionEvent.ACTION_MOVE://手指移动
                if (!isMove && (Math.abs(e.getRawX() - rx) > 30 || Math.abs(e.getRawY() - ry) > 30)) {
                    isMove = true;
                } else if (isMove && !scope.fm.isOpen()) {
                    scope.setPosition(wx + e.getRawX() - rx, wy + e.getRawY() - ry);
                }
                break;
            case MotionEvent.ACTION_UP:
                if (isMove && !scope.fm.isOpen()) {
                    //播放贴边动画
                    scope.margin_animator.start();
                } else if (!isMove) {
                    if (scope.fm.isOpen()) {
                        //关闭菜单
                        scope.fm.setState(1);
                    } else {
                        //显示菜单
                        scope.fm.setState(2);
                    }
                }
                break;
        }
        return true;
    });
}

module.exports = LogoWindow;