"nodejs";

const FloatMenu = require('..');
const { defineValue, createJavaArray } = require('./__util__');
require('rhino').install();

const ValueAnimator = android.animation.ValueAnimator
const CycleInterpolator = android.view.animation.CycleInterpolator;
const BounceInterpolator = android.view.animation.BounceInterpolator;
const LinearInterpolator = android.view.animation.LinearInterpolator;
const AccelerateInterpolator = android.view.animation.AccelerateInterpolator;
const DecelerateInterpolator = android.view.animation.DecelerateInterpolator;
const AccelerateDecelerateInterpolator = android.view.animation.AccelerateDecelerateInterpolator;

const end = Symbol('callback');
const start = Symbol('callback');
const cancel = Symbol('callback');
const repeat = Symbol('callback');
const update = Symbol('callback');

/**
 * 创建动画
 * @param {FloatMenu} fm FloatMenu
 * @param {number=0} min 最小值 默认0;
 * @param {number=1} max 最大值 默认1;
 * @param {number=500} duration 动画执行时常 默认500;
 */
function AnimationFloat(fm, min = 0.0, max = 1.0, duration = 500) {
    this.fm = fm;
    let floatArr = createJavaArray('float', 2);
    floatArr[0] = min;
    floatArr[1] = max;
    this.animator = new ValueAnimator.ofFloat(floatArr);
    init(this);
    this.duration = duration;
}

/** 动画插值器 */
/** 动画从开始到结束，变化率是一个加速的过程。 */
AnimationFloat.AccelerateInterpolator = AccelerateInterpolator;
/** 动画从开始到结束，变化率是一个减速的过程。 */
AnimationFloat.DecelerateInterpolator = DecelerateInterpolator;
/** 动画从开始到结束，变化率是循环给定次数的正弦曲线。 */
AnimationFloat.CycleInterpolator = CycleInterpolator;
/** 动画从开始到结束，变化率是先加速后减速的过程。 */
AnimationFloat.AccelerateDecelerateInterpolator = AccelerateDecelerateInterpolator;
/** 动画从开始到结束，变化率是线性变化。 */
AnimationFloat.LinearInterpolator = LinearInterpolator;
AnimationFloat.BounceInterpolator = BounceInterpolator;

AnimationFloat.prototype = {
    /**
     * 动画更新时 调用此方法
     * @param {animation_update} callback 
     */
    onAnimatoinUpdate(callback) {
        if ('function' === typeof callback)
            this[update] = callback;
        return this;
    },
    /**
     * 动画启动时 调用此方法
     * @param {animation_start} callback 
     */
    onAnimationStart(callback) {
        if ('function' === typeof callback)
            this[start] = callback;
        return this;
    },
    /**
     * 动画停止时 调用此方法
     * @param {animation_end} callback 
     */
    onAnimationEnd(callback) {
        if ('function' === typeof callback)
            this[end] = callback;
        return this;
    },
    /**
     * 动画取消时 调用此方法
     * @param {animation_cancel} callback 
     */
    onAnimationCancel(callback) {
        if ('function' === typeof callback)
            this[cancel] = callback;
        return this;
    },
    /**
     * 动画重复时 调用此方法
     * @param {animation_repeat} callback 
     */
    onAnimationRepeat(callback) {
        if ('function' === typeof callback)
            this[repeat] = callback;
        return this;
    },
    /**
     * 设置动画插值器
     * @param {*} interpolator 
     */
    setInterpolator(interpolator) {
        this.interpolator = interpolator;
        return this;
    },
    /**
     * 设置动画运行时常
     * @param {number} duration 
     */
    setDuration(duration) {
        this.duration = duration;
        return this;
    },
    /** 播放动画 */
    start() {
        if (this.animator.isRunning()) {
            this.animator.cancel();
        }
        this.animator.start();
    },
    /** 反向播放动画 */
    reverse() {
        if (this.animator.isRunning()) {
            this.animator.cancel();
        }
        this.animator.reverse();
    },

    defineValue
}

/**
 * 
 * @param {AnimationFloat} scope 
 */
function init(scope) {
    defineValue(scope, 'duration', null, duration => {
        scope.animator.setDuration(duration);
    });
    defineValue(scope, 'interpolator', null, interpolator => {
        scope.animator.setInterpolator(interpolator);
    });

    scope[update] = new Function;
    scope[start] = new Function;
    scope[end] = new Function;
    scope[cancel] = new Function;
    scope[repeat] = new Function;

    scope.animator.addListener({
        onAnimationStart(animator, isReverse) {
            scope[start].apply(this, arguments);
        },
        onAnimationEnd(animator, isReverse) {
            scope[end].apply(this, arguments);
            scope.fm.emitter.emit('animation_end', animator, isReverse);
        },
        onAnimationCancel(animator) {
            scope[cancel].apply(this, arguments);
        },
        onAnimationRepeat(animator) {
            scope[repeat].apply(this, arguments);
        }
    });

    try {
        scope.animator.addUpdateListener({
            onAnimationUpdate(animator) {
                scope[update](animator);
            }
        });
    } catch (error) {
        console.log(error);
    }
}

//CallBack 动画回调方法
/**
 * 动画更新回调方法
 * @callback animation_update
 * @param {animation} animator Animator
 */
/**
 * 动画启动回调方法
 * @callback animation_start
 * @param {animation} animator Animator
 * @param {boolean} isReverse 动画是否反向播放
 */
/**
 * 动画停止回调方法
 * @callback animation_end
 * @param {animation} animator Animator
 * @param {boolean} isReverse 动画是否反向播放
 */
/**
 * 动画取消回调方法
 * @callback animation_cancel
 * @param {animation} animator Animator
 */
/**
 * 动画反向播放回调方法
 * @callback animation_repeat
 * @param {animation} animator Animator
 */

module.exports = AnimationFloat;


// class AnimationFloat {
//     constructor() {

//     }

//     /** 动画从开始到结束，变化率是一个加速的过程。 */
//     static AccelerateInterpolator = AccelerateInterpolator;
//     /** 动画从开始到结束，变化率是一个减速的过程。 */
//     static DecelerateInterpolator = DecelerateInterpolator;
//     /** 动画从开始到结束，变化率是循环给定次数的正弦曲线。 */
//     static CycleInterpolator = CycleInterpolator;
//     /** 动画从开始到结束，变化率是先加速后减速的过程。 */
//     static AccelerateDecelerateInterpolator = AccelerateDecelerateInterpolator;
//     /** 动画从开始到结束，变化率是线性变化。 */
//     static LinearInterpolator = LinearInterpolator;
//     static BounceInterpolator = BounceInterpolator;


// }
