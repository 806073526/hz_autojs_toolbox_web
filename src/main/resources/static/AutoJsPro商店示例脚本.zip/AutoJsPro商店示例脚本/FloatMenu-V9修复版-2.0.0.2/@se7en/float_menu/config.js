'nodejs';

const FloatMenu = require(".");
const { defineValue, isHorizontalScreen } = require("./modules/__util__");
const { device } = require('device');

class FloatConfig {

    /**
     * 悬浮球配置
     * @param {FloatMenu} fm 
     */
    constructor(fm) {
        this.fm = fm;
        init(this);
    }

    /** 所有按钮控件大小 (单位:dp) */
    all_item_size = 44;
    /** 所有按钮背景圆角 (单位:dp) */
    all_item_radius = -1;
    /** 所有按钮控件内边距 (单位:dp) */
    all_item_padding = 8;

    /** 菜单每个控件的间隔 水平样式:控件与控件的间距 扇形:控件与logo的间距 (单位:dp) */
    menu_item_gap = 10;
    /** 菜单控件点击缩放参数 0~1; */
    menu_item_scale = 0.8;

    /** 控件点击动画时间 */
    animator_duration_item = 230;
    /** logo显示动画时间 */
    animator_duration_show = 500;
    /** logo贴边动画时间 */
    animator_duration_margin = 500;
    /** 菜单展开动画时间 */
    animator_duration_open = 230;

    /** 
     * 扇形菜单展开角度 
     * @author 贡献者: I'm zz 大佬
     */
    angle = 180;
    /** logo按钮相对于屏幕所在位置的垂直比例*/
    logoY = 0.5;
    /** 是否在左侧边缘 */
    isLeftMargin = true;
    /** logo控件透明值 */
    logoAlpha = 0.5;

    //下方参数不要修改
    /** 是否正在播放动画 */
    isAnimatedStart = false;
    get width() {
        return device.screenWidth;
    }

    get height() {
        return device.screenHeight;
    }
}

/**
 * @param {FloatConfig} scope 
 */
function init(scope) {
    defineValue(scope, 'all_item_size', undefined, value => {
        scope.fm.getAllItemViews().forEach(iv => iv.setSize(value));
    });
    defineValue(scope, 'all_item_radius', undefined, value => {
        scope.fm.getAllItemViews().forEach(iv => iv.setRadius(value));
    });
    defineValue(scope, 'all_item_padding', undefined, value => {
        scope.fm.getAllItemViews().forEach(iv => iv.setPaddings(value));
    });
    defineValue(scope, 'menu_item_gap', undefined, value => {
        scope.fm.menuWindow.__style__.updateMenuPosition();
        scope.fm.menuWindow.__style__.updateMenuWindow();
    });
    defineValue(scope, 'menu_item_scale', undefined, value => {
        scope.fm.getItemViews().forEach(iv => iv.setAnimScaleValue(value));
    });
    defineValue(scope, 'isAnimatedStart', undefined, value => {
        let type = value ? 'animation_start' : 'animation_end';
        scope.fm.emitter.emit(type, value);
    });
    defineValue(scope, 'isLeftMargin', undefined, value => {
        scope.fm.getAllItemViews().forEach(iv => iv.attr('layout_gravity',
            (value ? 'left' : 'right') + '|center_vertical'
        ));
    });
    defineValue(scope, 'orientation', null, value => {
        if (scope.fm.logoWindow && scope.fm.logoWindow.isInit) {
            scope.fm.setState(1);
            scope.fm.logoWindow.updateWindowPosition();
        }
    });
    scope.orientation = isHorizontalScreen();

}


module.exports = FloatConfig;