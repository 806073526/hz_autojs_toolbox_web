'nodejs';

const FloatMenu = require("..");
const AnimationFloat = require("../modules/animation_foat");
const StyleMenu = require("../modules/__style_menu__");
const { defineValue, float1 } = require("../modules/__util__");
const Window = require("../modules/__window__");
const CircularMenu = require("../styles/circular_menu");
const HorizontalMenu = require("../styles/horizontal_menu");


class MenuWindow extends Window {

    /**
     * menu菜单
     * @param {FloatMenu} fm 
     */
    constructor(fm) {
        super(fm);
        this.fm = fm;
        /** @type {StyleMenu} */
        this.__style__ = null;
        this.isOpen = false;
        /** @type {AnimationFloat} */
        this.animator = null;
        init(this);
    }

    /** 扇形菜单样式 */
    static TYPE_MENU_CIRCULAR = CircularMenu;
    /** 水平菜单样式 */
    static TYPE_MENU_HORIZONTAL = HorizontalMenu;

    onViewCreated() {
        return this.fm.getMenuViewGroup();
    }

    onWindowCreated() {
        initWindow(this);
    }

    setMenuStyle(style) {
        this.style = style;
    }

    /**
     * 展开菜单
     */
    open() {
        let that = this;
        return new Promise(function (resolve, reject) {
            that.animator.onAnimationEnd(function () {
                that.fm.config.isAnimatedStart = false;
                that.setTouchable(true);
                resolve(true);
            })
            that.animator.start();
        });
    }

    /**
     * 隐藏菜单
     */
    hide() {
        let that = this;
        return new Promise(function (resolve, reject) {
            that.animator.onAnimationEnd(function () {
                that.fm.config.isAnimatedStart = false;
                that.fm.getMenuViewGroup().attr('visibility', 'invisible');
                that.fm.getLogoView().setAlpha(that.fm.config.logoAlpha);
                resolve(true);
            })
            that.animator.reverse();
        });
    }
}

/**
 * 
 * @param {MenuWindow} scope 
 */
function init(scope) {
    defineValue(scope, 'style', null, style => {
        scope.__style__ = new style(scope);
    });
    scope.style = MenuWindow.TYPE_MENU_HORIZONTAL;

    initMenuAnimator(scope);
}

/**@param {MenuWindow} scope */
function initMenuAnimator(scope) {
    let animator = new AnimationFloat(scope.fm);
    animator.setDuration(scope.fm.config.animator_duration_open);
    animator.onAnimatoinUpdate(animator => {
        scope.__style__.updateMenuAnimation(animator.getAnimatedValue());
    });
    animator.onAnimationStart(() => {
        scope.isOpen = !scope.isOpen;
        scope.fm.config.isAnimatedStart = true;

        if (scope.isOpen) {
            scope.fm.getLogoView().setAlpha(float1);
            scope.fm.getMenuViewGroup().attr('visibility', 'visible');
        } else
            scope.setTouchable(false);
    });
    scope.animator = animator;
}


/**
 * 
 * @param {MenuWindow} scope 
 */
function initWindow(scope) {
    scope.setSize(-2, -2);
    scope.setTouchable(false);
}

module.exports = MenuWindow;