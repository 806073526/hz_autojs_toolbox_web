
const MenuWindow = require("../windows/menu_window.node");

class StyleMenu {

    /**
     * @param {MenuWindow} window 
     */
    constructor(window) {
        this.window = window;
        this.fm = window.fm;
        this.config = this.fm.config;
    }

    /**
     * 更新菜单悬浮窗
     */
    updateMenuWindow() {
    }
    /**
     * 更新菜单坐标
     */
    updateMenuPosition() {
    }
    /**
     * 更新菜单动画
     */
    updateMenuAnimation(f) {
    }
}

module.exports = StyleMenu;