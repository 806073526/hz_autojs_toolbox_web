'nodejs';


require('rhino').install();
const Color = android.graphics.Color;
const GradientDrawable = android.graphics.drawable.GradientDrawable;

const resources = context.getResources();
const scale = resources.getDisplayMetrics().density;
const config = resources.getConfiguration();

const status_bar_height = resources.getDimensionPixelSize(
    resources.getIdentifier('status_bar_height', 'dimen', 'android')
);
const navigation_bar_height = resources.getDimensionPixelSize(
    resources.getIdentifier('navigation_bar_height', 'dimen', 'android')
);

function dp2px(dp) {
    return Math.floor(dp * scale + .5);
}

function px2dp(px) {
    return Math.floor(px / scale + .5);
}

function defineValue(obj, key, defval, changeCallback) {
    let value = defval || obj[key];
    let oldval;
    Object.defineProperty(obj, key, {
        get() {
            return value;
        },
        set(newval) {
            oldval = value;
            value = newval;
            if (newval !== oldval) {
                changeCallback(newval, oldval);
            }
        }
    });
}

/**
 * 创建样式
 * @param {numbar}      radius           圆角弧度 -1圆形
 * @param {number|null} shape            类型 null矩形
 * @param {string|null} fillcolor        颜色 null透明色
 * @param {Object}      stroke           描边参数 不需要描边可以忽略
 * @param {number}      stroke.width     线条宽度
 * @param {string}      stroke.color     线条颜色
 * @param {number}      stroke.dashWidth 虚线线宽
 * @param {number}      stroke.dashGap   虚线间隔
 */
function createShape(radius, shape, fillcolor, stroke) {
    radius = radius === -1 ? Number.MAX_VALUE : dp2px(radius);
    shape = shape || 0;
    let gd = new GradientDrawable();
    gd.setCornerRadius(radius);
    gd.setShape(shape);
    if (fillcolor) {
        gd.setColor(Color.parseColor(fillcolor));
    }
    if (stroke) {
        stroke = Object.assign({
            width: 0,
            color: Color.TRANSPARENT,
            dashWidth: 0,
            dashGap: 0
        }, stroke);
        if ('string' === typeof stroke.color) {
            stroke.color = Color.parseColor(stroke.color);
        }
        gd.setStroke(stroke.width, stroke.color, stroke.dashWidth, stroke.dashGap);
    }
    return gd;
}

function typeToClass(type) {
    if (typeof (type) != 'string') {
        return type;
    }
    if (type == 'string') {
        return java.lang.String;
    }
    var types = {
        "int": "Integer",
        "long": "Long",
        "double": "Double",
        "char": "Character",
        "byte": "Byte",
        "float": "Float"
    };

    if (types[type]) {
        return Packages["java.lang." + types[type]].TYPE;
    }
    return Packages[type];
}

function createJavaArray(type) {
    var clazz = typeToClass(type);
    var args = arguments;
    args[0] = clazz;
    return java.lang.reflect.Array.newInstance.apply(null, args);
}

/**
 * 是否横屏
 */
function isHorizontalScreen() {
    return config.orientation === 2;
}



module.exports = {
    resources,
    status_bar_height,
    navigation_bar_height,
    defineValue,
    createShape,
    dp2px,
    px2dp,
    createJavaArray,
    isHorizontalScreen,
    float1: new java.lang.Float(1.0)
}