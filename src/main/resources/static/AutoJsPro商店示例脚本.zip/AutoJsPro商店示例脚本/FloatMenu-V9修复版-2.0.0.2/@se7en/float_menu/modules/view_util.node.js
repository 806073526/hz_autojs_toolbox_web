'nodejs';

require('rhino').install();
const { defaultThemeContext } = require('ui');
const ItemView = require("../widgets/item_view.node");

const { EventEmitter } = require('events');
const FloatConfig = require('../config.node');
const itemViews = Symbol();
const logoView = Symbol();
const logoGroup = Symbol();
const menuGroup = Symbol();

class ViewUtil {

    constructor() {
        /** @type {Array.<ItemView>} */
        this[itemViews] = [];
        /** @type {ItemView} */
        this[logoView] = null;
        this.emitter = new EventEmitter();
        /** @type {FloatConfig} */
        this.config = new FloatConfig(this);
        init(this);
    }

    /**
     * 创建一个控件并添加到菜单指定位置
     *      
     *      //创建一个控件并添加到菜单最后面
     *      var item = fm.addItem('按钮1');
     * @param {string} name 控件名称
     * @param {number = -1} index 控件位置 默认-1
     * @returns {ItemView} 
     */
    addItem(name, index = -1) {
        let view = this.getItem(name);
        if (view) return view;
        //创建ItemView;
        view = new ItemView(this, name);
        //添加到菜单
        this[menuGroup].addView(view, index);
        if (index === -1) index = this[itemViews].length;
        this[itemViews].splice(index, 0, view);
        //更新菜单item坐标
        this.menuWindow.__style__.updateMenuPosition();
        //更新item重力位置
        view.attr('layout_gravity',
            (this.config.isLeftMargin ? 'left' : 'right') + '|center_vertical'
        );
        return view;
    }

    /**
     * 控件是否存在
     * @param {string} name 按钮名称
     */
    hasItem(name) {
        return !!this.getItem(name);
    }

    /**
     * 获取指定控件
     * @param {string} name 控件名称
     * @returns {ItemView|null}
     */
    getItem(name) {
        return this.getItemViews().find(iv => iv.name === name);
    }

    /**
     * 获取logo控件
     */
    getLogoView() {
        return this[logoView];
    }

    /**
     * 获取logoViewGroup
     */
    getLogoViewGroup() {
        return this[logoGroup];
    }

    /** 
     * 获取菜单ViewGroup
     */
    getMenuViewGroup() {
        return this[menuGroup];
    }

    /**
     * 获取菜单ItemView集合
     */
    getItemViews() {
        return this[itemViews];
    }

    /**
     * 获取所有ItemView控件包括LogoView
     * @returns {Array.<ItemView>}
     */
    getAllItemViews() {
        return this[itemViews].concat(this[logoView]);
    }
}

/**
 * @param {ViewUtil} scope 
 */
function init(scope) {
    let lv = new android.widget.FrameLayout(defaultThemeContext());
    let lvparams = new android.widget.FrameLayout.LayoutParams(-1, -1);
    lv.setLayoutParams(lvparams);
    scope[logoGroup] = lv;
    let mv = new android.widget.FrameLayout(defaultThemeContext());
    let mvparams = new android.widget.FrameLayout.LayoutParams(-1, -1);
    mv.setLayoutParams(mvparams);
    scope[menuGroup] = mv;
    mv.attr('visibility', 'invisible');
    let iv = new ItemView(scope, 'logo');
    iv.setIcons('icon_autojs_logo').setColors('#fafafa');
    scope[logoView] = iv;
    scope[logoGroup].addView(iv);
}

module.exports = ViewUtil;