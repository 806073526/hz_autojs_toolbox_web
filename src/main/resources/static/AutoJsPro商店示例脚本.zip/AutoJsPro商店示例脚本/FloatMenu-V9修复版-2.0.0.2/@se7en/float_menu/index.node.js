'nodejs';

const ViewUtil = require("./modules/view_util.node");
const { EventEmitter } = require("events");
const { defineValue, isHorizontalScreen, resources } = require("./modules/__util__.node");
const LogoWindow = require("./windows/logo_window.node");
const MenuWindow = require("./windows/menu_window.node");
const ItemView = require("./widgets/item_view.node");

const state = Symbol();

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};


class FloatMenu extends ViewUtil {
    
    /**
     * 悬浮菜单-V9引擎
     * @author 大柒Se7en
     * @version 1.0.0
     * @description 此模块仅支持autojs pro 9016以上V9引擎使用
     */
    constructor() {
        super();
        this.menuWindow = new MenuWindow(this);
        this.logoWindow = new LogoWindow(this);
        init(this);
    }

    /** 悬浮球状态 关闭 */
    static STATE_CLOSED = -1
    /** 悬浮球状态 隐藏 */
    static STATE_HIDE = 0
    /** 悬浮球状态 显示 */
    static STATE_SHOW = 1
    /** 悬浮球状态 展开 */
    static STATE_OPEN = 2

    /** 菜单样式 扇形菜单 */
    static TYPE_MENU_CIRCULAR = MenuWindow.TYPE_MENU_CIRCULAR;
    /** 菜单样式 水平菜单 */
    static TYPE_MENU_HORIZONTAL = MenuWindow.TYPE_MENU_HORIZONTAL;

    /** 控件样式 按钮 */
    static TYPE_ITEM_STYLE_BUTTON = ItemView.TYPE_ITEM_STYLE_BUTTON;
    /** 控件样式 复选框 */
    static TYPE_ITEM_STYLE_CHECKBOX = ItemView.TYPE_ITEM_STYLE_CHECKBOX;

    /**
     * 显示悬浮球
     */
    show() {
        this.setState(FloatMenu.STATE_SHOW);
    }

    /**
     * 隐藏悬浮球
     */
    hide() {
        this.setState(FloatMenu.STATE_HIDE);
    }

    /**
     * 关闭悬浮球
     */
    close() {
        this.setState(FloatMenu.STATE_CLOSED);
    }

    /**
     * 展开菜单
     */
    open() {
        this.setState(FloatMenu.STATE_OPEN);
    }

    /**
     * 悬浮球是否显示
     */
    isShow() {
        return this.getState() === FloatMenu.STATE_SHOW;
    }

    /**
     * 菜单是否展开
     */
    isOpen() {
        return this.getState() === FloatMenu.STATE_OPEN;
    }

    /**
     * 设置悬浮球状态
     * @param {numbar} value 
     */
    setState(value) {
        this[state] = value;
    }

    /**
     * 获取悬浮球状态
     */
    getState() {
        return this[state]
    }

    /**
     * 设置菜单样式
     * @param {class} style 
     */
    setMenuStyle(style) {
        this.menuWindow.setMenuStyle(style);
    }

    /**
     * @callback ItemViewOnClickCallback
     * @param {ItemView} view
     * @returns {boolean=} 是否关闭菜单 没有返回值或者返回true保持菜单开启,返回false关闭菜单
     */

    /**
     * @param {string} type 事件名称
     * @param {ItemViewOnClickCallback} callback 回调方法
     * @returns 
     */
    on(type, callback) {
        return this.emitter.on.apply(this.emitter, arguments);
    }

}

/**
 * @param {FloatMenu} scope 
 */
async function init(scope) {
    defineValue(scope, state, FloatMenu.STATE_CLOSED, (cunrrentstate, previousstate) => {
        scope.emitter.emit('state_changed', cunrrentstate, previousstate);
    });

    //状态改变成悬浮窗关闭
    scope.on('state_changed', (cunrrentstate, previousstate) => {
        return __awaiter(this, void 0, void 0, function* () {
            if (cunrrentstate !== FloatMenu.STATE_CLOSED)
                return
            switch (previousstate) {
                case FloatMenu.STATE_OPEN:
                // yield scope.menuWindow.hide();
                case FloatMenu.STATE_SHOW:
                // yield scope.logoWindow.hide();
                case FloatMenu.STATE_HIDE:
                    scope.logoWindow.close();
                    scope.menuWindow.close();
            }
        });
    });

    //状态改变成悬浮球隐藏
    scope.on('state_changed', (cunrrentstate, previousstate) => {
        return __awaiter(this, void 0, void 0, function* () {
            if (cunrrentstate !== FloatMenu.STATE_HIDE)
                return
            switch (previousstate) {
                case FloatMenu.STATE_CLOSED:
                    scope.menuWindow.init();
                    scope.logoWindow.init();
                    break;
                case FloatMenu.STATE_OPEN:
                    yield scope.menuWindow.hide();
                case FloatMenu.STATE_SHOW:
                    yield scope.logoWindow.hide();
            }
        });
    });

    //状态改变成悬浮球显示
    scope.on('state_changed', (cunrrentstate, previousstate) => {
        return __awaiter(this, void 0, void 0, function* () {
            if (cunrrentstate !== FloatMenu.STATE_SHOW)
                return
            switch (previousstate) {
                case FloatMenu.STATE_CLOSED:
                    scope.menuWindow.init();
                    scope.logoWindow.init();
                case FloatMenu.STATE_HIDE:
                    yield scope.logoWindow.show();
                    break;
                case FloatMenu.STATE_OPEN:
                    yield scope.menuWindow.hide();
                    break;
            }
        });
    });

    //状态改变成菜单开启
    scope.on('state_changed', (cunrrentstate, previousstate) => {
        return __awaiter(this, void 0, void 0, function* () {
            if (cunrrentstate !== FloatMenu.STATE_OPEN)
                return
            switch (previousstate) {
                case FloatMenu.STATE_CLOSED:
                    scope.menuWindow.init();
                    scope.logoWindow.init();
                case FloatMenu.STATE_HIDE:
                    yield scope.logoWindow.show();
                case FloatMenu.STATE_SHOW:
                    yield scope.menuWindow.open();
            }
        });
    });

    process.on('exit', function () {
        scope.close();
    });

    //监听屏幕旋转
    setInterval(() => {
        scope.config.orientation = isHorizontalScreen();
    }, 1e3);

}

module.exports = FloatMenu;