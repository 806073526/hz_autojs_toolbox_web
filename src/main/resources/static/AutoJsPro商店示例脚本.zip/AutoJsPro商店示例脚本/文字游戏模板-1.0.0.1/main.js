/*
QQ:3177459839
只是普通的文字游戏模板，进度后退那个内容互换位置就行了
第一次发这个，做的不是太好，就光模板用就行了
例子：
if(内容id == "内容1"){
内容2
}
*/
"ui";
ui.statusBarColor(colors="#000000");
ui.layout(    
<frame bg="#faf0e6">(
 <img id="空白图" scaleType="fitXY" src="file:///storage/emulated/0/脚本/文字游戏模板/空白图.png"/>    
//复制   alpha="0.3"改变透明度↓↓↓            
<text id="内容" text="开始游戏" textColor="#000000" bg="#804000" textSize="20sp"h="80" layout_gravity="bottom" margin="10"/>
<linear gravity="right">
<button id="上一句" text="∧" textSize="18" textColor="#ff0000" style="Widget.AppCompat.Button.Borderless.Colored" layout_gravity="bottom|right" w="40" h="40"/>
<button id="下一句" text="∨" textSize="16" textColor="#ff0000" style="Widget.AppCompat.Button.Borderless.Colored" layout_gravity="bottom|right" w="40" h="40"/>
</linear>
)
</frame>
);
//进度前进
ui.下一句.click(function(){                
var 内容 = ui.内容.getText();
if(内容 == "开始游戏"){
ui.内容.setText("1");

}
if(内容 == "1"){
ui.内容.setText("2");
//图片自己找↓  
 ui.空白图.setSource("file:///storage/emulated/0/.png");     
}
if(内容 == "2"){
ui.内容.setText("3"); 
ui.空白图.setSource("file:///storage/emulated/0/.png");      
}
});
//进度后退
ui.上一句.click(function(){                
var 内容 = ui.内容.getText();
if(内容 == "1"){
ui.内容.setText("开始游戏"); 
     
}
if(内容 == "2"){
ui.内容.setText("1");
ui.空白图.setSource("file:///storage/emulated/0/.png");       
}
if(内容 == "3"){
ui.内容.setText("2");
ui.空白图.setSource("file:///storage/emulated/0/.png"); 
}
});
                    
//强制横屏↓↓↓↓↓
function orientation(integer) {
    if (ui == null) {
        return;
    }
activity.setRequestedOrientation(integer);
}
//此处比大小公式↓↓↓
var i= 0;
var l= 0;
if(i==l){
  orientation(0);
}