"ui";

/**
 * 极简风UI模板 By浩然AN
 * 
 * 2022.7.2
 */

importClass(android.widget.SeekBar);
importClass(android.text.TextWatcher);
importClass(android.os.Build)
importClass(android.view.WindowManager)


$ui.useAndroidResources();
activity.theme.applyStyle($ui.R.style.MainTheme, true);

var color = "#3399ff";
var color3 = "#2288ff"
$ui.layout(
    <drawer id="drawer">
        <vertical>
            <appbar bg="{{color}}">
                <toolbar id="toolbar" title="UI模板"/>
                <tabs id="tabs"/>
            </appbar>
            <viewpager id="viewpager">
                <vertical h="*">
                    <scroll layout_weight="1">
                        <vertical padding="16dp">
                            <vertical bg="@drawable/radius_16_gray" padding="12dp">
                                <horizontal gravity="center_vertical">
                                    <text textSize="20dp" text="Card" textColor="{{color3}}" marginLeft="8dp"/>
                                    <frame layout_weight="1">
                                    </frame>
                                    <button style="Widget.AppCompat.Button.Borderless.Colored" id="verify" text="验证"/>
                                </horizontal>
                                <horizontal>
                                    <text textSize="15sp" text="验证结果  " marginLeft="10dp"/>
                                    <text textSize="15sp" id="verifyResult" text="未验证" textColor="#222222"/>
                                </horizontal>
                                <horizontal marginTop="2dp">
                                    <text textSize="15sp" text="有效期  " marginLeft="10dp"/>
                                    <text textSize="15sp" id="validity" text="UNKNOWN" textColor="#222222"/>
                                </horizontal>
                                <horizontal gravity="center" marginTop="6dp">
                                    <input password="true" layout_weight="1" bg="@drawable/input" id="card"/>
                                    <button style="Widget.AppCompat.Button.Borderless.Colored" id="paste" text="粘贴"/>
                                </horizontal>
                            </vertical>
                            <vertical bg="@drawable/radius_16_gray" padding="12dp" marginTop="16dp">
                                <horizontal gravity="center_vertical">
                                    <text textSize="20dp" text="Device" textColor="{{color3}}" marginLeft="8dp"/>
                                    <frame layout_weight="1" h="44dp">
                                    </frame>
                                </horizontal>
                                <horizontal marginTop="2dp">
                                    <text textSize="15sp" text="分辨率  " marginLeft="10dp"/>
                                    <text textSize="15sp" text="{{deviceWh()}}" textColor="#222222"/>
                                </horizontal>
                                <horizontal marginTop="2dp">
                                    <text textSize="15sp" text="设备名  " marginLeft="10dp"/>
                                    <text textSize="15sp" text="{{deviceName()}}" textColor="#222222"/>
                                </horizontal>
                                <horizontal marginTop="2dp">
                                    <text textSize="15sp" text="安卓系统  " marginLeft="10dp"/>
                                    <text textSize="15sp" text="{{device.release}}" textColor="#222222"/>
                                </horizontal>
                                <horizontal marginTop="2dp" marginBottom="4dp">
                                    <text textSize="15sp" text="Root权限  " marginLeft="10dp"/>
                                    <text textSize="15sp" text="无" textColor="#222222"/>
                                </horizontal>
                            </vertical>
                            <vertical paddingBottom="20dp" bg="@drawable/radius_16_gray" paddingRight="20dp" paddingTop="12dp" paddingLeft="20dp" marginTop="16dp">
                                <horizontal gravity="center_vertical">
                                    <text textSize="20dp" text="Option" textColor="{{color3}}"/>
                                    <frame layout_weight="1">
                                    </frame>
                                    <button style="Widget.AppCompat.Button.Borderless.Colored" id="save" text="保存"/>
                                </horizontal>
                                <text marginBottom="4dp" textSize="16sp" text="拖动条" textColor="#444444" marginTop="4dp"/>
                                <horizontal marginLeft="6dp" marginRight="6dp" marginTop="4dp">
                                    <vertical>
                                        <horizontal gravity="center_vertical" h="30sp" layout_gravity="center_vertical">
                                            <frame layout_weight="1"/>
                                            <text marginRight="6dp" textSize="15sp" text="价格:"/>
                                            <text id="price" textSize="16sp" text="&gt;10¥" textColor="#222222">
                                            </text>
                                        </horizontal>
                                        <horizontal gravity="center_vertical" h="30sp" layout_gravity="center_vertical">
                                            <frame layout_weight="1"/>
                                            <text marginRight="6dp" textSize="15sp" text="距离:"/>
                                            <text id="take" textSize="16sp" text="{{disTip(2)}}" textColor="#222222">
                                            </text>
                                        </horizontal>
                                        <horizontal gravity="center_vertical" h="30sp" layout_gravity="center_vertical">
                                            <frame layout_weight="1"/>
                                            <text marginRight="6dp" textSize="15sp" text="距离:"/>
                                            <text id="send" textSize="16sp" text="{{disTip(3)}}" textColor="#222222">
                                            </text>
                                        </horizontal>
                                    </vertical>
                                    <vertical layout_weight="1">
                                        <seekbar id="priceBar" h="30sp"/>
                                        <seekbar id="takeBar" h="30sp"/>
                                        <seekbar id="sendBar" h="30sp"/>
                                    </vertical>
                                </horizontal>
                                <text textSize="16sp" marginBottom="4dp" text="单选框" textColor="#444444" marginTop="14dp"/>
                                <radiogroup>
                                    <radio id="opSlide" text="模拟滑动"/>
                                    <radio id="opClick" text="模拟点击"/>
                                    <radio id="opPerson" text="提示人工操作"/>
                                </radiogroup>
                                <text textSize="16sp" marginBottom="4dp" text="多选框" textColor="#444444" marginTop="14dp"/>
                                <horizontal>
                                    <checkbox id="priBs" marginRight="6dp" text="选项1"/>
                                    <checkbox id="priXq" marginRight="6dp" text="选项2"/>
                                    <checkbox id="priZd" marginRight="6dp" text="选项3"/>
                                    <checkbox id="priDg" text="蛋糕"/>
                                </horizontal>
                                <text textSize="16sp" marginBottom="4dp" text="开关" textColor="#444444" marginTop="14dp"/>
                                <horizontal marginTop="4dp">
                                    <Switch id="moreProtect"/>
                                    <text text="防封防检测"/>
                                </horizontal>
                                <horizontal marginTop="4dp">
                                    <Switch id="moreSingle"/>
                                    <text text="只运行一次"/>
                                </horizontal>
                                <horizontal marginTop="4dp">
                                    <Switch id="moreShowConsole"/>
                                    <text text="显示控制台"/>
                                </horizontal>
                                <horizontal marginTop="4dp">
                                    <Switch id="moreRecord"/>
                                    <text text="记录运行情况"/>
                                </horizontal>
                                <horizontal marginTop="4dp">
                                    <Switch id="moreRoot"/>
                                    <text text="使用Root权限"/>
                                </horizontal>
                            </vertical>
                            <vertical padding="12dp" bg="@drawable/radius_16_gray" marginTop="16dp">
                                <horizontal gravity="center_vertical">
                                    <text textSize="20dp" text="Contact" textColor="{{color3}}" marginLeft="8dp"/>
                                    <frame layout_weight="1"/>
                                    <button style="Widget.AppCompat.Button.Borderless.Colored" id="jump" text="跳转"/>
                                </horizontal>
                                <horizontal marginTop="2dp">
                                    <text textSize="15sp" text="联系QQ  " marginLeft="10dp"/>
                                    <text id="qq" textSize="15sp" text="UNKNOWN" textColor="#222222"/>
                                </horizontal>
                            </vertical>
                        </vertical>
                    </scroll>
                    <vertical padding="16dp">
                        <frame id="start" h="42dp" bg="@drawable/radius_ripple_blue">
                            <text text="开始" gravity="center" textColor="{{color}}" textSize="18sp"/>
                        </frame>
                        <frame id="stop" h="42dp" bg="@drawable/radius_ripple_gray" marginTop="16dp" marginBottom="6dp">
                            <text text="停止" gravity="center" textColor="#888888" textSize="18sp"/>
                        </frame>
                    </vertical>
                </vertical>
                <frame>
                    <text textSize="20sp" gravity="center" text="只可意会，不可言传。" layout_gravity="center" textColor="black"/>
                </frame>
                <frame>
                    <vertical padding="64dp" h="auto">
                        <checkbox id="debugMode" text="调试模式"/>
                        <checkbox id="saveLog" text="日志缓存"/>
                        <button id="toDebugDir" text="查看调试输出目录" style="Widget.AppCompat.Button.Colored"/>
                        <horizontal>
                            <text text="调试任务"/>
                            <input id="debugTask" layout_weight="1"/>
                        </horizontal>
                        <text text="本地储存" marginTop="64dp"/>
                        <button id="showRecord" text="查看恒定识别参数" style="Widget.AppCompat.Button.Colored"/>
                        <button id="clearRecord" text="清除恒定识别参数"/>
                        <horizontal>
                            <input id="getKey" layout_weight="1"/>
                            <button id="doGet" text="读取" style="Widget.AppCompat.Button.Borderless.Colored" w="auto"/>
                        </horizontal>
                        <horizontal>
                            <input id="setKey" layout_weight="1"/>
                            <input id="setValue" layout_weight="1"/>
                            <button id="doSet" text="写入" style="Widget.AppCompat.Button.Borderless.Colored" w="auto"/>
                        </horizontal>
                    </vertical>
                </frame>
            </viewpager>
        </vertical>
        <vertical layout_gravity="left" bg="#ffffff" w="280">
            <img w="280" h="200" scaleType="fitXY" src="file://./images/background.png"/>
            <list id="menu">
                <horizontal bg="?selectableItemBackground" w="*">
                    <img w="50" h="50" padding="16" src="{{this.icon}}" tint="{{color}}"/>
                    <text textColor="black" textSize="15sp" text="{{this.title}}" layout_gravity="center"/>
                </horizontal>
            </list>
        </vertical>
    </drawer>
)

//BindSdcard-Init&Save
var uiStorage = storages.create("STORAGE_UI_VALUE");
$ui.emitter.on("resume",()=>{
    initUiValue();
});
$ui.emitter.on("pause",()=>{
    saveUiValue();
});
initUiValue();
function initUiValue(){
    $ui.saveLog.setChecked(uiStorage.get("saveLog",false));
    $ui.debugMode.setChecked(uiStorage.get("debugMode",false));
    $ui.moreRoot.setChecked(uiStorage.get("moreRoot",false));
    $ui.moreRecord.setChecked(uiStorage.get("moreRecord",true));
    $ui.moreShowConsole.setChecked(uiStorage.get("moreShowConsole",false));
    $ui.moreSingle.setChecked(uiStorage.get("moreSingle",true));
    $ui.moreProtect.setChecked(uiStorage.get("moreProtect",true));
    $ui.priDg.setChecked(uiStorage.get("priDg",false));
    $ui.priZd.setChecked(uiStorage.get("priZd",false));
    $ui.priXq.setChecked(uiStorage.get("priXq",true));
    $ui.priBs.setChecked(uiStorage.get("priBs",true));
    $ui.opPerson.setChecked(uiStorage.get("opPerson",false));
    $ui.opClick.setChecked(uiStorage.get("opClick",false));
    $ui.opSlide.setChecked(uiStorage.get("opSlide",true));
    $ui.sendBar.setProgress(uiStorage.get("sendBar",60));
    $ui.takeBar.setProgress(uiStorage.get("takeBar",40));
    $ui.priceBar.setProgress(uiStorage.get("priceBar",30));
    $ui.card.setText(uiStorage.get("card",""));
    $ui.qq.setText(getQQ());
}
function saveUiValue(){
    uiStorage.put("saveLog",$ui.saveLog.checked);
    uiStorage.put("debugMode",$ui.debugMode.checked);
    uiStorage.put("moreRoot",$ui.moreRoot.checked);
    uiStorage.put("moreRecord",$ui.moreRecord.checked);
    uiStorage.put("moreShowConsole",$ui.moreShowConsole.checked);
    uiStorage.put("moreSingle",$ui.moreSingle.checked);
    uiStorage.put("moreProtect",$ui.moreProtect.checked);
    uiStorage.put("priDg",$ui.priDg.checked);
    uiStorage.put("priZd",$ui.priZd.checked);
    uiStorage.put("priXq",$ui.priXq.checked);
    uiStorage.put("priBs",$ui.priBs.checked);
    uiStorage.put("opPerson",$ui.opPerson.checked);
    uiStorage.put("opClick",$ui.opClick.checked);
    uiStorage.put("opSlide",$ui.opSlide.checked);
    uiStorage.put("sendBar",$ui.sendBar.getProgress());
    uiStorage.put("takeBar",$ui.takeBar.getProgress());
    uiStorage.put("priceBar",$ui.priceBar.getProgress());
    uiStorage.put("card",$ui.card.text());
}

//Bind-Connect saveLog
$ui.saveLog.on("check",(checked)=>{
    uiStorage.put("saveLog",$ui.saveLog.checked);
});
//Bind-Connect debugMode
$ui.debugMode.on("check",(checked)=>{
    uiStorage.put("debugMode",$ui.debugMode.checked);
});
//Bind-Connect moreRoot
$ui.moreRoot.on("check",(checked)=>{
    uiStorage.put("moreRoot",$ui.moreRoot.checked);
});
//Bind-Connect moreRecord
$ui.moreRecord.on("check",(checked)=>{
    uiStorage.put("moreRecord",$ui.moreRecord.checked);
});
//Bind-Connect moreShowConsole
$ui.moreShowConsole.on("check",(checked)=>{
    uiStorage.put("moreShowConsole",$ui.moreShowConsole.checked);
});
//Bind-Connect moreSingle
$ui.moreSingle.on("check",(checked)=>{
    uiStorage.put("moreSingle",$ui.moreSingle.checked);
});
//Bind-Connect moreProtect
$ui.moreProtect.on("check",(checked)=>{
    uiStorage.put("moreProtect",$ui.moreProtect.checked);
});
//Bind-Connect priDg
$ui.priDg.on("check",(checked)=>{
    uiStorage.put("priDg",$ui.priDg.checked);
});
//Bind-Connect priZd
$ui.priZd.on("check",(checked)=>{
    uiStorage.put("priZd",$ui.priZd.checked);
});
//Bind-Connect priXq
$ui.priXq.on("check",(checked)=>{
    uiStorage.put("priXq",$ui.priXq.checked);
});
//Bind-Connect priBs
$ui.priBs.on("check",(checked)=>{
    uiStorage.put("priBs",$ui.priBs.checked);
});
//Bind-Connect opPerson
$ui.opPerson.on("check",(checked)=>{
    uiStorage.put("opPerson",$ui.opPerson.checked);
});
//Bind-Connect opClick
$ui.opClick.on("check",(checked)=>{
    uiStorage.put("opClick",$ui.opClick.checked);
});
//Bind-Connect opSlide
$ui.opSlide.on("check",(checked)=>{
    uiStorage.put("opSlide",$ui.opSlide.checked);
});
//Bind-Connect sendBar
$ui.sendBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener({onProgressChanged : function(bar,i,isFromUser){
    let progress = $ui.sendBar.getProgress();
    uiStorage.put("sendBar",progress);
    $ui.send.setText(disTip(progress/10));
}}));
//Bind-Connect takeBar
$ui.takeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener({onProgressChanged : function(bar,i,isFromUser){
    let progress = $ui.takeBar.getProgress();
    uiStorage.put("takeBar",progress);
    $ui.take.setText(disTip(progress/10));
}}));
//Bind-Connect priceBar
$ui.priceBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener({onProgressChanged : function(bar,i,isFromUser){
    let progress = $ui.priceBar.getProgress();
    uiStorage.put("priceBar",progress);
    let price = parseInt(progress/2);
    if(price<2){
        $ui.price.setText("无限制");
    }else{
        $ui.price.setText(">"+price+"¥");
    }
}}));
//Bind-Connect card
$ui.card.addTextChangedListener(new TextWatcher({afterTextChanged : function(s){
    uiStorage.put("card",$ui.card.text());
}}));


//创建选项菜单(右上角)
$ui.emitter.on("create_options_menu", menu => {
    menu.add("设置");
    menu.add("关于");
});
//设置toolbar
activity.setSupportActionBar($ui.toolbar);
//设置滑动页面的标题
$ui.viewpager.setTitles(["设置", "说明", "调试"]);
//让滑动页面和标签栏联动
$ui.tabs.setupWithViewPager($ui.viewpager);
//让工具栏左上角可以打开侧拉菜单
$ui.toolbar.setupWithDrawer($ui.drawer);
//设置状态栏颜色
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
    let window = activity.getWindow();
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
    window.setStatusBarColor(colors.parseColor(color));
    window.setNavigationBarColor(colors.parseColor(color));
}

//触发事件
$ui.menu.setDataSource([{
        title: "无障碍权限",
        icon: "@drawable/ic_android_black_48dp"
    },
    {
        title: "检查更新",
        icon: "@drawable/ic_settings_black_48dp"
    },
    {
        title: "续购卡密",
        icon: "@drawable/ic_favorite_black_48dp"
    },
    {
        title: "退出",
        icon: "@drawable/ic_exit_to_app_black_48dp"
    }
]);
//menu菜单点击事件
$ui.menu.on("item_click", item => {
    switch (item.title) {
        case "退出":
            saveUiValue()
            $ui.finish();
            break;
        case "检查更新":
            // TODO
            toastLog("已是最新版")
            break;
        case "续购卡密":
            // TODO
            break;
        case "无障碍权限":
            try{
                auto()
            }catch(e){}
            break;
        
        
    }
})

$ui.paste.click(()=>{
    $ui.card.setText(getClip());
});
$ui.verify.click(()=>{
    if(checkSecret()){
        toastLog("验证成功");
        $ui.verifyResult.setText("成功");
        $ui.validity.setText("UNKNOWN");
    }else{
        toastLog("验证失败");
        $ui.verifyResult.setText("已过期");
        $ui.validity.setText("UNKNOWN");
    }
});
$ui.save.click(()=>{
    saveUiValue()
});
$ui.jump.click(()=>{
    toQQ(getQQ())
});
$ui.jump.longClick(()=>{
    rawInput("编辑联系方式QQ", getQQ()).then(qq => {
        if(qq){
            setQQ(qq)
            toastLog("联系方式已更新 " + qq);
        }
    });
})

//运行停止
var runThread = null
$ui.stop.on("click", () => {
    if (runThread) {
        runThread.forceStop()
        runThread = null
        toastLog("已停止")
    } else {
        toastLog("没有运行中的脚本")
    }
});
$ui.start.on("click", () => {
    if (!checkSecret()) {
        return null
    }
    saveUiValue()
    if (runThread) {
        runThread.forceStop()
        runThread = null
    }
    if (checkSecret($ui.password.text())) {
        engines.execScriptFile("./start.js")
    }
});

$ui.toDebugDir.click(()=>{
    alert(uiStorage.get("debugDir","/sdcard/Script/debug"));
})
$ui.doGet.click(()=>{
    let key = $ui.getKey.text();
    alert(uiStorage.get(key))
});
$ui.doSet.click(()=>{
    let key = $ui.setKey.text();
    let value = $ui.setValue.text();
    uiStorage.put(key,value);
    toastLog("写入完成")
})



// 功能函数
function setQQ(qq) {
    uiStorage.put("qq", qq)
    return $ui.qq.setText(qq)
}
function getQQ() {
    return uiStorage.get("qq", "2125764918")
}
function toQQ(qq) {
    app.startActivity({
        action: "android.intent.action.VIEW",
        data: "mqqapi://card/show_pslcard?&uin="+qq
    });
}

function deviceName() {
    return device.brand + " " + device.model
}
function deviceWh() {
    return device.width + "x" + device.height
}

function disTip(km) {
    if(km>9.8)return "无限制"
    km = km + "";
    if(km.length<3)km=km+".0"
    return "<" + km + "km"
}
function testCheck() {
    if (checkCard()) {
        toastLog("卡密验证成功")
    }
}
function checkCard() {
    let card = $ui.card.text()
    
    return true
}