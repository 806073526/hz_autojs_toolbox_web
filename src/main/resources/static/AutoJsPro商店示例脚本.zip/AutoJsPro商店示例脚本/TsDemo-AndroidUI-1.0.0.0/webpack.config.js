const path = require('path');

function resolve (dir) {
  return path.resolve(__dirname, dir)
}

module.exports = {
    mode: "production",
    entry: "./src/main.ts",
    output: {
        filename: "main.node.js",
    },
    target: "node",
    module: {
        rules: [ //rules主要是通过ts-loader这个包针对于ts文件，针对src目录里面的ts和tsx文件进行编译处理操作
            {
                test: /\.tsx?$/,
                use: 'ts-loader',
                include: [resolve('src')]
            }
        ]
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js'] //针对于'.ts', '.tsx', '.js'这三种文件进行处理引入文件可以不写他的扩展名
    },
    externals: {
        engines: "commonjs engines",
        shell: "commonjs shell",
        ui: "commonjs ui",
        rhino: "commonjs rhino",
        lang: "commonjs lang",
        app: "commonjs app",
        color: "commonjs color",
        dialogs: "commonjs dialogs",
    },
};