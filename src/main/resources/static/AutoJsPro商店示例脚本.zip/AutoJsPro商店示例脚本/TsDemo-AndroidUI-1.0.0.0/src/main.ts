import * as $ui from "ui";
import * as $app from "app";
import * as fs from "fs";
import { myEngine } from "engines";
import * as rhino from "rhino";
import { showConfirmDialog } from 'dialogs';
import { toColorInt } from 'color';

//rhino.install();
const Packages = rhino.Packages;
const android = Packages.android;
const com = Packages["com"];
const MenuItem = android.view.MenuItem;
const Snackbar = com.google.android.material.snackbar.Snackbar;
const View = android.view.View;
type View = android.view.View;

class MyActivity extends $ui.Activity {
    
    listData: { text: string, enabled: boolean }[] = [
        { text: 'Hello', enabled: true },
        { text: 'World', enabled: true },
        { text: 'Auto.js', enabled: true },
        { text: 'Pro', enabled: true },
    ];
    
    get initialStatusBar(): $ui.StatusBarConfig {
        return {
            color: '#ffffff',
            light: true
        }
    }

    get layoutXml(): string {
        return `
<column>
    <appbar w="*" h="auto">
        <toolbar id="toolbar" title="TsDemo"/>
    </appbar>
    <scroll>
        <column paddingLeft="12" paddingEnd="12">
            <text text="文本、输入框、按钮" textStyle="bold" textSize="16sp"/>
            <text  maxLines="1" ellipsize="end" text="Android是一种基于Linux的自由及开放源代码的操作系统，主要使用于移动设备，如智能手机和平板电脑，由Google公司和开放手机联盟领导及开发"/>
            <button id="button" text="按钮"/>
            <input id="input" hint="请输入文本"/>

            <text text="表格" textStyle="bold" textSize="16sp"/>
            <grid id="grid" spanCount="2"/>

            <text text="列表" textStyle="bold" textSize="16sp"/>
            <list id="list" h="500"/>

            <text text="画布" textStyle="bold" textSize="16sp"/>
            <canvas id="canvas" w="*" h="200"/>
        </column>
    </scroll>
</column>
        `
    }
    
    get ui(){
        return new Proxy(this, {
            get(target: any, key: any): View | null {
                return target.contentView.findView(key);
            }
        });
    };
    
    public onContentViewSet(view: View): void {
        (this as any).setSupportActionBar(this.ui.toolbar);
        console.log(this.ui.grid.getClass());
    }
    
    public onCreateOptionsMenu(menu: android.view.Menu): boolean {
        menu.add("Abouts")
            .setIcon($ui.R.drawable.ic_info_outline_black_48dp)
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add("Settings");
        return true;
    }
    
    public onOptionsItemSelected(item: android.view.MenuItem): boolean {
        switch (item.getTitle()) {
            case "Abouts":
                this._showMaterial3Alert("Abouts", "UI Demo\nAuto.js Pro V9 With Node.js");
                break;
            case "Settings":
                $app.startActivity("settings");
                break;
        }
        return true;
    }
    
    public _setupGridView(grid: android.widget.GridView): void {
        
    }
    
    public _showMaterial3Alert(title: string, message: string) {
        const MaterialAlertDialogBuilder = com.google.android.material.dialog.MaterialAlertDialogBuilder;
        new MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }
}


$ui.setMainActivity(MyActivity);
$ui.activityLifecycle.on('all_activities_destroyed', () => {
    process.exit();
});