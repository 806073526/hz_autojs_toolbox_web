/* tslint:disable:no-unused-variable */
// Android specific TypeScript declarations

declare module androidNative {	export class Array<T> {	constructor(); length: number; [index: number]: T; } }

import globalAndroid = android;
import globalJava = java;
import globalAndroidX = androidx;
import globalJavaX = javax;
import globalOrg = org;
