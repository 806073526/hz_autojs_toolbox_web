/// <reference path="./android-declarations.d.ts" />
