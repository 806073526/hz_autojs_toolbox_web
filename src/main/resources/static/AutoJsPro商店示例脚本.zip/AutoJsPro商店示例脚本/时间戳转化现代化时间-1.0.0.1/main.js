/*
   作者:啊豪
   qq:2100415529
   这个只是一个简单的时间戳转换现代时间
*/
var sjc = new Date().getTime().toString().substr(0, 10);//10为时间戳可调
function timestampToTime(timestamp) {
    // 时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var date = new Date(timestamp * 1000),
        Y = date.getFullYear() + '-', //年份
        M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-', //月份
        D = date.getDate() + ' ', //日期
        h = date.getHours() + ':', //小时
        m = date.getMinutes() + ':', //分钟
        s = date.getSeconds() //秒
    return Y + M + D + h + m + s
}
timestampToTime(sjc)
console.log(timestampToTime(sjc)) // 10位时间戳