"ui";
ui.layout(
    <drawer id="drawer">
        <vertical>
            <appbar>
                <toolbar id="toolbar"bg="#00BBFF"title="解一元二次方程"/>
            </appbar>
            <horizontal>
                <text textSize="25sp"textColor="black"text="二次项系数a="/>
                <input textSize="20sp"textColor="red"id="a"text="1"/>
            </horizontal>
            <horizontal>
                <text textSize="25sp"textColor="black"text="一次项系数b="/>
                <input textSize="20sp"textColor="red"id="b"text="2"/>
            </horizontal>
            <horizontal>
                <text textSize="25sp"textColor="black"text="常数项系数c="/>
                <input textSize="20sp"textColor="red"id="c"text="-3"/>
            </horizontal>
            <button id="ok"w="auto"h="auto"text="确定"/>
        </vertical>
    </drawer>
);
ui.emitter.on("create_options_menu", menu=>{
    menu.add("退出程序");
});
ui.emitter.on("options_item_selected", (e, item)=>{
    switch(item.getTitle()){
        case "退出程序":
            engines.stopAll();
            break;
    }
    e.consumed = true;
});
activity.setSupportActionBar(ui.toolbar);
ui.ok.click(function() {
    var a = ui.a.getText();
    var b = ui.b.getText();
    var c = ui.c.getText();
    var jie1 = (-b + Math.sqrt(Math.pow(b, 2) - 4 * a * c) - 0) / 2 * a;
    var jie2 = (-b - Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / 2 * a;
    if (Math.pow(b, 2) - 4 * a * c >= 0) {
        if (jie1 > jie2) {
            alert("x1=" + jie1 + "\nx2=" + jie2);
        } else if (jie1 = jie2) {
            alert("x=" + jie1);
        } else {
            alert("x1=" + jie1 + "\nx2=" + jie2);
        };
    } else {
        alert("无解");
    };
});