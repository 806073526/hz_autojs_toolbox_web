"ui";
/**
 * const 在main.js中定义的变量, 在其他js模块中可以直接使用
 */
const rootPath = engines.myEngine().cwd();
const Global = require( "./src/modules/global" );
const CFG = require( "./src/modules/objConfig" );
const cfg = CFG.getConfig();
const UIParms = require( "./src/modules/uiparms" );
const uiparms = UIParms.getUIParms();


$ui.statusBarColor( uiparms.color.body.statusbar );

const mViewManager = new Global.viewManager();
const viewGroup = mViewManager.getViewGroup();
mViewManager.addViewToRoot( viewGroup.mainActivity );

mViewManager.addViewToParint( viewGroup.msg_edit, $ui.mainbody );
require( "./src/viewlogic/mainview" );

// curl https://api.openai.com/v1/embeddings \
//   -X POST \
//   -H "Authorization: Bearer YOUR_API_KEY" \
//   -H "Content-Type: application/json" \
//   -d '{"input": "The food was delicious and the waiter...",
//        "model": "text-similarity-babbage-001"}'
