module.exports = ( function() {
    const CFG = require( "../modules/objConfig" );
    const cfg = CFG.getConfig();

    // console.log( cfg.url );
    return this;
} )()