"nodejs";

const { createDatastore } = require("datastore");
const { playByUrl } = require("./debug");
// Create an storage form
const storage = createDatastore("play.path")

function initialCount() {
    const count = parseInt(Math.random() * 4, 10) + 1
    storage.setSync("count", count)
}
function getMusicPath() {
    initialCount()
    const count = storage.getSync("count")
    return `music/connect_power_${count}.mp3`
}
playByUrl(getMusicPath())