"nodejs";

const { createDatastore } = require("datastore");
const { playByUrl } = require("./debug");
// Create an storage from
const storage = createDatastore("play.path")

function getMusicPath() {
    let count = storage.getSync("count")
    if (count == null || count == undefined) count = parseInt(Math.random() * 4, 10) + 1
    return `music/disconnect_power_${count}.mp3`
}
playByUrl(getMusicPath())