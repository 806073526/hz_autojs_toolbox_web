const { showToast } = require("toast")
const { queryIntentTasks } = require("work_manager")
const { android } = require("rhino").Packages
const Intent = android.content.Intent
const { playMusic } = require("media")

function log(...args) {
    let c = ""
    args.forEach(v => {
        c += v + " "
    })
    console.log(c.trim())
}

function toastLog(...args) {
    let c = ""
    args.forEach(v => {
        c += v + " "
    })
    showToast(c.trim())
    log(c.trim())
}

async function isStarted() {
    const t1 = await queryIntentTasks({
        action: Intent.ACTION_POWER_CONNECTED
    })
    const t2 = await queryIntentTasks({
        action: Intent.ACTION_POWER_DISCONNECTED
    })
    return t1.length < 1 && t2.length < 1 ? false : true
}

function playByUrl(url) {
    playMusic(url)
}

module.exports = {
    log,
    toastLog,
    isStarted,
    playByUrl
}