"nodejs";
const { android } = require("rhino").Packages
const { queryIntentTasks, removeIntentTask } = require("work_manager");
const { toastLog, isStarted, log } = require("./debug");
const { createDatastore } = require("datastore")
const Intent = android.content.Intent
const storage = createDatastore("play.path")

async function stop_task() {
    const actions = [Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED]
    actions.forEach(async intent => {
        const tasks = await queryIntentTasks({
            action: intent
        })
        tasks.forEach(task => {
            removeIntentTask(task.id)
        })
    })
    storage.clear()
}

async function main() {
    if (await isStarted()) {
        stop_task()
        toastLog("成功停止服务")
    } else {
        toastLog("没有正在运行的服务，无需此操作")
    }
}

main()