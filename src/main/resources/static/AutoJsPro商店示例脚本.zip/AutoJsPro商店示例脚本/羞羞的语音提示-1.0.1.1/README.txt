运行 start.js 开启服务
运行 stop.js 停止服务