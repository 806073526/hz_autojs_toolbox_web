"nodejs";
const { android } = require("rhino").Packages
const { addBroadcastIntentTask, queryIntentTasks } = require("work_manager");
const { toastLog, isStarted } = require("./debug");
const Intent = android.content.Intent

function start_task() {
    addBroadcastIntentTask({
        path: "./connect_power.js",
        action: Intent.ACTION_POWER_CONNECTED
    })
    addBroadcastIntentTask({
        path: "./disconnect_power.js",
        action: Intent.ACTION_POWER_DISCONNECTED
    })
}

async function main() {
    if (!await isStarted()) {
        start_task()
        toastLog("注册服务成功")
    } else {
        toastLog("已经注册过此服务，无需重复操作")
    }
}

main()
