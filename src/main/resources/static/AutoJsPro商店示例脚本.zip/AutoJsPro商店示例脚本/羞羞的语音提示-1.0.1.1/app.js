// 此项目在project.json指定了type: node，因此所有文件默认以nodejs模式运行
// This project specifies type: node in project.json, so all files run in nodejs mode by default
"nodejs";
const { readFile } = require("node:fs/promises")
const { toastLog } = require("./debug")
async function main() {
    let content = await readFile("README.txt")
    toastLog(content)
}

main()