/*
*author:云熙
*function:表格视图生成
*qq:1770604763
*还有更多方法，可以自己遍历一遍看方法
*/





"ui";
runtime.loadDex("YunxiTable.dex");
importClass("com.bin.david.form.core.SmartTable");
importClass("com.bin.david.form.data.table.MapTableData");
importClass(com.mycompany.application2.util.JsonHelper);
importClass(java.util.Map);
var storage = storages.create("cookieTime");


//这是里面导入的一个数据集，不用管
var station = function() {
    var storage = storages.create("cookieTime");
    var stDetail = storage.get("station_name_v10073");
  
    if (stDetail == undefined) {
        var file = open("./station.txt")
        var txt = file.read();
        var txtarr = txt.split("@")
        var station_name_v10073 = [];
        for (var x = 1; x < txtarr.length; x++) {
            var splitStation = txtarr[x].split("|")
            var station = {
                Name: splitStation[1],
                StationCode: splitStation[2],
                PingYing: splitStation[3],
                PingYingShort: splitStation[0],
                Sort: splitStation[5]

            };
            station_name_v10073.push(station)

        };
        storage.put("station_name_v10073", station_name_v10073);
    } else {
        var storage = storages.create("cookieTime");
        let station_name_v10073 = storage.get("station_name_v10073");
        let now = JSON.stringify(station_name_v10073)
        let parse = eval(now)

    }
};
var stDetail = storage.get("station_name_v10073");
if(!stDetail){
    station();
    stDetail = storage.get("station_name_v10073");
}
var xx = JSON.parse(JSON.stringify(stDetail))
var xxx = JSON.stringify(xx).toString();
log(xxx)
//var text = '[{ "sites" : [' + '{ "name":"Runoob" , "url":"m.runoob.com" },' + '{ "name":"Google" , "url":"www.google.com" },' + '{ "name":"Taobao" , "url":"www.taobao.com" } ]}]';
var table = new SmartTable(activity);
ui.layout(
    <vertical >
        <RelativeLayout id="outSide"w="*"h="*">
            
        </RelativeLayout>
    </vertical>
)
ui.outSide.addView(table)
var list = [{
        title: "写操作系统作业",
        summary: "明天第1～2节",
        color: "#f44336",
        done: false
    },
    {
        title: "给ui模式增加若干Bug",
        summary: "无限期",
        color: "#ff5722",
        done: false
    },
    {
        title: "发布Auto.js 5.0.0正式版",
        summary: "2019年1月",
        color: "#4caf50",
        done: false
    },
    {
        title: "完成毕业设计和论文",
        summary: "2019年4月",
        color: "#2196f3",
        done: false
    }
]
//可以自己用json，也可以导入Excel数据，需要用poi包
//var t = "[{\"companyId\":\"111111111\",\"companyName\":\"Huuuu\",\"_uid\":10,\"_index\":0,\"_state\":\"modified\"},{\"companyId\":\"000000000000000000\",\"companyName\":\"cx01\",\"_uid\":11,\"_index\":1,\"_state\":\"modified\"},{\"companyId\":\"9999999999999\",\"companyName\":\"ttt\",\"_uid\":12,\"_index\":2,\"_state\":\"modified\"}]";
//var tableData = MapTableData.create("全国车站列表",JsonHelper.jsonToMapList(JSON.stringify(list)));
var tableData = MapTableData.create("全国车站列表",JsonHelper.jsonToMapList(xxx));
table.setTableData(tableData);

