/*
 * @Author: xyq7750 qq:1144317234
 * @Date: 2021-01-06 22:33:42
 * @LastEditTime: 2021-01-06 23:55:16
 * @LastEditors: Please set LastEditors
 * @Description: 监听剪切板，当监听到复制内容后将内容打印 
 * @FilePath: \autojs\test\clip.js
 */
var manager = context.getSystemService(context.CLIPBOARD_SERVICE);
var clip = null;

var ClipChangedListener = new android.content.ClipboardManager.OnPrimaryClipChangedListener() {
    onPrimaryClipChanged: function () {
        // if (manager.hasPrimaryClip() && manager.getPrimaryClip().getItemCount() > 0) {
        //   var addedText = manager.getPrimaryClip();
        //  console.log(addedText);
        //}
        var nowClip = getClip();
        if (nowClip != clip) {
            clip = nowClip;
            log(clip)
        }
    }
}
manager.addPrimaryClipChangedListener(ClipChangedListener);

setInterval(() => { }, 1000);
events.on('exit', function () {
    manager.removePrimaryClipChangedListener(ClipChangedListener)
})