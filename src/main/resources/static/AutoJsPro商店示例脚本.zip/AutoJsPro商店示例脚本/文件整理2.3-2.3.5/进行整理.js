let data;
try {
    data = JSON.parse(files.read("./配置.json"));
} catch (err) {
    console.error(err);
    toast("请先添加配置!");
    exit();
}
let ALmoshi = data.moshi;
let p = (new Date()).getTime();
let ri = 0; //记录移动文件成功的数量
let scanMedia = data.ismedia; //记录是否扫描媒体
uer(data.data);
let tos = "本次整理文件数量：" + ri +
    ('\n花费时间:' + ((new Date()).getTime() - p))+"毫秒";
toastLog(tos);
//广播给其他应用
app.sendBroadcast({
    action: "android.intent.selp.filecso",
    extras: {
        txt: tos
    }
});

function uer(data) {
    data.forEach(function(val) {
        let dir = val.dir;
        let sdt = val.sdt;
        let sizeSet = val.sizeSet;
        let moshi = ALmoshi.concat(val.moshi || []);

        if (!files.isDir(dir)) return;
        //列出所有要操作的文件
        let youdir = [];
        let filed = files.listDir(dir, function(name) {
            if (!data.ioname && name[0] === ".") {
                return false; //忽略.开头的文件
            }
            let qval = files.join(dir, name); //组合绝对路径
            let fileSize = (new java.io.File(qval)).length() / 1024; //取得文件大小-kb
            if (sizeSet) { //文件大小过滤
                if (fileSize < sizeSet.minSize) return false;
                if (sizeSet.maxSize > 0 && fileSize > sizeSet.maxSize) return false;
            }
            if (files.isDir(qval)) {
                youdir.push({
                    dir: qval,
                    sdt: sdt - 1,
                    moshi: val.moshi
                });
                return false;
            }
            return true;
        });

        //进行文件移动
        filed.forEach(function(val) {
            let fomp = files.join(dir, val); //要移动的文件绝对路径
            for (let i = moshi.length - 1; i >= 0; i--) {
                let tofile = moshi[i].tofile; //目标文件夹
                let name = moshi[i].name; //文件类型集
                if (!files.isDir(tofile)) {
                    toastLog(tofile + "文件夹不存在");
                    return;
                }
                let top = files.join(tofile, val); //目标路径
                for (let i2 = 0; i2 < name.length; i2++) {

                    if (val.endsWith("." + name[i2].toLowerCase())) {
                        //如果文件已存在
                        if (files.exists(top)) {
                            console.warn("文件重复：" + val);
                        } else {
                            if (!files.move(fomp, top)) {
                                console.warn("移动文件失败：" + fomp + ">>>>>" + top);
                            } else {
                                log("移动成功：" + fomp + ">>>>>" + top);
                                if (scanMedia) {
                                    media.scanFile(fomp);
                                    media.scanFile(top);
                                }
                                ri += 1;
                            }
                        }
                        return;
                    }
                }
            }
        });
        //多级目录搜索
        if (sdt > 0) {
           return uer(youdir);
        }
    });
}
   
   
   
   
   


