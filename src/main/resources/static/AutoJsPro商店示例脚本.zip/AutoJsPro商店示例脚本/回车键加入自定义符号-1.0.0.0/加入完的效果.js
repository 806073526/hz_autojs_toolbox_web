[
    {
        "hint": "↲",
        "insertText": "
"
    },
    {
        "hint": "(",
        "insertText": "("
    },
    {
        "hint": ")",
        "insertText": ")"
    },
    {
        "hint": "/",
        "insertText": "/",
        "action": "togglecommen"
    },
    {
        "hint": "=",
        "insertText": "="
    },
    {
        "hint": ",",
        "insertText": ","
    },
    {
        "hint": ";",
        "insertText": ";"
    },
    {
        "hint": "\"",
        "insertText": "\""
    },
    {
        "hint": "'",
        "insertText": "'"
    },
    {
        "hint": "{",
        "insertText": "{"
    },
    {
        "hint": "}",
        "insertText": "}"
    },
    {
        "hint": "[",
        "insertText": "["
    },
    {
        "hint": "]",
        "insertText": "]"
    },
    {
        "hint": "`",
        "insertText": "`"
    },
    {
        "hint": "<",
        "insertText": "<"
    },
    {
        "hint": ">",
        "insertText": ">"
    },
    {
        "hint": "-",
        "insertText": "-"
    },
    {
        "hint": "+",
        "insertText": "+"
    },
    {
        "hint": "|",
        "insertText": "|"
    },
    {
        "hint": ":",
        "insertText": ":"
    },
    {
        "hint": "_",
        "insertText": "_"
    },
    {
        "hint": "*",
        "insertText": "*"
    },
    {
        "hint": "%",
        "insertText": "%"
    },
    {
        "hint": "\\",
        "insertText": "\\"
    },
    {
        "hint": "#",
        "insertText": "#"
    },
    {
        "hint": "$",
        "insertText": "$"
    },
    {
        "hint": "&",
        "insertText": "&"
    },
    {
        "hint": "!",
        "insertText": "!"
    },
    {
        "hint": "?",
        "insertText": "?"
    },
    {
        "hint": "^",
        "insertText": "^"
    }
]