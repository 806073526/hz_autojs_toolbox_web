/*
* @Author: 大薯
* @QQ:571235039
* @versioin: 1.0
* @Date: 2021-03-27 04:13:50
*/
"ui";
var resources = context.getResources();
var statusBarHeight = resources.getDimensionPixelSize(resources.getIdentifier('status_bar_height', 'dimen', 'android'));//通知栏高度
var navigationBarHeight = getNavigationBarHeight()//导航栏高度
var deviceheight = device.height - statusBarHeight - navigationBarHeight
var rect = new android.graphics.Rect
ui.layout(
    <frame w="*" h="*" >
        <vertical id="main" w="450px" h="200px" layout_gravity="center" bg="#00ffff">
            <text h="100px" text="你愿意给我10元红包吗" textColor="#000000" gravity="center"/>
            <frame>
                <text id="touch" w="200px" h="100px" text="愿意" bg="#363636" gravity="center" textColor="#ffffff" />
                <text id="fake" w="200px" h="100px" layout_gravity="right|bootom"/>
            </frame>
        </vertical>
        <text id="untouch" w="200px" h="100px" text="不愿意" bg="#363636" textColor="#ffffff" gravity="center"/>
    </frame>
)
setTimeout(function() {
    ui.fake.getBoundsOnScreen(rect)
    ui.untouch.x = rect.left
    ui.untouch.y = rect.top - statusBarHeight
}, 50)
ui.touch.on("click", () => {
    app.startActivity({
        data: "mqqapi://card/show_pslcard?src_type=internal&source=sharecard&version=1&uin=571235039"
    });
    toast("请加QQ571235039并发10元红包")
})
ui.untouch.on("touch_down", () => {
    ui.untouch.getBoundsOnScreen(rect)
    let l = rect.left
    let t = rect.top - statusBarHeight
    let r = rect.right
    let b = rect.bottom - statusBarHeight
    let w = rect.width()
    let h = rect.height()
    //以下if-else语句是为了保持按钮在屏幕内并尽量随机变换按钮位置
    if (l < w) {
        ui.untouch.x = random(l + w, device.width - w)
        if (t < h || new Date().getTime % 2)
            ui.untouch.y = random(t + h, deviceheight - h)
        else
            ui.untouch.y = random(0, b - h)
    } else if ((device.width - r) < w) {
        ui.untouch.x = random(0, r - w)
        if ((deviceheight - b) < h || new Date().getTime % 2)
            ui.untouch.y = random(0, b - h)
        else
            ui.untouch.y = random(t + h, deviceheight - h)
    } else if (new Date().getTime % 2) {
        ui.untouch.x = random(l + w, device.width - w)
        if (t < h || new Date().getTime % 2)
            ui.untouch.y = random(t + h, deviceheight - h)
        else
            ui.untouch.y = random(0, b - h)
    } else {
        ui.untouch.x = random(0, r - w)
        if ((deviceheight - b) < h || new Date().getTime % 2)
            ui.untouch.y = random(0, b - h)
        else
            ui.untouch.y = random(t + h, deviceheight - h)
    }
})

function getNavigationBarHeight() {
    var navigationBarHeight = 0;
    var rid = context.getResources().getIdentifier("config_showNavigationBar", "bool", "android");
    if (rid != 0) {
        var resourceId = context.getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        navigationBarHeight = context.getResources().getDimensionPixelSize(resourceId);
    }
    return navigationBarHeight;
}