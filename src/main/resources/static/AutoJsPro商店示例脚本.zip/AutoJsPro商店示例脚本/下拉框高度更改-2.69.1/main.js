'ui';
/*
 * 作者:潜龙(2307136635)   又名:九天
 * 测试时间:2022/08/27
 * 测试机器:小米8se 
 * AJ版本:pro9.1.20
 */
importClass(android.widget.Spinner)
importClass(android.widget.ListPopupWindow)
//importClass(android.widget.PopupWindow)
importClass(java.lang.Class);
let boxXml = (
    <vertical id="a">
        <Spinner id="sp1"  w="160" h="50" />
        <Spinner id="sp2" entries="选项1|选项2|选项3" h="50" />     
    </vertical>
);
var uu = ui.inflate(
    boxXml
)

mEntriesModify(uu.sp1, ["潜龙", "2307136635", "ww3", "ee4", "ww5", "ee", "ww", "ee"])
mEntriesModify(uu.sp2, ["潜龙", "e3e"])

function mEntriesModify(sp, mEntries) {
    let adapter = new android.widget.ArrayAdapter(context, android.R.layout.simple_spinner_item, mEntries)
    sp.setAdapter(adapter);
    // 弹窗宽度
    sp.setDropDownWidth(360)
    // 弹窗纵向偏移
    sp.setDropDownVerticalOffset(100)

    clazz = Class.forName("android.widget.Spinner");
    popup = clazz.getDeclaredField("mPopup");
    popup.setAccessible(true);
    popupWindow = (ListPopupWindow)(popup.get(sp));
    // 弹窗高度
    popupWindow.setHeight(360);
}

//ui设定
ui.setContentView(uu);

// 以下为模块使用方法
// obj = {}
// obj.view = uu
// module.exports = obj;