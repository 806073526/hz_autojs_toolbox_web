let yashuUtil=require("../yashuUtil");
var ButtonLayout = (function () {
  importClass(android.graphics.Color);
  importClass("androidx.core.graphics.drawable.DrawableCompat");
  util.extend(ButtonLayout, ui.Widget);
  function ButtonLayout() {
    ui.Widget.call(this);
    this.defineAttr("leftDrawable", (view, attr, value, defineSetter) => {
      view.widget.mLeftDrawable = value;
      var lDrawable = context.getResources().getDrawable(getResourceID(value));
      lDrawable.setBounds(0, 0, view.widget.mLeftDrawableSize, view.widget.mLeftDrawableSize);
      let wrappedDrawable = DrawableCompat.wrap(lDrawable);
      DrawableCompat.setTint(wrappedDrawable, Color.parseColor("#FFFFFF"));
      view.setCompoundDrawables(lDrawable, null, null, null);
    });
  }
  ButtonLayout.prototype.mLeftDrawable = null;
  ButtonLayout.prototype.mLeftDrawableSize = yashuUtil.dp2px(20);
  ButtonLayout.prototype.render = function () {
    return (
      <TextView
        bg="?attr/selectableItemBackground"
        gravity="left|center_vertical"
        textColor="#FFFFFF"
        textStyle="normal"
        typeface="monospace"
        padding="20 10"
        drawablePadding="20"
      />
    );
  };

  function getResourceID(name) {
    var resource = context.getResources();
    return resource.getIdentifier(name, "drawable", context.getPackageName());
  }
  ui.registerWidget("button-layout", ButtonLayout);
  return ButtonLayout;
})();