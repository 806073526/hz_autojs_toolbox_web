(function () {
  util.extend(CustomView, ui.Widget);
  function CustomView() {
    ui.Widget.call(this);
    this.scrollPosition = 0;
    this.scrollPositionOffset = 0;
    this.lastScrollPositionOffsetPixels = null;
  }
  CustomView.prototype.render = function () {
    let that = this;
    return JavaAdapter(
      com.stardust.autojs.core.ui.widget.JsViewPager,
      {
        onPageScrolled: function (position, positionOffset, positionOffsetPixels) {
          // log("onPageScrolled: " + position + " " + positionOffset + " " + positionOffsetPixels);
          this.super$onPageScrolled(position, positionOffset, positionOffsetPixels);

          if (that.lastScrollPositionOffsetPixels === null) {
            that.lastScrollPositionOffsetPixels = positionOffsetPixels;
          } else {
            if (that.lastScrollPositionOffsetPixels > positionOffsetPixels) {
              that.moveFromLeftToRight = true;
            } else {
              that.moveFromLeftToRight = false;
            }
          }
          that.scrollPosition = position;
        },
      },
      context
    );
  };

  (CustomView.prototype.isMoveFromLeftToRight = function () {
    return this.moveFromLeftToRight;
  }),
    ui.registerWidget("scale-viewpager", CustomView);
  return CustomView;
})();
