let yashuUtil = require("../yashuUtil");
var ButtonLayout = (function () {
  importClass(android.graphics.Color);
  importClass("androidx.core.graphics.drawable.DrawableCompat");
  util.extend(ButtonLayout, ui.Widget);
  function ButtonLayout() {
    ui.Widget.call(this);
  }
  ButtonLayout.prototype.mLeftDrawable = null;
  ButtonLayout.prototype.mLeftDrawableSize = yashuUtil.dp2px(20);
  ButtonLayout.prototype.render = function () {
    return <button>aaa</button>;
  };

  function getResourceID(name) {
    var resource = context.getResources();
    return resource.getIdentifier(name, "drawable", context.getPackageName());
  }
  ui.registerWidget("test-button", ButtonLayout);
  return ButtonLayout;
})();
