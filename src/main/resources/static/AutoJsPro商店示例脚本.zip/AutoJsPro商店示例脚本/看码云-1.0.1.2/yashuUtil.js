importClass(android.view.WindowManager);
importClass(android.view.View);
importClass(android.graphics.Color);
importClass(android.graphics.drawable.GradientDrawable);

/* -------------------------------------------------------------------------- */
let resources = context.getResources();
let status_bar_height = resources.getDimensionPixelSize(
  resources.getIdentifier("status_bar_height", "dimen", "android")
);

/* -------------------------------------------------------------------------- */
// 密度比例
var scale = resources.getDisplayMetrics().density;
var dp2px = (dp) => {
  return Math.floor(dp * scale + 0.5);
};
var px2dp = (px) => {
  return Math.floor(px / scale + 0.5);
};
/* -------------------------------------------------------------------------- */
function setStatusBarFullTransparent() {
  let window = activity.getWindow();
  window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
  window
    .getDecorView()
    .setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
  window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
  window.setStatusBarColor(Color.TRANSPARENT);
}
//是否全屏
function fullScreen(enable) {
  if (enable) {
    //设置全屏
    let lp = activity.getWindow().getAttributes();
    lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
    activity.getWindow().setAttributes(lp);
    activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
  } else {
    //取消全屏
    let attr = activity.getWindow().getAttributes();
    attr.flags &= ~WindowManager.LayoutParams.FLAG_FULLSCREEN;
    activity.getWindow().setAttributes(attr);
    activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
  }
}

function setBackgroundRoundGradientCornerRadiiButton(view, color) {
  gradientDrawable = new GradientDrawable();
  gradientDrawable.setShape(GradientDrawable.RECTANGLE);
  gradientDrawable.setColor(colors.parseColor(color));
  // gradientDrawable.setStroke(10, Color.BLUE);
  // gradientDrawable.setCornerRadius(10);
  //1、2两个参数表示左上角，3、4表示右上角，5、6表示右下角，7、8表示左下角

  let radiusArr = util.java.array("float", 8);
  radiusArr[0] = 80;
  radiusArr[1] = 80;
  radiusArr[2] = 80;
  radiusArr[3] = 80;
  radiusArr[4] = 80;
  radiusArr[5] = 80;
  radiusArr[6] = 80;
  radiusArr[7] = 80;
  gradientDrawable.setCornerRadii(radiusArr);
  view.setBackground(gradientDrawable);
}
function setBackgroundRoundGradientCornerRadii(view, color) {
  gradientDrawable = new GradientDrawable();
  gradientDrawable.setShape(GradientDrawable.RECTANGLE);
  gradientDrawable.setColor(colors.parseColor(color));
  // gradientDrawable.setStroke(10, Color.BLUE);
  // gradientDrawable.setCornerRadius(10);
  //1、2两个参数表示左上角，3、4表示右上角，5、6表示右下角，7、8表示左下角

  let radiusArr = util.java.array("float", 8);
  radiusArr[0] = 10;
  radiusArr[1] = 20;
  radiusArr[2] = 30;
  radiusArr[3] = 40;
  radiusArr[4] = 50;
  radiusArr[5] = 60;
  radiusArr[6] = 70;
  radiusArr[7] = 80;
  gradientDrawable.setCornerRadii(radiusArr);
  gradientDrawable.setSize(50, 50);
  view.setBackground(gradientDrawable);
}
function printObj(obj) {
  var arr = [];
  for (var k in obj) {
    arr.push(k);
  }
  arr.sort();

}
function shareTxtFile(filepath) {
  let sharingIntent = new Intent(Intent.ACTION_SEND);
  sharingIntent.setType("text/*");
  sharingIntent.putExtra(Intent.EXTRA_STREAM, app.getUriForFile(filepath));
  app.startActivity(Intent.createChooser(sharingIntent, "分享到"));
}
module.exports = {
  printObj: printObj,
  setStatusBarFullTransparent: setStatusBarFullTransparent,
  fullScreen: fullScreen,
  status_bar_height: status_bar_height,
  setBackgroundRoundGradientCornerRadiiButton: setBackgroundRoundGradientCornerRadiiButton,
  setBackgroundRoundGradientCornerRadii: setBackgroundRoundGradientCornerRadii,
  dp2px: dp2px,
  px2dp: px2dp,
  shareTxtFile: shareTxtFile,
};
