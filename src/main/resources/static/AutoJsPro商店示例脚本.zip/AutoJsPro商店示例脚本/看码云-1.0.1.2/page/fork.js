"ui";
let yashuUtil = require("./yashuUtil");
let service = require("./service");
let config = require("./config");
let baseUrl = config.baseUrl;
let themeColor = config.themeColor;
let status_bar_height = yashuUtil.status_bar_height;
ui.layout(
  <vertical bg="{{themeColor}}" paddingTop="{{status_bar_height}}px" gravity="center">
    <text
      w="*"
      gravity="center"
      layout_gravity="bottom"
      text="Fork一个仓库"
      layout_width="wrap_content"
      layout_height="wrap_content"
      textSize="32"
      textColor="#ffffff"
      textStyle="bold"
    />
    <input padding="16" gravity="center" textSize="16sp" id="repoUrl" textColor="#ffffff" hint="码云仓库链接"></input>
    <text
      id="login"
      w="200dp"
      text="fork"
      textColor="#ffffff"
      padding="20"
      gravity="center"
      marginTop="32dp"
      textSize="22sp"
    />
  </vertical>
);
ui.login.click(function () {
  let url = ui.repoUrl.text().trim();
  if (!url) {
    toastLog("请填写 码云仓库链接");
  } else {
    // url匹配码云域名
    let reg = /gitee.com\/(.*)\/(.*)/;
    let match = url.match(reg);
    if (match) {

      service.forkRepo(url);
    } else {
      toastLog("请填写正确的码云仓库链接");
    }
  }
});
yashuUtil.setStatusBarFullTransparent();
yashuUtil.setBackgroundRoundGradientCornerRadii(ui.repoUrl, "#229c27b0");
yashuUtil.setBackgroundRoundGradientCornerRadiiButton(ui.login, "#1fa62b");
ui.repoUrl.setHintTextColor(colors.parseColor("#b3ffffff"));
/* -------------------------------------------------------------------------- */
