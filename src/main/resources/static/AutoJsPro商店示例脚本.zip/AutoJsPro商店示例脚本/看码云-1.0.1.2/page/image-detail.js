"ui";
var args = engines.myEngine().execArgv;
let url = args.url;
let sha = args.sha;
let filepath = args.path;
importClass(Packages.androidx.recyclerview.widget.RecyclerView);
importClass(Packages.androidx.recyclerview.widget.LinearLayoutManager);
importClass(android.graphics.Color);
importClass(Packages.androidx.swiperefreshlayout.widget.SwipeRefreshLayout);
importClass(android.view.View);
let yashuUtil = require("./yashuUtil");
let config = require("./config");
let service = require("./service");

let themeColor = config.themeColor;
let status_bar_height = yashuUtil.status_bar_height;
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
let userInfo = config.storage.get("userInfo");
ui.layout(
  <vertical bg="{{themeColor}}" paddingRight="16" paddingTop="{{status_bar_height}}px">
    <frame marginBottom="16" paddingLeft="16">
      <img
        id="back"
        tint="#ffffff"
        src="@drawable/ic_keyboard_arrow_left_black_48dp"
        layout_gravity="center_vertical"
        w="40dp"
      ></img>
      <TextView
        id="title"
        textColor="#ffffff"
        textSize="32sp"
        layout_width="wrap_content"
        layout_height="wrap_content"
        layout_centerInParent="true"
        layout_gravity="center"
        text=""
      />
      <horizontal layout_gravity="right|center" w="*" gravity="right|center">
        <img id="share" tint="#ffffff" src="@drawable/ic_share_black_48dp" w="40dp"></img>
      </horizontal>
    </frame>
    <vertical>
      <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
        id="swipeRefreshLayout"
        layout_width="match_parent"
        layout_height="wrap_content"
      >
        <img id="img" w="*" h="*"></img>
      </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>
    </vertical>
  </vertical>
);
ui.title.setText(filepath);
/* -------------------------------------------------------------------------- */
ui.swipeRefreshLayout.setRefreshing(true);
service.getBlob(url, sha, filepath).then((filepath) => {
  ui.run(function () {
    ui.swipeRefreshLayout.setRefreshing(false);
    ui.swipeRefreshLayout.setEnabled(false);
  });

  // 分享链接
  ui.share.on("click", () => {
    yashuUtil.shareTxtFile(filepath);
  });
  // 设置布局管理器
  ui.post(function () {
    ui.img.attr("src", "file://" + filepath);
  }, 500);
});
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */

yashuUtil.setStatusBarFullTransparent();
ui.title.setText(filepath);
ui.back.on("click", () => {
  engines.myEngine().forceStop();
});
