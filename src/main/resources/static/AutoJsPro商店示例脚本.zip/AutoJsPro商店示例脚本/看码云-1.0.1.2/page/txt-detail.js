"ui";
var args = engines.myEngine().execArgv;

let url = args.url;
let sha = args.sha;
let filepath = args.path;
importClass(Packages.androidx.recyclerview.widget.RecyclerView);
importClass(Packages.androidx.recyclerview.widget.LinearLayoutManager);
importClass(android.graphics.Color);
importClass(Packages.androidx.swiperefreshlayout.widget.SwipeRefreshLayout);
importClass(android.view.View);
let yashuUtil = require("./yashuUtil");
let config = require("./config");
let service = require("./service");

let themeColor = config.themeColor;
let status_bar_height = yashuUtil.status_bar_height;
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
let userInfo = config.storage.get("userInfo");
ui.layout(
  <vertical bg="{{themeColor}}" paddingRight="16" paddingTop="{{status_bar_height}}px">
    <frame marginBottom="16" paddingLeft="16">
      <img
        id="back"
        tint="#ffffff"
        src="@drawable/ic_keyboard_arrow_left_black_48dp"
        layout_gravity="center_vertical"
        w="40dp"
      ></img>
      <TextView
        id="title"
        textColor="#ffffff"
        textSize="32sp"
        layout_width="wrap_content"
        layout_height="wrap_content"
        layout_centerInParent="true"
        layout_gravity="center"
        text=""
      />
      <horizontal layout_gravity="right|center" w="*" gravity="right|center">
        <img id="copy" tint="#ffffff" src="@drawable/ic_content_copy_black_48dp" w="40dp"></img>
        <img id="share" tint="#ffffff" src="@drawable/ic_share_black_48dp" w="40dp"></img>
      </horizontal>
    </frame>

    <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
      id="swipeRefreshLayout"
      layout_width="match_parent"
      layout_height="wrap_content"
    >
      <androidx.recyclerview.widget.RecyclerView
        id="recyclerView"
        layout_width="match_parent"
        layout_height="match_parent"
      />
    </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>
  </vertical>
);
ui.title.setText(filepath);
ui.swipeRefreshLayout.setRefreshing(true);
/* -------------------------------------------------------------------------- */
service.getBlob(url, sha, filepath).then((filepath) => {
  ui.run(function () {
    ui.swipeRefreshLayout.setRefreshing(false);
    ui.swipeRefreshLayout.setEnabled(false);
  });

  // 分享链接
  ui.share.on("click", () => {
    yashuUtil.shareTxtFile(filepath);
  });
  ui.copy.on("click", () => {
    setClip(files.read(filepath));
    toastLog("已复制");
  });
  let lines = files.read(filepath).split("\n");
  // 设置布局管理器
  ui.run(function () {
    let layoutManager = new LinearLayoutManager(context);
    ui.recyclerView.setLayoutManager(layoutManager);
    let recycleAdapter = createRecyclerViewAdapter(lines);
    ui.recyclerView.setAdapter(recycleAdapter);
  });
});
/* -------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------- */

yashuUtil.setStatusBarFullTransparent();
ui.title.setText(filepath);
ui.back.on("click", () => {
  engines.myEngine().forceStop();
});
/* -------------------------------------------------------------------------- */
function createRecyclerViewAdapter(items) {
  let itemLayout = (
    <horizontal gravity="center_vertical">
      <text
        id="lineNumber"
        paddingLeft="16"
        paddingRight="2"
        bg="#c270b7"
        gravity="center|right"
        h="*"
        w="50dp"
        textSize="12sp"
        textColor="#ffffff"
      ></text>
      <text padding="8 8 0 8" gravity="left" id="lineContent" textColor="#ffffff"></text>
    </horizontal>
  );
  return RecyclerView.Adapter({
    onCreateViewHolder: function (parent, viewType) {
      // log("onCreateViewHolder");
      // 视图创建
      let view;
      let holder;
      view = ui.inflate(itemLayout, parent, false);
      holder = JavaAdapter(RecyclerView.ViewHolder, {}, view);
      return holder;
    },
    onBindViewHolder: function (holder, position) {
      // 数据绑定
      let view = holder.itemView;
      let item = items[position];
      view.lineNumber.setText("" + position);
      view.lineContent.setText(item);
    },
    getItemCount: function () {
      return items.length;
    },
  });
}
