let materialColors = [
  "#e91e63",
  "#ab47bc",
  "#5c6bc0",
  "#7e57c2",
  "#2196f3",
  "#00bcd4",
  "#26a69a",
  "#4caf50",
  "#8bc34a",
  "#ffeb3b",
  "#ffa726",
  "#78909c",
  "#8d6e63",
];
var len = materialColors.length;
for (var i = 0; i < len; i++) {
  let color = materialColors[i];
  materialColors[i] = colors.parseColor(color);
}
let config = {
  dir: "gitee-for-android",
  themeColor: "#c71d23",
  baseUrl: "https://gitee.com/api/v5",
  storageName: "gitee-for-android",
  userEventsCount: 10,
  repoCount: 10,
  searchResultCount:10,
  fileSizeLimit: 50 * 1024,
  actionType: {
    CreateEvent: "创建了",
    PushEvent: "推送了",
    DeleteEvent: "删除了",
    ForkEvent: "fork了",
    WatchEvent: "关注了",
    IssueCommentEvent: "评论了",
    IssuesEvent: "发布了",
    PullRequestEvent: "提交了",
    PullRequestReviewCommentEvent: "评论了",
    ReleaseEvent: "发布了",
    WatchEvent: "关注了",
  },
  refType: {
    branch: "分支",
    tag: "标签",
    commit: "提交",
    repository: "仓库",
  },
  materialColors: materialColors,
};

let storage = storages.create(config.storageName);
config.storage = storage;
module.exports = config;
let token = storage.get("token", false);

