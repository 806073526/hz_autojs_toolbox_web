# gitee-for-android

这是一个 [autojs](https://www.yuque.com/yashujs/bfug6u/vce2fh) 的项目, 使用的api主要是 [UI](https://pro.autojs.org/docs/#/zh-cn/ui) 和 [http](https://pro.autojs.org/docs/#/zh-cn/http) , 实现了以下功能:

- 获取码云用户动态
- 获取码云仓库列表
- 展示仓库的文件目录
- 查看仓库的图片和文本
- 分享文件



## 图示

登录页

![](img/1.jpg)

侧栏

![](img/2.jpg)

动态

![](img/3.jpg)

仓库文件列表

![](img/4.jpg)

文本文件

![](img/5.jpg)




## autojs版本

9.1.19

## 获取码云token

个人主页/ 设置/ 安全设置/ 私人令牌/ 生成新令牌

## 警告

请严格保管你的token, 避免泄漏, 因为token的权限很大, 可以读写以及删除仓库

## Q群
![](牙叔教程q群.png)


## 公众号 牙叔教程
![](牙叔教程公众号.jpg)

## 相关教程

[autojs给码云提交issue · 语雀 (yuque.com)](https://www.yuque.com/yashujs/bfug6u/ad7z0u)

## 您的打赏，会给我提供更大的前行动力，谢谢！

<center class="half">
    <img src="./vx.png" width="400"/>
    <img src="./zfb.png" width="400"/>
</center>
