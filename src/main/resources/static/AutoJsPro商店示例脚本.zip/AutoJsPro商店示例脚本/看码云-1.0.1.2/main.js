"ui";
engines.all().map((ScriptEngine) => {
  if (engines.myEngine().toString() !== ScriptEngine.toString()) {
    ScriptEngine.forceStop();
  }
});
let yashuUtil = require("./yashuUtil");
let service = require("./service");
let config = require("./config");
// config.storage.clear();
let baseUrl = config.baseUrl;
ui.layout(
  <frame bg="#fffdff">
    <img src="file://./logo.png" gravity="center" scaleType="center" />
    <text
      w="*"
      gravity="center"
      layout_gravity="bottom"
      text="牙叔出品"
      layout_width="wrap_content"
      layout_height="wrap_content"
      textSize="32"
      textColor="#ffffff"
      textStyle="bold"
      margin="32"
    />
  </frame>
);


yashuUtil.setStatusBarFullTransparent();

let storage = config.storage;
let token = service.readToken();
if (!token) {
  engines.execScriptFile("./page/login.js");
} else {
  let url = baseUrl + "/user?access_token=" + token;
  http.get(url, {}, function (res, err) {
    if (err) {
      console.error(err);
      return;
    }
    if (res.statusCode !== 200) {
      engines.execScriptFile("./page/login.js");
    } else {
      let data = res.body.json();
      let name = data.name;
      toastLog("欢迎回来, " + name);
      storage.put("userInfo", data);
      engines.execScriptFile("./page/user.js");
    }
  });
}
