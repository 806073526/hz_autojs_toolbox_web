toast("我被运行了");
sleep(5000);
toast("我被关闭了");