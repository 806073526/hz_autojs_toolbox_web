console.log("Hello, Auto.js Pro!");

function 关闭指定脚本(脚本) {
    var 所有脚本 = engines.all();
    for (let i = 0; i < 所有脚本.length; i++) {
        var 删除脚本 = 所有脚本.pop();
        if (脚本.test(删除脚本)) {
            删除脚本.forceStop();
        };
    };
};

engines.execScriptFile("./被关闭脚本.js");

sleep(1000);

关闭指定脚本(/被关闭脚本/);
//在正则里输入被关闭脚本的名称