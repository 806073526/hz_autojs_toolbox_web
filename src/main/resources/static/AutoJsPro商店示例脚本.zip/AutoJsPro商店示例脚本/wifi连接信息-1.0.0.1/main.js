/*
   作者:selp
   qq:201228773
   参考链接:https://www.cnblogs.com/xiaqiuchu/articles/11674430.html
   用正则处理了一下变成了方便使用的json格式，
   没开热点时会显示当前连接的wifi信息
*/

function retip() {
    let a = shell('ip neigh');
    if (a.code !=0) throw new Error(a.error);
    let arr = a.result.match(/[^\s]+ dev .+ lladdr [^\s]+( router)?/g);
    if (arr==null) return [];
    let data = arr.map((val)=>{
        return {
            ip:val.match(/^[^\s]+/)[0],
            dev:val.match(/[^\s]+(?= lladdr)/)[0],
            mac:val.match(/[^\s]+(?=$| router$)/)[0],
            router:/router$/.test(val)
        }
    });
    return data;
}
log(retip());