"ui";

var shape = require("./RippleDrawable.js");
var color1 = "#6200ee";
var color2 = "#ef4e4f";
var color3 = "#ffffff";
var color4 = "#50000000";
var color5 = "#cc00ff";
var color6 = "#ff9900";
var color7 = "#99ff00";
var color8 = "#33ffff";
var color9 = "#000000";
ui.statusBarColor(color1);
ui.layout(
    <LinearLayout layout_width="match_parent" layout_height="match_parent" orientation="vertical">
        <toolbar layout_width="match_parent" background={color1} title="UI样式3.0——点击UI不再生硬" />
        <ScrollView w="*" h="*" >
            <LinearLayout layout_width="match_parent" layout_height="match_parent" orientation="vertical" >
                <TextView w="auto" clickable="true" w="*" textSize="18" gravity="center" h="55" id="m1" text="重构2.0版本并添加点击水波纹效果" textColor={color1} />
                <LinearLayout layout_width="match_parent" layout_height="50">
                    <TextView w="0" layout_weight="1" clickable="true" h="*" gravity="center" id="v1" text="水波纹点击" textColor={color1} />
                    <TextView w="0" layout_weight="1" clickable="true" h="*" gravity="center" id="v2" text="水波纹点击" textColor={color1} />
                    <TextView w="0" layout_weight="1" clickable="true" h="*" gravity="center" id="v3" text="水波纹点击" textColor={color1} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="40" gravity="center" paddingLeft="10" paddingRight="10">
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v4" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v5" text="水波纹点击" textColor={color3} marginLeft="15" marginRight="15" />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v6" text="水波纹点击" textColor={color3} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="50" gravity="center" paddingLeft="10" paddingRight="10">
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v7" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v8" text="水波纹点击" textColor={color3} marginLeft="15" marginRight="15" />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v9" text="水波纹点击" textColor={color3} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="50" gravity="center" paddingLeft="10" paddingRight="10">
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v10" text="水波纹点击" textColor={color1} />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v11" text="水波纹点击" textColor={color1} marginLeft="15" marginRight="15" />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v12" text="水波纹点击" textColor={color1} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="50" gravity="center" paddingLeft="10" paddingRight="10">
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v13" text="水波纹点击" textColor={color1} />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v14" text="水波纹点击" textColor={color1} marginLeft="15" marginRight="15" />
                    <TextView w="0" layout_weight="1" clickable="true" h="30" gravity="center" id="v15" text="水波纹点击" textColor={color1} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="50" gravity="center" paddingLeft="10" paddingRight="10" id="vll1" clickable="true">
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="40" gravity="center" marginLeft="10" marginRight="10" marginTop="10dp" id="vll2" clickable="true">
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                </LinearLayout>
                <LinearLayout layout_width="match_parent" layout_height="40" gravity="center" marginLeft="10" marginRight="10" marginTop="10dp" id="vll3" clickable="true">
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                </LinearLayout>
                <View id="line1" w="*" h="1" marginTop="15" />
                <View id="line2" w="*" h="3" marginTop="15" />
                <View id="line3" w="*" h="6" marginTop="15" />

                <LinearLayout layout_width="match_parent" layout_height="40" gravity="center" marginLeft="10" marginRight="10" marginTop="15dp" id="vll4" clickable="true">
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                    <TextView w="0" layout_weight="1" h="30" gravity="center" text="水波纹点击" textColor={color3} />
                </LinearLayout>
            </LinearLayout>
        </ScrollView>
    </LinearLayout>
);

shape.widthRipple(activity).setTextColor(color5, color6, color7).into(ui.m1);

shape.widthRipple(activity).setRippleColor(color1, color2).into(ui.v1);
shape.widthRipple(activity).setRippleColor("#FFFF00", "#303F9F").into(ui.v2);
shape.widthRipple(activity).setRippleColor("#00ffff", "#FF0000").into(ui.v3);

shape.widthRipple(activity).setColor(color1).setAllRadius(20).into(ui.v4);
shape.widthRipple(activity).setColor(color1).setRadius(20, 20, 0, 0, 20, 20).setRippleColor(color3, color2).into(ui.v5);
shape.widthRipple(activity).setColor(color1).setRadius(0, 0, 20, 20, 0, 0, 20, 20).setRippleColor(color2, color3).into(ui.v6);

shape.widthRipple(activity).setColor(color1, color2).setRadius(20, 20, 20, 20, 0, 0, 0, 0).setRippleColor(color4, color3).into(ui.v7);
shape.widthRipple(activity).setColor(color1, color2).setRadius(0, 0, 0, 0, 20, 20, 20, 20).setRippleColor(color4, color3).setOrientation("left_right").into(ui.v8);
shape.widthRipple(activity).setColor(color1, color2).setRadius(0, 0, 20, 20, 20, 20, 0, 0).setRippleColor(color4, color3).setOrientation("tr_bl").into(ui.v9);

shape.widthRipple(activity).setStroke(2, color1).into(ui.v10);
shape.widthRipple(activity).setStroke(2, color1).setAllRadius(20).setRippleColor("#00FF00", color3).setColor(color3).into(ui.v11);
shape.widthRipple(activity).setStroke(2, color1).setRadius(20, 20, 0, 0, 20, 20).setRippleColor("#FFFF00", color3).setColor(color3).into(ui.v12);

shape.widthRipple(activity).setStroke(2, color1).setDash(5, 3).into(ui.v13);
shape.widthRipple(activity).setStroke(2, color1).setDash(5, 3).setAllRadius(20).setRippleColor("#00FF00", color3).setColor(color3).into(ui.v14);
shape.widthRipple(activity).setStroke(2, color1).setDash(5, 3).setRadius(20, 20, 0, 0, 20, 20).setRippleColor("#FFFF00", color3).setColor(color3).into(ui.v15);


shape.widthRipple(activity).setColor(color5, color6, color7).into(ui.vll1);
shape.widthRipple(activity).setColor(color5, color6, color7).setStroke(2, color1).setAllRadius(30).setRippleColor(color8).into(ui.vll2);
shape.widthRipple(activity).setColor(color5, color6, color7).setStroke(2, color1).setDash(5, 5).setAllRadius(30).setRippleColor(color8).into(ui.vll3);

shape.widthRipple(activity).line(color1, 5, 5).into(ui.line1);
shape.widthRipple(activity).line(color9, 5, 5).into(ui.line2);
shape.widthRipple(activity).line(color2, 5, 5).into(ui.line3);


shape.widthRipple(activity)
    .setAllRadius(20)
    .setColor(color3, color5, color6, color7, color3)
    .setStrokeWidth(2)
    .setGradientStrokeColor(color6, color8, color5, color7)
    .setGradientStrokeOrientation("top_Bottom")
    .setOrientation("left_right")
    .intoGradientStroke(ui.vll4);



