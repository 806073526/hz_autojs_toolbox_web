/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-06-24 12:53:16
 * @LastEditTime: 2022-06-28 19:08:46
 * @Description: 可通过点击通知或按钮，打开第二个activity
 * 灵感来之不易,积累创造奇迹
 */
"ui";
import rhino from "rhino";
import { Activity, R, setMainActivity, startActivity as startSelfActivity } from "ui";
import { startActivity, launch } from "app";
import { showToast } from "toast";
import { notify } from "notification";
rhino.install();
const MenuItem = android.view.MenuItem;
const context = $autojs.androidContext;
//可以用来记录正在显示的activity，这里用applicationGlobals的方案
let currentActivity = "MainActivity";
//用内部api获取顶层activity
const applicationGlobals = $autojs.__internals.applicationGlobals;
class SecondActivity extends Activity {
	constructor() {
		super();
	}
	get initialStatusBar() {
		return { color: "#ffffff", light: true };
	}

	get layoutXml() {
		return `
        <column>
            <appbar w="*" h="auto">
                <toolbar id="toolbar" title="第二个activity"/>
            </appbar>
            <scroll>
                <column paddingLeft="12" paddingEnd="12">
                    <text text="文本、输入法、按钮" textStyle="bold" textSize="16sp"/>
                    <text maxLines="1" ellipsize="end" text="这是跳转的界面"/>
                </column>
            </scroll>
        </column>
        `;
	}

	onResume() {
		currentActivity = "SecondActivity";
		super.onResume();
	}
}
class MainActivity extends Activity {
	constructor() {
		super();
		this.lastActivity = SecondActivity;
	}

	get initialStatusBar() {
		return { color: "#ffffff", light: true };
	}

	get layoutXml() {
		return `
        <column>
            <appbar w="*" h="auto">
                <toolbar id="toolbar" title="Demo"/>
            </appbar>
            <scroll>
                <column paddingLeft="12" paddingEnd="12">
                    <text text="文本、输入法、按钮" textStyle="bold" textSize="16sp"/>
                    <text  maxLines="1" ellipsize="end" text="Android是一种基于Linux的自由及开放源代码的操作系统，主要使用于移动设备，如智能手机和平板电脑，由Google公司和开放手机联盟领导及开发"/>
                    <com.google.android.material.button.MaterialButton text="发送通知" id="send" margin="5 20 5 0" w="*" />
                    <com.google.android.material.button.MaterialButton text="切换activity" id="button" margin="5 20 5 0" w="*" />
                </column>
            </scroll>
        </column>
        `;
	}

	onContentViewSet(view) {
		this.setSupportActionBar(view.findView("toolbar"));
		view.findView("send").on("click", async () => {
			notify(1001, {
				contentTitle: "测试发通知",
				contentText: "点击可进入第二个界面",
				ticker: "您收到一条来自autojs的通知",
				autoCancel: true,
				onContentClick: () => {
				    //如果主activity正在显示，则打开第二个，否则仅打开app
					if (applicationGlobals.topActivity().equals(this)) {
						startSelfActivity(this.lastActivity);
					} else {
						launch(context.getPackageName());
					}
				},
			});
		});
		view.findView("button").on("click", async () => {
			startSelfActivity(this.lastActivity);
		});
	}

	onResume() {
		currentActivity = "MainActivity";
		super.onResume();
	}

	onCreateOptionsMenu(menu, inflater) {
		menu.add("About").setIcon(R.drawable.ic_info_outline_black_48dp).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add("Console");
		return true;
	}

	onOptionsItemSelected(item) {
		switch (item.getTitle()) {
			case "About":
				showToast("UI Demo");
				break;
			case "Console":
				startActivity("console");
				break;
		}
		return true;
	}
}

setMainActivity(MainActivity);
