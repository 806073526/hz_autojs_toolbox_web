const Copy = {};

Copy.kill = function(string, callback) {
    if (string) {
        switch (typeof string) {
            case "string":
                let over = engines.all();
                for (let i = 0; i < over.length; i++) {
                    if (String(over[i].source).search(string) !== -1) {
                        over[i].forceStop();
                        try {
                            callback(over[i].source) 
                        } catch (x) {}
                    }
                }
            break;

            case "object":
                if (string.length) { //检测传参数据是否为数组
                    let over = engines.all();
                    for (let i = 0; i < over.length; i++) {
                        for (let c = 0; c < [over.length - 1]; c++) {
                            if (String(over[i].source).search(string[c]) !== -1) {
                                over[i].forceStop();
                                try {
                                    callback(over[i].source)
                                } catch (x) {}
                            }
                        }
                    }
                }
            break;
        }
    }
}

Copy.kill("test.js", function(i) {
    if (i.toString().search("test.js") !== -1) {
        toast("ok")
    }
})