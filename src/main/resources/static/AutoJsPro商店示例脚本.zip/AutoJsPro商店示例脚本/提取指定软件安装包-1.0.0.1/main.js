// 用户给变量赋初值
app = "com.tencent.mobileqq"  // 软件包名
appName = "QQ"  // 软件名称
// =============================== //
apkName = appName + ".apk"
saveApkDir = "/sdcard/Android/" + apkName
// 获取应用安装包路径
appInstallDir = shell("pm path " + app).result.split(":")[1]
copyCmd = "cp -f " + appInstallDir + " " + saveApkDir
copyCmd = copyCmd.replace("\n", "")
// 提取文件
shell(copyCmd)
// 判断是否提取成功
if (files.isFile(saveApkDir)) {
    toast("软件: " + appName + " 的安装包已提取成功!")
    toast("安装包存储位置: " + saveApkDir)
} else {
    toast("安装包提取失败......")
}