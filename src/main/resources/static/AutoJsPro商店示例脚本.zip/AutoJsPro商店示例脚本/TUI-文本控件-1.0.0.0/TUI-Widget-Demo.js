"ui";
importClass(java.lang.Integer);
importClass(android.graphics.Color);
//var tuiText = require('components/tuiText.js');
//var tuiButton =require('components/tuiButton.js');
//var Util = require("util.js");
//var serviceThread = require("mainService.js");
var {tuiText,
     tuiButton ,
     tuiEditText, 
     tuiCheckBox} = require('./components/tuiWidget.js');
let UICode = (
    <ScrollView>
    <vertical padding="20">
        <tui-text id="title" text="*TUI-Widget" textSize="30sp" margin="10"  textStyle="bold" gravity="center" layout_gravity="center"/>
        <tui-text  text=">>tui-text:" textSize="20sp" margin="10" color="black" textStyle="bold"/>
            <tui-text  text="这是一个普通的tui-text"/>
            <tui-text  text="这是一个有颜色的tui-text" color="green"/>
            <tui-text id="imsobig" text="这是一个加大加粗有颜色有背景有点击事件的tui-text" background="#000000" textSize="16sp" color="red" textStyle="bold"/>
            <tui-text id="colorful" text="这是一个多彩的tui-text" />
            <tui-text  text=">>tui-button:"textSize="20sp"margin="10" textStyle="bold"color="black"/>
              <tui-button  text="这是一个普通的tui-button" />
                <tui-button  text="这是一个带颜色的tui-button" backgroundColor="red" color="white"/>
              <linear margin="8">
                <tui-button  text="点击加载" id="autoloading" backgroundColor="#0099ff" color="white" w="100" />
               <tui-button  text="点我加载" id="autoloading2" backgroundColor="#00ffff" color="white" w="100" />
                <!--backgroundColor="blue" color="white" padding="5"/-->
                </linear>
                
                <tui-text  text=">>tui-editText:"textSize="20sp"margin="10" textStyle="bold"color="black"/>
                    <tui-editText id="aaac" prefKey="aaa" hint="这是一个设置了自动保存内容的edittext"/>
                    <tui-editText prefKey="bbb" hint="这是另一个设置了自动保存内容的edittext"/>
                    <tui-editText  hint="我没有设置自动保存内容"/>
                    
                    <tui-text  text=">>tui-checkBox:"textSize="20sp"margin="10" textStyle="bold"color="black"/>
                        <tui-checkBox text="这是一个可以自定义未/选中状态的CheckBox" statusStyle="[V]|[X]|[*]" prefKey="testcheckbox1" textSize="18"/>
                        <tui-checkBox text="默认tui样式:选中■|未选中□|禁用▧"  textSize="18"/>
                        <tui-checkBox text="自动保存状态的checkBox" prefKey="testcheckbox3" textSize="18"/>
                        <tui-checkBox text="我有颜色"  textSize="18" color="#ff0000"/>
                        <tui-checkBox text="我被禁用" forbid="true" textSize="18"/>
                    </vertical>
                    </ScrollView>);
ui.layout(UICode);
/*oInf = ui.__inflate__
ui.__inflate__ = function(inflateCtx, xml, parent, attachToParent) {
    //    
    if (xml instanceof android.view.View) {
        return xml
        // return oInf(inflateCtx, xml, parent, attachToParent)// 
    }
}*/

print(Color.RED, 0xFFFF0000);
ui.title.setColourfulText([{
        start: 1,
        end: 4,
        color: 0xffffcc00
    },
    {
        start: 5,
        end: 8,
        color: 0xffff0000
    },
    /*{start:6,end:7,color:Color.BLACK},
    {start:7,end:8,color:Color.YELLOW},*/
    {
        start: 8,
        end: 11,
        color: 0xff00aaff
    }
]);
ui.colorful.setColourfulText([{
        start: 1,
        end: 2,
        color: 0xff00ff66
    },
    {
        start: 2,
        end: 3,
        color: 0xffff0000
    },
    {
        start: 3,
        end: 5,
        color: 0xff0022ff
    },
    {
        start: 5,
        end: 8,
        color: 0xffff9900,
        background: Color.BLUE
    }
]);
ui.aaac.addTuiTextChangedListener(new TextWatcher() {
    //@Override
    afterTextChanged: function(s) {
        FIND_FORM_STEP_IS_FROM_TEXT = (ui.aaac.getText().toString()).split("->")
        // toast("FIND_FORM_STEP_IS_FROM_TEXT:"+FIND_FORM_STEP_IS_FROM_TEXT)
    }
})
/*ui.autoloading.click(function(){
    var loading_style = ["｜", "／", "——", "｜", "＼"];
     threads.start(function() {
                    while (true) {
                        // sleep(400);
                        for (let i = 0; i < loading_style.length; i++) {
                            //uu(loading_style[i] + "正在加载..");
                            //loadAdapter.updateButton(loading_style[i] + loadtext)
                            ui.autoloading.setStatus(loading_style[i] +  "正在加载..")
                            sleep(400);
                            print(i)
                        }
                    }
                });*/
    /*ui.autoloading.startLoading(
        new tuiButton.loadAdapter({updateButton:function(t){
           ui.autoloading.setText(t);
    }}),"加载中...");*/
//});

ui.autoloading.setStatus("开始22");
ui.autoloading.on("click", function() {
    threads.start(function(){
      var loading_style = ["｜", "／", "—", "｜", "＼"];
      //loading_style = ["∷", "∵", "∴"]
     // loading_style = ["○●●", "●○●", "●●○"]
      loading_style = ["■", "◆"]
      loading_style = [".", "..","..."]
      loading_style = ["－", "＝","≡"]
        while (true) {
        // sleep(400);
      for (let i = 0; i < loading_style.length; i++) {
            ui.run(()=>{
            //ui.autoloading.setProgress(j)
            ui.autoloading.setText(loading_style[i] + "正在加载..")
        })
        sleep(200)
        //toast("why")
        }
        }
    
})
});


ui.autoloading2.on("click", function() {
    threads.start(function(){
      var loading_style = ["｜", "／", "—", "｜", "＼"];
        while (true) {
        // sleep(400);
      for (let i = 0; i < loading_style.length; i++) {
            ui.run(()=>{
            //ui.autoloading.setProgress(j)
            ui.autoloading2.setText(loading_style[i] + "正在加载..")
        })
        sleep(200)
        //toast("why")
        }
        }
    
})
});

ui.imsobig.on("click", () => {
    toast("我很大，你忍一下")
});