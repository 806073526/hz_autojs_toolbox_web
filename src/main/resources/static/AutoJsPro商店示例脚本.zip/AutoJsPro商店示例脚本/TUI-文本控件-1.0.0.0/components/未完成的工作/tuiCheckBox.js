"ui";
var {
    tuiText,
    tuiButton
} = require('tuiWidget.js');
var tuiCardLayout = (function() {
    //继承至ui.Widget
    util.extend(tuiCardLayout, ui.Widget);
    var stateStyles = "■|□|▧";
    function tuiCardLayout() {
        ui.Widget.call(this);
        //自动保存数据
        this.defineAttr("autoSaveState", (view, attr, value, defineSetter)=>{
          
         });
         //设置文本
         this.defineAttr("text", (view, attr, value, defineSetter)=>{
             view._tui_checkbox_text.setText(value);
         });
         //设置状态: 选中|未选中|禁用
         this.defineAttr("stateStyles", (view, attr, value, defineSetter)=>{
            stateStyles = value.split("|");
             view._tui_checkbox_text.setText(value);
         });
    }
    
    tuiCardLayout.prototype.render = function() {
        return (
           
                <vertical  padding="0 8 0 8" margin="0 0 0 -58">
                        <tui-text id="_tui_checkbox_button" text="√" textSize="20sp" padding="8" textStyle="normal" textColor="#000000" width="150" height="40"/>
                        <tui-text id="_tui_checkbox_text" text="当前环境" textSize="20sp" padding="8" textStyle="normal" textColor="#000000" width="150" height="40"/>
                        
                      
            </vertical>
        );
    }
    ui.registerWidget("tui-card-layout", tuiCardLayout);
    return tuiCardLayout;
})();

ui.layout(
    <vertical>
        <tui-card-layout id="name" cardbg="0xffff00" title="???">
        <vertical background="#99ff00" >
             <tui-text id="deviceinfo" text="hhhhgfffff" textSize="16sp" margin="8" padding="8"/>
                </vertical>
        </tui-card-layout>
                <tui-card-layout id="name" hint="请输入名字">
        <vertical background="#99ff00" padding="0 8 0 58">
             <tui-text id="deviceinfo" text="hhhhgfffff" textSize="16sp" margin="8" padding="8"/>
                </vertical>
        </tui-card-layout>
        <button id="ok" text="确认"/>
    </vertical>
);

ui.ok.on("click", function(){
    toast("名字是：" + ui.name.widget.getInput() + ", 年龄是：" + ui.age.widget.getInput());
});