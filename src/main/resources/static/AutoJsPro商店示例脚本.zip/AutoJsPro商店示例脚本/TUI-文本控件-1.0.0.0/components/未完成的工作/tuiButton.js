/* _____________
 *  tuiButton
 */

tuiButton = {

    that: function() {
        var default_text;
        var on_load_text;
        //调用父类构造函数
        ui.Widget.call(this);
        this.render = function() {
            return (
                <button/>);
        };
        this.onFinishInflation = function(view) {
            view.setTypeface(tf);
        };

        this.onViewCreated = function(view) {
            view.setTypeface(tf);
            view.setProgress = function(progre) {
                    Pro = java.lang.Float.parseFloat(progre);
                    progress = (java.lang.Math.round(Pro * 100)) / 100;

                    this.invalidate();
                },
                view.setStatus = function(text) {
                    statusText = text
                    this.invalidate();
                }
        }

    }
}



util.extend(tuiButton.that, ui.Widget);
module.exports = tuiButton;