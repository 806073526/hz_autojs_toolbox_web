var tuiInput = (function() {
    //继承至ui.Widget

    util.extend(tuiInput, ui.Widget);

    function tuiInput() {
        var pref_key = "@@@@@";
        //调用父类构造函数
        ui.Widget.call(this);
        /*//是否开启自动存储
        this.defineAttr("autoStorage", (view, attr, value, defineSetter)=>{
            if(null!=value && "" != value){
             tuiInput._is_auto_storage = value;
            }else{
             tuiInput._is_auto_storage = false;
            }
         });*/
        this.defineAttr("prefKey", (view, attr, value, defineSetter) => {
            // if(tuiInput.isAutoStorage() && null!=value && "" != value){

            if (null != value && "" != value) {
                this.key = value;
                tuiInput._prefkey = value;
                print(this)
                print("\n__---___\n")
                print(tuiInput)
                print("\n_____\n")
            }
            //print("tuiInput._prefkey:", tuiInput._prefkey)
        });


    }
    tuiInput.prototype.render = function() {
        return (
            <input/>);
    }

    tuiInput.prototype.onFinishInflation = function(view) {
        //设置字体
        view.setTypeface(tf);
        //设置本地数据
        pref_text = "";
        print("创造结束后key:", tuiInput._prefkey)
        print(view.pref_key)
        if (null != tuiInput._prefkey) {
            pref_text = tuiInput.getPref().get(tuiInput._prefkey);
            pref_text = pref_text == null ? "" : pref_text;
            // if (null != pref_text) {
            view.setText(pref_text);
            //设置初始监听,传入一个空的TextWatcher
            // view.addTextChangedListener(new TextWatcher({}));
            tuiInput.addTuiTextChangedListener(view, new TextWatcher({}))
            // }

        }
    }
    /* //是否启动自动本地存储(弃用,设置prefkey属性自动开启)
     tuiInput.isAutoStorage = function() {
         if(!tuiInput._is_auto_storage){
           return false;
         }else{
            return true;
         }
     }*/



    /*
     *  添加监听事件通过addTuiTextChangedListener,而不要使用addTextChangedListener直接设置
     *   通过自定义监听预制了监听数据更改存储本地数据
     */
    tuiInput.addTuiTextChangedListener = function(view, textWatcher) {
        view.addTextChangedListener(new TextWatcher({
            //@Override
            afterTextChanged: function(s) {
                pref_text = s;
                tuiInput.updatePref(view);
                toast(s);
                //FIND_FORM_STEP_IS_FROM_TEXT = (ui.find_step.getText().toString()).split("->")
                textWatcher.afterTextChanged(s);
            },
            beforeTextChanged: function(s, start, count, after) {
                textWatcher.beforeTextChanged(s, start, count, after);
            },
            onTextChanged: function(s, start, before, count) {
                textWatcher.onTextChanged(s, start, before, count);
            }

        }));
    }
    tuiInput.setPref = function(pref) {
        tuiInput._pref = pref;
    }
    tuiInput.getPref = function() {
        if (!tuiInput._pref) {
            tuiInput._pref = storages.create("tuiWidgetDateBase:tuiInput");
        }
        return tuiInput._pref;
    }
    /*
     *用来更新本地数据
     */
    tuiInput.updatePref = function(view) {
        print("更新时key", tuiInput._prefkey)
        tuiInput.getPref().put(tuiInput._prefkey, pref_text)
    }

    ui.registerWidget("tui-input", tuiInput);
    return tuiInput;
})();