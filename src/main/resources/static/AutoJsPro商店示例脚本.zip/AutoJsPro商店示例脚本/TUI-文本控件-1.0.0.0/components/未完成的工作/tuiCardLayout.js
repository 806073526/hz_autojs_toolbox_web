"ui";
var {
    tuiText,
    tuiButton
} = require('tuiWidget.js');
var tuiCardLayout = (function() {
    //继承至ui.Widget
    util.extend(tuiCardLayout, ui.Widget);

    function tuiCardLayout() {
        ui.Widget.call(this);
        this.defineAttr("cardbg", (view, attr, value, defineSetter)=>{
        console.log(value);
        
            // view.setBackgroundColor(value);
             view._tui_card_title.setBackgroundColor(665);
         });
         this.defineAttr("title", (view, attr, value, defineSetter)=>{
             view._tui_card_title.setText(value);
              
         });
         
    }
    
    tuiCardLayout.prototype.render = function() {
        return (
           
                <vertical  padding="0 8 0 8" margin="0 0 0 -58">
                    <linear>
                        <tui-text id="_tui_card_title" text="当前环境" textSize="20sp" padding="8" textStyle="normal" textColor="#000000" width="150" height="40"/>
                        <img w="40" h="40" src="file://res/triangle_shape.png" tint="#88dd00"/>
                    </linear>
                
            </vertical>
        );
    }
    ui.registerWidget("tui-card-layout", tuiCardLayout);
    return tuiCardLayout;
})();

ui.layout(
    <vertical>
        <tui-card-layout id="name" cardbg="0xffff00" title="???">
        <vertical background="#99ff00" >
             <tui-text id="deviceinfo" text="hhhhgfffff" textSize="16sp" margin="8" padding="8"/>
                </vertical>
        </tui-card-layout>
                <tui-card-layout id="name" hint="请输入名字">
        <vertical background="#99ff00" padding="0 8 0 58">
             <tui-text id="deviceinfo" text="hhhhgfffff" textSize="16sp" margin="8" padding="8"/>
                </vertical>
        </tui-card-layout>
        <button id="ok" text="确认"/>
    </vertical>
);

ui.ok.on("click", function(){
    toast("名字是：" + ui.name.widget.getInput() + ", 年龄是：" + ui.age.widget.getInput());
});