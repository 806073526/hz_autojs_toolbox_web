"ui";
/* 组件化
*
*/
//var tf = Typeface.createFromFile(java.io.File(files.path("../../res/Zpix.ttf")));
let tuiText = require("tuiText.js");
let tuiButton = require("tuiButton.js");
const TUIWidget={
    _enable_default_typeface:false,
    typeface:null,
    /*
    *  是否启用默认字体样式
    */
    setEnableTypeface:function(b,tf){
        this._enable_default_typeface = b;
        if(b){
            this.typeface = tf!=null?tf:android.graphics.Typeface.createFromFile(java.io.File(files.path("linux.ttf")));
           tuiText.setTypefaceObj(this.typeface);
        }
        return this;
    },
    isEnableTypeface:function(b){
       return this._enable_default_typeface;
    },
    loadWidgets:function(widgets){
        if(!widgets instanceof Array){return null;}
        for (i in widgets) {
         this._transforLoad(widgets[i]);
        }
    },
    _transforLoad:function(str){
        switch (str) {
            case 'tui-text':
                //tuiText包含自身和ui:that
                ui.registerWidget(str, tuiText.that);
                break;
            case 'tui-button':
                ui.registerWidget(str, tuiButton.that);
                break;
            default:
                // code
        }
    }
    
    
}
TUIWidget.setEnableTypeface(true,null)
         .loadWidgets(["tui-text"]);
         
ui.layout(<vertical><tui-text id="title" text="*TUI-Widget" textSize="30sp" margin="10"  textStyle="bold" gravity="center" layout_gravity="center"/>
            <tui-text  text=">>tui-text:" textSize="20sp" margin="10" color="black" textStyle="bold"/>
                <tui-text id="simple" text="这是一个普通的tui-text"textSize="16sp"/>
                <tui-text  text="这是一个有颜色的tui-text" color="green"textSize="16sp"/>
                <tui-text id="imsobig" text="这是一个加大加粗有颜色有背景有点击事件的tui-text" background="#000000" textSize="26sp" color="red" textStyle="bold"/>
                <tui-text id="colorful" text="这是一个多彩的tui-text"textSize="26sp" />
                <tui-text  text=">>tui-button:"textSize="20sp"margin="10" textStyle="bold"color="black"/>
                </vertical>)
ui.title.setColourfulText([{
        start: 1,
        end: 4,
        color: 0xffffcc00
    },
    {
        start: 5,
        end: 8,
        color: 0xffff0000
    },
    /*{start:6,end:7,color:Color.BLACK},
    {start:7,end:8,color:Color.YELLOW},*/
    {
        start: 8,
        end: 11,
        color: 0xff00aaff
    }
]);
ui.colorful.setColourfulText([{
        start: 1,
        end: 2,
        color: 0xff00ff66
    },
    {
        start: 2,
        end: 3,
        color: 0xffff0000
    },
    {
        start: 3,
        end: 5,
        color: 0xff0022ff
    },
    {
        start: 5,
        end: 8,
        color: 0xffff9900,
        background: 0xff0099ff
    }
]);
