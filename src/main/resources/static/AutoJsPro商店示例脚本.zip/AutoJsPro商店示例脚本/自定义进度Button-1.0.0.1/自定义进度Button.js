"ui";

/*
*author:云熙
*QQ:2058951500
*lastEdit:2021/08/04 9:40
*
*/



(function ProgressButton() {

    importClass(android.graphics.Paint);
    importClass(android.graphics.LinearGradient);
    importClass(android.graphics.Color);
    importClass(android.text.TextUtils);
    importClass(android.graphics.RectF);
    importClass(android.graphics.Shader);
    importClass(android.graphics.Color);
    

    util.extend(ProgressButton, ui.Widget);
    //继承ui.Widget
    function ProgressButton() {

        var blueColor = colors.parseColor("#BB000000")
        var whiteColor = colors.GREEN;
        var textSize = 60 //context.getResources().getDimensionPixelOffset(R.dimen.normal_text_size);
        var paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        var baseLine;
        var rectF;
        var statusText;
        var progress;

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(60);
        paint.setColor(blueColor);


        //调用父类构造函数
        ui.Widget.call(this);

        let p = Paint();
        let path = android.graphics.Path();
        let preX = 0;
        let preY = 0;
        p.setAntiAlias(true);
        p.setTextSize(60);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeCap(Paint.Cap.ROUND);
        this.render = function() {
            return JavaAdapter(android.view.View, {
                onDraw: function(canvas) {
                    this.super$onDraw(canvas)
                    var height = rectF.height();
                    var width = rectF.right;
                    if (height <= 0 || width <= 0) {
                        return;
                    }
                    paint.setShader(null);
                    paint.setColor(blueColor);

                    var radius = height / 2;
                    if (progress == 1) {
                        paint.setStyle(Paint.Style.FILL);
                    } else {
                        paint.setStyle(Paint.Style.STROKE);
                    }
                    canvas.drawRoundRect(rectF, radius, radius, paint);

                    paint.setStyle(Paint.Style.FILL);

                    if (progress > 0 && progress < 1) {
                        //var colorArr = java.lang.reflect.Array.newInstance(java.lang.Integer, 2)
                        var colorArr = util.java.array("int", 2);
                        colorArr[0] = blueColor;
                        colorArr[1] = Color.TRANSPARENT;


                        //var ProArr = java.lang.reflect.Array.newInstance(java.lang.Float, 2)
                        var ProArr = util.java.array("float", 2);
                        
                        ProArr[0] = progress;
                        ProArr[1] = 0;

                        var shader = Shader.TileMode.CLAMP;
                        var progressGradient = new LinearGradient(0, 0, width, 0, colorArr, ProArr, shader) //两种颜色占的比重

                        paint.setShader(progressGradient);
                        canvas.drawRoundRect(rectF, radius, radius, paint);
                        paint.setShader(null);
                    }
                    if (!statusText) {
                        return;
                    }

                    rectF.right = width * progress;
                    var textWidth = paint.measureText(statusText);
                    var textLeft = width / 2 - textWidth / 2;
                    var textRight = width / 2 + textWidth / 2;
                    if (rectF.right >= textRight) { //进度完全覆盖了文字，文字不用计算进度，全部显示白色
                        paint.setColor(whiteColor);
                    } else if (rectF.right > textLeft) { //进度覆盖了文字，但是没有完全覆盖，计算文字进度
                        var extProgress = (rectF.right - textLeft) / textWidth;
                        var colorArr = util.java.array("int", 2);
                        colorArr[0] = blueColor;
                        colorArr[1] = Color.TRANSPARENT;

                        var ProArr = util.java.array("float", 2);
                        ProArr[0] = progress;
                        ProArr[1] = 0;
                        var textGradient = new LinearGradient(textLeft, 0, textRight, 0,
                            colorArr,
                            ProArr,
                            Shader.TileMode.CLAMP);
                        paint.setShader(textGradient);
                    }
                    canvas.drawText(statusText, width / 2, baseLine, paint);
                    rectF.right = width;
                },
                onSizeChanged: function(w, h, oldw, oldh) {
                    this.super$onSizeChanged(w, h, oldw, oldh);

                    rectF = new RectF(1, 1, w - 1, h - 1);
                    var fontMetrics = paint.getFontMetrics();
                    baseLine = h / 2 + (fontMetrics.bottom - fontMetrics.top) / 2 - fontMetrics.bottom;
                },
                setProgress: function(progre) {
                    Pro = java.lang.Float.parseFloat(progre);
                    progress = (java.lang.Math.round(Pro * 100)) / 100;

                    this.invalidate();
                },
                setStatus: function(text) {
                    statusText = text
                    this.invalidate();
                }

            }, activity)

        }

    }


    ui.registerWidget("ProgressButton", ProgressButton);
    return ProgressButton;
})();
oInf = ui.__inflate__
ui.__inflate__ = function(inflateCtx, xml, parent, attachToParent) {
    //    
    if (xml instanceof android.view.View) {
        return xml
        // return oInf(inflateCtx, xml, parent, attachToParent)// 
    }
}
ui.layout(
    <vertical gravity="center">
        <ProgressButton w="100" h="50"id="test"/>
    </vertical>
);

ui.test.setStatus("开始");
ui.test.on("click", function() {
    threads.start(function(){
    
        var j  = 0;
        
        for(let i = 0;i<100;i++){
            j = j+0.01;
            ui.run(()=>{
            ui.test.setProgress(j)
            ui.test.setStatus(i+"%")
        })
        sleep(200)
        }
    
})
});