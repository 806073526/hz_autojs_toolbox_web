<!--
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-12-16 11:29:59
 * @LastEditTime: 2022-12-18 21:31:28
 * @Description: 使用说明
 * 灵感来之不易,积累创造奇迹
-->

# autojs-ui-tool 使用示例

## 作者：抠脚本人

### autojs 中二代 api 里 ui 创建工具,使用 ui.layout 函数风格封装

建议按照:入门示例.mjs --> 进阶示例 --> demo.mjs 的顺序学习使用技巧
