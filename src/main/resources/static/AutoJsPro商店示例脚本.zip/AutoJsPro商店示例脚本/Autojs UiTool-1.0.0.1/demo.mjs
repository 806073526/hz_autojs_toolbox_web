/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-12-14 09:44:09
 * @LastEditTime: 2022-12-18 21:32:10
 * @Description:完整示例,先看另外两个,理解后再看这个
 * 灵感来之不易,积累创造奇迹
 */
"ui";
import "autojs-ui-tool";
import { showToast } from "toast";
//界面中的参数
const uiConfig = {
	title: "界面是用来和用户交互的",
	message: "Android是一种基于Linux的自由及开放源代码的操作系统",
};
//用ui.layout显示界面，提供ui变量，提供初始状态栏状态。还可以多activity，且不同activity能进行交互
let firstActivity = await ui.layout(
	`<column padding="12 0">
        <text text="{{title}}" textStyle="bold" textSize="16sp"/>
        <text maxLines="1" ellipsize="end" text="{{message}}"/>
        <button id="change" text="修改状态栏"/>
        <button id="button" text="切换界面"/>
        <input id="input" text="我是输入框" hint="请输入文本"/>
		<list id="list" h="500"/>
    </column>`,
	{ scope: uiConfig }
);
firstActivity.emitter.on("pause", () => {
	console.log("pause");
});
firstActivity.emitter.on("resume", () => {
	console.log("resume");
});
//根布局的binding
const rootLayout = firstActivity.contentView.binding;
//根布局中id为input的控件
/**@type {import("ui").V8RecyclerView} */
const list = rootLayout.list;
const input = rootLayout.input;
console.log(input);
const listData = [
	{ text: "Hello", enabled: true },
	{ text: "World", enabled: true },
	{ text: "Auto.js", enabled: true },
	{ text: "Pro", enabled: false },
];
list.setItemTemplate(
	`<materialcard w="*" margin="8">
		<column padding="16">
			<row>
				<text text="{{this.text}}" textColor="{{this.enabled ? '#000000' : '#ff0000'}}" layout_weight="1" w="0"/>
				<switch id="enabled" checked="{{this.enabled}}"/>
			</row>
			<button id="delete" text="删除" w="auto" style="Widget.AppCompat.Button.Borderless.Colored"/>
		</column>
	</materialcard>`
);
list.on("item_created", (itemView, holder) => {
	/**@type {android.widget.Switch} */
	const enabledView = itemView.binding.enabled;
	const deleteView = itemView.binding.delete;
	itemView.on("click", () => {
		enabledView.toggle();
	});
	deleteView.on("click", () => {
		listData.splice(holder.position, 1);
		list.getAdapter().notifyItemRemoved(holder.position);
	});
	enabledView.setOnCheckedChangeListener((v, checked) => {
		console.log(`position = ${holder.position}, checked = ${checked}`);
		const data = listData[holder.position];
		if (data.enabled === checked) return;
		data.enabled = checked;
		list.getAdapter().notifyItemChanged(holder.position);
	});
});
list.setDataSource(listData);
rootLayout.change.on("click", () => {
	firstActivity.setStatusBarColor("#01352F");
	firstActivity.setLightStatusBar(false);
});
rootLayout.button.on("click", () => {
	startSecActivity();
});
//启动第二个测试界面
function startSecActivity() {
	//再次调用启动第二个界面
	ui.layout(
		`<column paddingLeft="12" paddingEnd="12">
            <text textStyle="bold" textSize="16sp" text="第二个界面"/>
            <button id="button" text="关闭第一个"/>
            <input id="input" text="3秒后自动关闭" hint="请输入文本"/>
        </column>`
	).then(mActivity => {
		//在layout函数中设置状态栏颜色，则布局显示前生效，也可以加载布局后修改颜色
		mActivity.setStatusBarColor("#01352F");
		//打印所有有效的activity，可以看到有两个
		console.log(ui.aliveActivity);
		mActivity.contentView.findView("button")?.on("click", () => {
			let activityArr = Array.from(ui.aliveActivity);
			//甚至可以关闭第一个activity,第二个界面如果也关了，就没有界面了，软件就退出了
			activityArr[0].finish();
			console.log("基础页面已关闭");
		});
		mActivity.emitter.on("back_pressed", event => {
			//消费返回事件
			/**@type {{consumed:boolean}} */ (event).consumed = true;
			showToast("别急哦,会自动返回");
			console.log("返回", event);
		});
		setTimeout(function () {
			//关闭当前界面
			mActivity.finish();
		}, 3000);
	});
}
