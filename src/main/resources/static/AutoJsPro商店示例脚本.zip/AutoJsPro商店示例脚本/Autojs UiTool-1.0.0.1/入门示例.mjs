/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-12-14 09:44:09
 * @LastEditTime: 2022-12-18 21:30:53
 * @Description:入门示例
 * 灵感来之不易,积累创造奇迹
 */
"ui";
import "autojs-ui-tool";
//用ui.layout显示界面
let firstActivity = await ui.layout(
	`<column padding="12 0">
        <text text="界面是用来和用户交互的" textStyle="bold" textSize="16sp"/>
        <text maxLines="1" ellipsize="end" text="Android是一种基于Linux的自由及开放源代码的操作系统"/>
        <button id="change" text="修改状态栏"/>
        <button id="button" text="我是一个按钮"/>
    </column>`
);
console.log(firstActivity);