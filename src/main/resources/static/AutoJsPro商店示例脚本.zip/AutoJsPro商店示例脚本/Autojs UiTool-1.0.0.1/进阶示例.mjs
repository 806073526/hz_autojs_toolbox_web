/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-12-14 09:44:09
 * @LastEditTime: 2022-12-18 21:30:45
 * @Description:先看入门示例
 * 灵感来之不易,积累创造奇迹
 */
"ui";
import "autojs-ui-tool";
//界面中的参数
const uiConfig = {
	title: "界面是用来和用户交互的",
	message: "Android是一种基于Linux的自由及开放源代码的操作系统",
};
//用ui.layout显示界面，提供ui变量，提供初始状态栏状态
let firstActivity = await ui.layout(
	`<column padding="12 0">
        <text text="{{title}}" textStyle="bold" textSize="16sp"/>
        <text maxLines="1" ellipsize="end" text="{{message}}"/>
        <button id="change" text="修改状态栏"/>
        <button id="button" text="我是一个按钮"/>
		<list id="list" h="500"/>
    </column>`,
	{ scope: uiConfig }
);
//根布局的binding
const rootLayout = firstActivity.contentView.binding;
//根布局中id为input的控件
/**@type {import("ui").V8RecyclerView} */
const list = rootLayout.list;
/**@type {android.widget.EditText} */
const input = rootLayout.input;
console.log(input);
const listData = [
	{ text: "Hello", enabled: true },
	{ text: "World", enabled: true },
	{ text: "Auto.js", enabled: true },
	{ text: "Pro", enabled: false },
];
list.setItemTemplate(
	`<materialcard w="*" margin="8">
		<column padding="16">
			<row>
				<text text="{{this.text}}" textColor="{{this.enabled ? '#000000' : '#ff0000'}}" layout_weight="1" w="0"/>
				<switch id="enabled" checked="{{this.enabled}}"/>
			</row>
			<button id="delete" text="删除" w="auto" style="Widget.AppCompat.Button.Borderless.Colored"/>
		</column>
	</materialcard>`
);
list.on("item_created", (itemView, holder) => {
	/**@type {android.widget.Switch} */
	const enabledView = itemView.binding.enabled;
	const deleteView = itemView.binding.delete;
	itemView.on("click", () => {
		enabledView.toggle();
	});
	deleteView.on("click", () => {
		listData.splice(holder.position, 1);
		list.getAdapter().notifyItemRemoved(holder.position);
	});
	enabledView.setOnCheckedChangeListener((v, checked) => {
		console.log(`position = ${holder.position}, checked = ${checked}`);
		const data = listData[holder.position];
		if (data.enabled === checked) return;
		data.enabled = checked;
		list.getAdapter().notifyItemChanged(holder.position);
	});
});
list.setDataSource(listData);
rootLayout.change.on("click", () => {
	// firstActivity.setStatusBarColor(-16698065);
	firstActivity.setStatusBarColor("#01352F");
	firstActivity.setLightStatusBar(false);
});