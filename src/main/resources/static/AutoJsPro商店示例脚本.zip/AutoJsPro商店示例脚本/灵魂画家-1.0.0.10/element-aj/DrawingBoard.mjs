/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-11-07 11:17:11
 * @LastEditTime: 2022-11-09 13:13:43
 * @Description: 自定义控件画板
 * 灵感来之不易,积累创造奇迹
 */
import { delay } from "lang";
import { install } from "rhino";
install();
const Bitmap = android.graphics.Bitmap;
const Paint = android.graphics.Paint;
const Color = android.graphics.Color;
const MotionEvent = android.view.MotionEvent;
const paint = new Paint();
export function loadDrawingBoard() {
	return $java.defineClass(
		class DrawingBoard extends android.widget.ImageView {
			constructor(...args) {
				super(...args);
				this.preX = 0;
				this.preY = 0;
				paint.setStyle(Paint.Style.STROKE);
				paint.setStrokeWidth(5);
				paint.setColor(Color.BLACK);
			}
			onLayout(changed, left, top, right, bottom) {
				if (changed) {
					//放在onLayout切换成分屏或小窗会清空画布哦
					this.bitmap = Bitmap.createBitmap(right, bottom, Bitmap.Config.ARGB_8888);
					this.canvas = new android.graphics.Canvas(this.bitmap);
				}
			}
			onTouchEvent(event) {
				let x = event.getX();
				let y = event.getY();
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
						this.preX = x;
						this.preY = y;
						break;
					case MotionEvent.ACTION_MOVE:
						this.canvas.drawLine(this.preX, this.preY, x, y, paint);
						this.setImageBitmap(this.bitmap);
						this.preX = x;
						this.preY = y;
						break;
					case MotionEvent.ACTION_UP:
						//可以设计成保存到本地,方便下一次打开恢复画布
						console.log("UP");
						break;
					default:
						break;
				}
				this.invalidate();
				return true;
			}
		},
		{ packageName: "org.drawing" }
	);
}
//设置画笔颜色
export function setColor(color) {
	paint.setColor(color);
}