/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-11-07 10:30:24
 * @LastEditTime: 2022-11-09 01:19:10
 * @Description: 组件库示例，为了便于理解自定义组件，没用到的方法继承没有删
 * 灵感来之不易,积累创造奇迹
 */
import { Widget } from "ui/index";
export class ColoredButton extends Widget {
	//设置类内部参数
	constructor() {
		super();
		this.name = "colored-button";
		this.author = "抠脚本人";
	}
	//初始化参数
	get initialAttributes() {
		return { color: "#2257D0" };
	}
	//设置值访问
	set attr$color(color) {
		this.view.attr("backgroundTint", color);
		this.attrs.color = color;
	}
	//准备空布局,没有任何参数,通过看源码,知道这里不需要super,里面没有其他的操作
	created() {
		// console.log("created");
	}
	//调用render,加载布局加载
	rootViewCreated(view) {
		// console.log("rootViewCreated", view);
		super.rootViewCreated(view);
	}
	//为view设置属性的过程,这里可以结合业务需要,比如利用本地存储为this.attrs赋值
	mount(view) {
		// console.log("mount", view);
		super.mount(view);
	}
	//挂载完成,这里可以注册子view的监听事件,通过看源码,知道这里不需要super,里面没有其他的操作
	didMount(view) {
		// console.log("didMount", view);
	}
	//给初始渲染的布局样板
	render() {
		return `<com.google.android.material.button.MaterialButton textSize="16sp" w="auto"/>`;
	}
	//为继承的类添加的其他方法
	onClick(callback) {
		this.view.on("click", callback);
	}
}
export function registerComponent(component, name = undefined) {
	Widget.register(name ?? component.name, component);
}
