import { registerBroadcastReceiver } from "app";
import { showToast } from "toast";
//会自动注册
const mReceiver = registerBroadcastReceiver("android.intent.action.CONFIGURATION_CHANGED");
//退出时会自动注销监听，很方便
mReceiver.on("receive", intent => {
    showToast("旋转了");
})