// 该模块用于对dev模式打包产生的eval(codestr)进行解压，调试时可以定位代码打包后的代码行，用以解决autojs这种rhino运行js的无法对map文件进行解释

const ConcatSource = require("webpack-sources").ConcatSource;

class Unpack {
    apply(compiler) {
        compiler.hooks.emit.tapAsync("Unpack", (compilation, callback) => {
            compilation.chunks.forEach((chunk) => {
                chunk.files.forEach((file) => {
                    let src = compilation.assets[file].source();
                    src = src.replace(/\neval\(".+?"\);\n/g, (line) => line.replace(/(?<!\\)\\n/g, '\n').replace(/(?<!\\)\\t/g, '\t').replace(/\\"/g, '"').replace(/\\\\/g, '\\').replace(/\neval\("|"\)\n$|\\r/g, ''));
                    compilation.assets[file] = new ConcatSource(src);
                });
            });
            callback();
        });
    }
}
module.exports = Unpack;