const autoConfig = require('./webpack.auto.config')
// const htmlConfig = require('./webpack.html.config')
const reactConfig = require('./webpack.react.config')

module.exports = [
    autoConfig,
    reactConfig
]