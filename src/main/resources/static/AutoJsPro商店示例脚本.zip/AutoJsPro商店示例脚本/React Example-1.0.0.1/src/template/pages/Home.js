import React from 'react';

export default function Home() {
    return (
        <div>
            <span className='title'>Home</span>
        </div>
    );
}