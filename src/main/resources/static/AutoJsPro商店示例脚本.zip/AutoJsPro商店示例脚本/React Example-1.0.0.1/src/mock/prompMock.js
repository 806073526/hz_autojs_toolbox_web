const promptMockData = {
    getSettings: [{
        desc: '无障碍服务',
        name: 'autoService',
        enabled: false,
        type: 'autojs_inner_setting_auto_service',
    }, {
        desc: '截图权限',
        name: 'screenCapturePermission',
        enabled: true,
        type: 'autojs_inner_settings_capture_permission',
    }, {
        desc: '悬浮窗权限',
        name: 'floatyPerminssion',
        enabled: false,
        type: 'autojs_inner_setting_floaty_permission',
    }, {
        desc: '音量上键停止脚本及程序',
        name: 'stop_all_on_volume_up',
        type: 'autojs_inner_setting',
        enabled: false,
    }, {
        desc: '前台服务',
        name: 'foreground_service',
        type: 'autojs_inner_setting',
        enabled: false,
    }, {
        desc: '忽略电池优化',
        name: 'ignoreBatteryOptimization',
        type: 'autojs_inner_setting_power_manage',
        enabled: false,
    }],
    saveSetting: false,
};

// 注入修改prompt
window.promptMock = function (apiName, apiValue) {
    if (promptMockData[apiName] !== undefined) {
        let option = JSON.parse(apiValue);
        let params = null;
        let deviceFn = null;
        if (option.PROMPT_CALLBACK) {
            params = option.params
            deviceFn = option.PROMPT_CALLBACK;
        } else {
            params = option;
        }
        let ret = null;
        if (typeof promptMockData[apiName] === 'function') {
            ret = promptMockData[apiName](apiValue && params);
        } else {
            ret = promptMockData[apiName];
        }
        console.log(`[promptMockData]apiName:${apiName}`);
        console.log(`[promptMockData]apiValue:${JSON.stringify(params)}`);
        console.log(`[promptMockData]returnData:${JSON.stringify(ret)}`);
        if (deviceFn) {
            window[deviceFn](ret);
            AutoWeb.removeDevicelly(deviceFn);
        } else {
            return ret;
        }
    } else {
        throw new Error(`apiName[${apiName}] can not find in promptMock`);
    }
}

export default promptMockData;