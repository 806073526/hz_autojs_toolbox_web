import React from 'react';

export default function People() {
    return (
        <div>
            <span className="title">People</span>
        </div>
    );
}