import home from '@/system/webviewEvents/home';
import settings from '@/system/webviewEvents/settings';

export default function webviewEvents() {
    home();
    settings();
}