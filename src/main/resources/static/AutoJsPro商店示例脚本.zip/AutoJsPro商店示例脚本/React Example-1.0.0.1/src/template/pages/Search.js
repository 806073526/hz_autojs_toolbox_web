import React from 'react';

export default function Search() {
    return (
        <div>
            <span className="title">Search</span>
        </div>
    );
}