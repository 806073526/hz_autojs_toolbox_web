function restart(myEngine) {

    let survive_state = engines.all().find((item) => {

        return item.getSource().toString() == myEngine
    })
    if (survive_state == null) {
        engines.execScriptFile(myEngine, {
            path: engines.myEngine().cwd()
        })
        engines.myEngine().forceStop()
    }
    sleep(30 * 1000)
    survive_state = null
    restart(myEngine)

}
function exec(action, args) {
    args = args || {};
    engines.execScript(action.name, action.name + "(" + JSON.stringify(args) + ");\n" + action.toString());
}
exec(restart, engines.myEngine().getSource().toString());