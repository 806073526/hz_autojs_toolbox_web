function importClass(pack) {
    if (typeof(pack) == "string") {
        var name = pack.split(".").at(-1);
        global[name] = $java.findClass(pack);
        return global[name];
    }
    var name = pack[$java.className].split(".").at(-1);
    global[name] = pack;
    return global[name];
}
global['importClass'] = importClass;

exports.importClass = importClass;