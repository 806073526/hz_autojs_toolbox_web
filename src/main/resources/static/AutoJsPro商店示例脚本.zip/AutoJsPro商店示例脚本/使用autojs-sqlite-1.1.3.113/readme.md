<!--
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-12-16 11:29:59
 * @LastEditTime: 2022-12-18 12:27:25
 * @Description: 使用说明
 * 灵感来之不易,积累创造奇迹
-->

# autojs-sqlite 使用示例

## 作者：抠脚本人

### 仿照 sequelize 风格封装的 autojs 中用的 orm 数据库框架，通过调用安卓的 SQLiteDatabase 封装，以下是使用的例子

#### 导入资源

```javascript
import { DataTypes, SQLite } from "autojs-sqlite";
```

#### 新建名为 test 的 SQLite 数据库对象，并强制同步数据库文件

```javascript
const mSqlite = new SQLite("test", { force: true });
```

#### 通过原生的 SQL 语句创建学生表

```javascript
const Student = mSqlite.rawCreateTable(
	"STUDENT",
	`CREATE TABLE IF NOT EXISTS STUDENT(
		'id' INTEGER PRIMARY KEY AUTOINCREMENT,
		'name' TEXT NOT NULL,
		'age' INTEGER,
		'score' INTEGER
	) `
);
```

#### 使用内置的封装创建教师表

```javascript
const Teacher = mSqlite.createTable("TEACHER", {
	id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true }, //以id为主键，数字类型自动递增
	name: { type: DataTypes.TEXT, notNull: true }, //姓名不能为空
	man: { type: DataTypes.BOOLEAN, defaultValue: 1 }, //布尔值，0为女教师，1为男教师，默认为男教师
	project: { type: DataTypes.TEXT, unique: true }, //将学科作为唯一键，避免重复添加
	age: DataTypes.INTEGER, //年龄为数字类型，可为空
});
```

#### 增加 4 行学生信息

```javascript
Student.insert([
	{ name: "测试1", age: 15, score: 55 },
	{ name: "测试2", age: 16, score: 66 },
	{ name: "测试3", age: 17, score: 77 },
	{ name: "测试4", age: 18, score: 95 },
]);
```

#### 删除 score 低于 60 的学生行

```javascript
console.log(
	Student.delete({
		score: { "<": 60 },
	})
);
```

#### 增加两行教师信息，返回增加的主键 id 数组

```javascript
Teacher.insert([
	{ name: "王老师", age: 45, project: "语文" },
	{ name: "李老师", age: 36, project: "英语" },
]);
```

#### 增加一行教师信息，可以用 insertItem，返回增加的主键 id

```javascript
console.log(Teacher.insertItem({ name: "张老师", age: 45, project: "数学" }));
```

#### 新增一行，由于 project 为唯一键，"数学"重复，返回-1，代表新增数据失败。且控制台会有日志提示

```javascript
console.log(Teacher.insertItem({ name: "赵老师", age: 49, project: "数学" }));
```

#### 第二个参数为 true，代表遇到唯一键时，更新信息，返回更新的主键值

```javascript
console.log(Teacher.insertItem({ name: "赵老师", age: 49, project: "数学" }, true));
```

#### 更新 project 为"数学"教师的 age 为 42

```javascript
console.log("更新行数:", Teacher.update({ age: 42 }, { project: "数学" }));
```

#### 查询 name 不等于"测试 4"，age 大于 15，小于 19 的学生

```javascript
console.log(
	Student.query({
		name: { "!=": "测试4" },
		age: {
			">": 15,
			"<": 19,
		},
	})
);
```

#### 查找 project 为语文的教师

```javascript
console.log(
	Teacher.findOne({
		project: "语文",
	})
);
```

#### 查找主键值为 2 的教师

```javascript
console.log(Teacher.findByPk(2));
```

#### 查找 name 为 "张老师" 的教师

```javascript
console.log(Teacher.query({ name: "张老师" }));
```

#### 使用原始 query 语句查询 name 是"测试 1"的学生

```javascript
let result = mSqlite.rawQuery("SELECT * FROM STUDENT WHERE name = ?", ["测试1"]);
console.log("result:", result);
```

#### 使用原始 sql 语句，执行删除 name 是"测试 1"的学生。注意看安卓文档，原始 sql 命令的适用场景

```javascript
mSqlite.rawSql("DELETE FROM STUDENT WHERE name = ?", ["测试1"]);
```

#### 关闭数据库引用

```javascript
mSqlite.close();
```
