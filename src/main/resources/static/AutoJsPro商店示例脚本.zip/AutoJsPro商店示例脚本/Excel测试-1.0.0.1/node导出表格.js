"nodejs";
const xlsx = require('./xlsx.core.min.js')
const toast = require('toast');
fileName = "./测试成功.xlsx"
let utils = xlsx.utils
let workSheet = utils.aoa_to_sheet(
    [
        ['姓名', '性别', '年龄', '注册时间'],
        ['张三', '男', 18, new Date()],
        ['李四', '女', 22, new Date()]
    ]
)

// let workSheet =
//     utils.json_to_sheet([{
//             '列1': 1,
//             '列2': 2,
//             '列3': 3
//         },
//         {
//             '列1': 4,
//             '列2': 5,
//             '列3': 6
//         }
//     ], {
//         header: ['列1', '列2', '列3'],
//         skipHeader: true // 跳过上面的标题行
//     })
    
// 向工作簿中追加工作表
let workBook = utils.book_new();
utils.book_append_sheet(workBook, workSheet, '注册登记');
xlsx.writeFile(workBook, fileName)
toast.show("生成完成")