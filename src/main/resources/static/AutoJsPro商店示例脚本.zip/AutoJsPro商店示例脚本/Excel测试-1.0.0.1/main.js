"ui";
ui.layout(
    <vertical>
        <button id="生成" w="*" textSize="15dp" paddingTop="10dp" style="Widget.AppCompat.Button.Colored" textColor="White" gravity="center" h="60dp" text="生成" />
    </vertical>
)
ui.生成.on("click", () => {
    if (app.versionCode < 8060000) {
        toast("请升级到auto.js 8.6.0以上版本使用")
        return;
    }
    engines.execScriptFile('./node导出表格.js')
})