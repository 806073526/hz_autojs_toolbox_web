"ui";
ui.statusBarColor(colors="#000000");
ui.layout(    
<frame bg="#faf0e6" layout_gravity="lift|top">
<linear>            
<button id="开" text="开"h="60"w="150"textSize="30px"/>
<button id="关" text="关"h="60"w="150"textSize="30px"/>
</linear>
</frame>
);
/*要打开的文件*/
ui.开.on("click",()=>{
    engines.execScriptFile("./按键控制.js");
    });
ui.关.on("click",()=>{    
    exit();
    });    