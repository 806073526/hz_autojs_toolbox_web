"auto";

events.observeKey();

events.onKeyDown("volume_up", function(event) {
    
    media.playMusic("/sdcard/脚本/派蒙音量提示音/派蒙语音.mp3");
    sleep("6000");
});

events.onKeyDown("volume_down", function(event) {
    media.playMusic("/sdcard/脚本/派蒙音量提示音/派蒙语音.mp3");
    sleep("6000");
});

loop();
