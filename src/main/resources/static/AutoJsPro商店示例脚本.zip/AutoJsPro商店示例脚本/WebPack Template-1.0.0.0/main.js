"nodejs ui";
require('rhino').install()

const ui = require('ui')
const {
    showToast
} = require('toast')

async function main() {
    await ui.loadAndroidResources()
    ui.setMainActivity(MainActivity)
}
main().catch(console.error)

class MainActivity extends ui.Activity {
    get initialStatusBar() {
        return {
            color: this.getColor(ui.R.color.primaryVariant),
            light: false
        }
    }
    // res/layout/activity_main.xml
    get layoutId() {
        return ui.R.layout.activity_main
    }

    constructor() {
        super()
    }

    onCreate(savedInstanceState) {
        this.getTheme().applyStyle(ui.R.style.AppTheme, true)
        super.onCreate(savedInstanceState)
    }

    onContentViewSet(view) {
        this.toolbar = view.findView('toolbar')
        this.setSupportActionBar(this.toolbar)
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true)
        this.toolbar.setNavigationOnClickListener(() => {
            this.finish()
        })
        view.findView('fab').setOnClickListener(view => {
            showToast("Hello AUTOJS")
        })
    }

    onCreateOptionsMenu(menu) {
        this.getMenuInflater().inflate(ui.R.menu.menu_main, menu)
        return true
    }

    onOptionsItemSelected(item) {
        switch (item.getItemId()) {
            case ui.R.id.action_abouts:
                this._showMaterial3Alert("Abouts", "NodeJS UI template using Android resources")
                break
            default:
                return super.onOptionsItemSelected(item)
        }
        return true
    }

    _showMaterial3Alert(title, message) {
        const MaterialAlertDialogBuilder = com.google.android.material.dialog.MaterialAlertDialogBuilder
        new MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}