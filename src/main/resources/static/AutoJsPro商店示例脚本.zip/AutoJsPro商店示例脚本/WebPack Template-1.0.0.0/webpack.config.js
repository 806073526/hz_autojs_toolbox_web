module.exports = {
    mode: "production",
    entry: "./main.js",
    output: {
        filename: "bundle.js",
    },
    target: "node",
    externals: {
        engines: "commonjs engines", 
        shell: "commonjs shell",
        ui: "commonjs ui",
        rhino: "commonjs rhino",
        lang: "commonjs lang",
        toast: "commonjs toast",
    },
};