// 'ui';
//此模块仅支持autojs pro 908以上Rhino引擎使用
//建议使用vs code 编写代码,会有代码提示功能

const FloatMenu = require('./@se7en/float_menu-rhino');

let fm = new FloatMenu();

//修改logoView参数
// let logo = fm.getLogoView();
// logo.setIcons();

let item = fm.addItem('按钮1')
//设置item背景色
item.setColors('#7a0066ff', '#7aff2851');
//设置item图标颜色
item.setTints('#ffffff');
//设置item图标
item.setIcons('ic_play_arrow_black_48dp', 'ic_stop_black_48dp');
//设置按钮样式为 复选框样式
item.setStyle(FloatMenu.STYLE_ITEM_CHECKBOX);
//设置背景样式
item.setRadius(10).setStroke(2, '#000000');
//设置item选中
item.setChecked(true);
item.onClick(function (view) {
    toastLog(`click ${view.name} 是否选中 ${view.checked}`);
    //没有返回值或返回true 保持菜单开启
});

fm.addItem('按钮2')
    .setColors('#3aff2851')
    .setIcons('icon_autojs_logo')
    //设置设置背景圆角
    .setRadius(10)
    //设置描边属性
    .setStroke(2, '#000000');

fm.addItem('按钮3').setIcons('icon_autojs_logo').setColors('#fa99fa');
fm.addItem('按钮4').setIcons('icon_autojs_logo').setColors('#00fafa');
fm.addItem('退出')
    .setIcons('ic_exit_to_app_black_48dp')
    .setColors('#fafa00')
    .onClick(view => {
        fm.close();
        exit();
    });

//监听item点击事件
fm.on('item_click', view => {
    toastLog(`item_click ${view.name} 关闭菜单`);
    //返回false 关闭菜单
    return false;
});

/** 扇形悬浮菜单样式 */
//设置控件与logo间距
fm.config.all_item_gap = 80;
// 设置菜单样式为扇形
fm.setMenuStyle(FloatMenu.TYPE_MENU_CIRCULAR);

//显示悬浮球 自行判断悬浮窗权限
fm.show();



