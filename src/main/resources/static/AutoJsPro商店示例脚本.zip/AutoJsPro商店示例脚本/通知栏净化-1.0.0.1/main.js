events.observeNotification();
events.on("notification", n => n.delete());
setInterval(n => n, 1000);