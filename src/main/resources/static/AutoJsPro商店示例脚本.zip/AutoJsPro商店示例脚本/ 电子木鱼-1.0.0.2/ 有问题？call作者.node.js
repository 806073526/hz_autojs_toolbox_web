const app = require("app");

async function main() {
    if (app.getPackageName("QQ") != null) {
        app.startActivity({
            action: "android.intent.action.VIEW",
            data: "mqqapi://card/show_pslcard?&uin=565947467"
        })
    }
}
main()