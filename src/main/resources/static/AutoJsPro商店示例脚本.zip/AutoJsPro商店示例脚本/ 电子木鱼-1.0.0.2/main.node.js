"ui";
require("rhino").install()
const ui = require("ui");
const media = require("media")
const MediaPlayer=media.MediaPlayer
const mediaPlayer=new MediaPlayer()
/**
 *  作者:唱跳rap打篮球
 *  QQ:565947467  
 *  Date:2022年11月18日
 * */

class MainActivity extends ui.Activity{
    
     get layoutId(){
         return ui.R.layout.activity_main
     }
    
    constructor(){
        super()
        this.arr = ["运气+1","智商-1","颜值+1","功德+1","财运+1","智慧+1","身高+1","体重+1"]
    }
     get initialStatusBar(){
         return {
             color:"#000000",
             light:false
         }
     }
    onCreate(savedInstanceState){
        //this.getTheme().applyStyle(ui.R.style.MyAppTheme,true);
        super.onCreate(savedInstanceState)
    }
    
    onContentViewSet(view){
       
        
        view.findView("img").on("touch",async ()=>{
            await view.findView("textView").setText(this.arr[this._random()])
            await view.findView("textView").attr("visibility","visible")
            let anim =await android.view.animation.AnimationUtils.loadAnimation(this, ui.R.anim.fo);
            await view.findView("img").startAnimation(anim)
            mediaPlayer.play("./music/biu.mp3")
            let sfwe =await android.view.animation.AnimationUtils.loadAnimation(this, ui.R.anim.move);
            await view.findView("textView").startAnimation(sfwe)
            await view.findView("textView").attr("visibility","gone")
        })
    }
    
    _random(){
       const num = Math.random()*(this.arr.length)
       return Math.floor(num)
    }
}

async function main() {
    await ui.loadAndroidResources()
    ui.setMainActivity(MainActivity)
}
main() 