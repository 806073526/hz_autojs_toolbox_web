"ui";
/**
 *  作者:唱跳rap打篮球
 *  QQ:565947467
 * */


let androidx = Packages.androidx;
let ActionBarDrawerToggle = androidx.appcompat.app.ActionBarDrawerToggle;
let MaterialColors = com.google.android.material.color.MaterialColors;

$ui.useAndroidResources();

// 设置自定义主题
activity.theme.applyStyle($ui.R.style.MyAppTheme, true);
// 设置状态栏颜色为主题色
$ui.statusBarColor(MaterialColors.getColor(activity, android.R$attr.colorPrimary, 0));

// 对应文件 res/layout/activity_main.xml
$ui.layoutFile("activity_main");
var arr = ["运气+1","智商-1","颜值+1","功德+1","财运+1","智慧+1","身高+1","体重+1"]
ui.img.on("touch", function() {
    ui.textView.setText(arr[random(0,arr.length-1)])
    ui.textView.attr("visibility","visible")
    anim = android.view.animation.AnimationUtils.loadAnimation(activity, ui.R.anim.fo);
    ui.img.startAnimation(anim);
    media.playMusic("./music/biu.mp3")
    
    sfwe = android.view.animation.AnimationUtils.loadAnimation(activity, ui.R.anim.move);
    ui.textView.startAnimation(sfwe)
    
    ui.textView.attr("visibility","gone")
})  

