import {
    server
} from "./scripts/server.node.mjs"

const start = new server("127.0.0.1", 19132).open()