import http from "http";
import fs from "fs";
import dir from "dir";
import toast from "toast";

export function server(ip, port) {
    this.ip = ip;
    this.port = Number(port);
}

server.prototype.url = function(url) {
    this.url = url;
    
    return this;
}

server.prototype.open = function() {
    const server = http.createServer();
    
    server.on("request", (req, res)=>{
        let url = decodeURI(req.url);
        
        if (url == "/hello") {
            res.end(fs.readFileSync(dir.getPathUrl()+"/web/html/hello.html"));
        }
    })
    
    server.listen(this.port, this.ip);
    
    toast.showToast(`服务端启动${this.ip}:${this.port}`)
}