importClass(Packages.android.graphics.drawable.GradientDrawable);
importClass(Packages.android.graphics.LinearGradient);
importClass(Packages.android.graphics.Shader);
importClass(Packages.android.graphics.Paint);
importClass(Packages.android.graphics.drawable.LayerDrawable);

function dp2px(context, value) {
    if (value <= 0) {
        return 0;
    }
    var density = context.getResources().getDisplayMetrics().density;
    return value * density + 0.5;
}
var orientationMap = {
    top_bottom: android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
    tr_bl: android.graphics.drawable.GradientDrawable.Orientation.TR_BL,
    right_left: android.graphics.drawable.GradientDrawable.Orientation.RIGHT_LEFT,
    br_tl: android.graphics.drawable.GradientDrawable.Orientation.BR_TL,
    bottom_top: android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
    bl_tr: android.graphics.drawable.GradientDrawable.Orientation.BL_TR,
    left_right: android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
    tl_br: android.graphics.drawable.GradientDrawable.Orientation.TL_BR
};

function JsGradientDrawable(context) {
    JsGradientDrawable.context = context;
    JsGradientDrawable.cornerRadius = 0;
    JsGradientDrawable.strokeWidth = 0;
    JsGradientDrawable.strokeColor = -1;
    JsGradientDrawable.strokeDashWidth = 0;
    JsGradientDrawable.strokeDashGap = 0;
    JsGradientDrawable.color = -1;
    JsGradientDrawable.colors = [];
    JsGradientDrawable.orientation = android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM;
    JsGradientDrawable.prototype.setCornerRadius = function(radius) {
        JsGradientDrawable.cornerRadius = dp2px(JsGradientDrawable.context, radius);
        return this;
    }
    JsGradientDrawable.prototype.setStrokeWidth = function(width) {
        JsGradientDrawable.strokeWidth = dp2px(JsGradientDrawable.context, width);
        return this;
    }
    JsGradientDrawable.prototype.setStrokeColor = function(strokeColor) {
        JsGradientDrawable.strokeColor = colors.parseColor(strokeColor);
        return this;
        JsGradientDrawable.prototype.setStrokeDashWidth = function(dashWidth) {
            JsGradientDrawable.strokeDashWidth = dp2px(JsGradientDrawable.context, dashWidth);
            return this;
        }
    }
    JsGradientDrawable.prototype.setStrokeDashGap = function(dashGap) {
        JsGradientDrawable.strokeDashGap = dp2px(JsGradientDrawable.context, dashGap);
        return this;
    }
    JsGradientDrawable.prototype.setColor = function(color) {
        if (color != undefined && !color.equals("")) {
            JsGradientDrawable.color = colors.parseColor(color);
        }
        return this;
    }
    JsGradientDrawable.prototype.setColors = function(colorsVal) {
        colorsVal.forEach(function(c) {
            JsGradientDrawable.colors.push(colors.parseColor(c));
        });
        return this;
    }
    JsGradientDrawable.prototype.setOrientation = function(orientation) {
        var iori = orientationMap[orientation];
        if (iori == undefined) {
            iori = android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM;

        }
        JsGradientDrawable.orientation = iori;
        return this;
    }

    JsGradientDrawable.prototype.into = function(view) {
        view.setBackground(this.getDrawable());
    }

    JsGradientDrawable.prototype.getDrawable = function() {
        var drawable = new GradientDrawable();
        drawable.setCornerRadius(JsGradientDrawable.cornerRadius);
        drawable.setStroke(JsGradientDrawable.strokeWidth, JsGradientDrawable.strokeColor, JsGradientDrawable.strokeDashWidth, JsGradientDrawable.strokeDashGap);
        if (JsGradientDrawable.color != -1) {
            drawable.setColor(JsGradientDrawable.color);
        }
        if (JsGradientDrawable.colors != null && JsGradientDrawable.colors.length > 0) {
            drawable.setColors(JsGradientDrawable.colors);
        }
        drawable.setOrientation(JsGradientDrawable.orientation);
        return drawable;
    }
}

function TextColors() {
    TextColors.colors = [];
    TextColors.prototype.setColors = function(colorsVal) {
        colorsVal.forEach(function(c) {
            TextColors.colors.push(colors.parseColor(c));
        });
        return this;
    }
    TextColors.prototype.into = function(textView) {
        if (TextColors.colors != null && TextColors.colors.length > 0) {
            var mLinearGradient = new LinearGradient(0, 0, textView.getPaint().getTextSize() * textView.getText().toString().length, 0, TextColors.colors, null, Shader.TileMode.CLAMP);
            textView.getPaint().setShader(mLinearGradient);
            textView.invalidate();
        }
    }
}

function JsLinearGradient(context) {
    JsLinearGradient.context = context;
    JsLinearGradient.cornerRadius = 0;
    JsLinearGradient.strokeWidth = 0;
    JsLinearGradient.colors = [];
    JsLinearGradient.background = "#FFFFFF";
    JsLinearGradient.orientation = "top_bottom";
    JsLinearGradient.prototype.setCornerRadius = function(radius) {
        JsLinearGradient.cornerRadius = dp2px(JsLinearGradient.context, radius);
        return this;
    }
    JsLinearGradient.prototype.setStrokeWidth = function(width) {
        JsLinearGradient.strokeWidth = dp2px(JsLinearGradient.context, width);
        return this;
    }
    JsLinearGradient.prototype.setColors = function(colorsVal) {
        colorsVal.forEach(function(c) {
            JsLinearGradient.colors.push(c);
        });
        return this;
    }
    JsLinearGradient.prototype.setOrientation = function(orientation) {
        JsLinearGradient.orientation = orientation;
        return this;
    }
    JsLinearGradient.prototype.setBackground = function(color) {
        JsLinearGradient.background = color;
        return this;
    }
    JsLinearGradient.prototype.into = function(view) {
        var bgDrawable = new JsGradientDrawable(JsLinearGradient.context)
            .setColors(JsLinearGradient.colors)
            .setCornerRadius(JsLinearGradient.cornerRadius)
            .setOrientation(JsLinearGradient.orientation)
            .getDrawable();

        var foreDrawable2 = new JsGradientDrawable(JsLinearGradient.context)
            .setCornerRadius(JsLinearGradient.cornerRadius)
            .setColors(["#FFFFFF", "#FFFFFF"])
            .getDrawable();

        var foreDrawable = new JsGradientDrawable(JsLinearGradient.context)
            .setCornerRadius(JsLinearGradient.cornerRadius)
            .setColor(JsLinearGradient.background)
            .getDrawable();
        var width = JsLinearGradient.strokeWidth;
        var layerDrawable = new LayerDrawable([bgDrawable, foreDrawable2, foreDrawable]);
        layerDrawable.setLayerInset(1, width, width, width, width);
        layerDrawable.setLayerInset(2, width, width, width, width);
        view.setBackground(layerDrawable);
    }
}

var shape = {};

shape.withGradientDrawable = function(context) {
    return new JsGradientDrawable(context);
}

shape.withText = function() {
    return new TextColors();
}
shape.withLinearGradient = function(context) {
    return new JsLinearGradient(context);
}
module.exports = shape;