"ui nodejs";

/*
作者:唱跳rap打篮球 
QQ:565947467

*/

const {select} = require('accessibility')
const EventEmitter = require('events')
const ui = require('ui'); 
const http = require('http');
const fs = require('fs');
const {delay} =require('lang')
const videoPath = './res/autoJsGril.mp4';
const event = new EventEmitter()

http.createServer(async (req, res) => {
    if (req.url == '/') {
        res.writeHead(200, { 'Content-Type': 'text/html', })
        res.write("<meta name='viewport' content='width=device-width, initial-scale=1.0'/>")
        res.end(
            `
            <video src='/video' width='388rem' heigth='750rem' controls='controls'></video>
            `)
    } else if (req.url=='/video') {
        fs.createReadStream(videoPath).pipe(res);

    }   
}).listen(3000,()=>{
    ui.setMainActivity(MainActivity);
    event.emit('Hight')
    
})


class MainActivity extends ui.Activity {

    get layoutXml() {
        return `
        <column>
            <webview id='web'   />
            <text text='欢迎来到 Autojs 美丽乡村大舞台' textSize='22' textStyle='bold'
             textColor='#95d135'  gravity='center'   />
        </column>

        `}

        onContentViewSet(contentView) {
            this.webview = contentView.findView('web');            
            this.webview.loadUrl('http://127.0.0.1:3000');
            event.emit('click')
        }   
        
}



event.on('click',async ()=>{
    setTimeout(function() {process.exit()},22000);
    await delay(850)
    let a = await select({ className:"android.widget.Button" }).atLeast(1).first()
    await a.click()})





