"ui nodejs";
const ui = require('ui');
const getFileForUri = require('./getFileForUri.js');

class TestActivity extends ui.Activity {
    
    get initialStatusBar() {
        return {
            color: '#ffffff',
            light: true
        }
    }

    get ui() {
        return new Proxy(this, {
            get: (target, key) => {
                return this.contentView.findView(key);
            }
        })
    };

    get layoutXml() {
        return `
<vertical>
    <button id="选择" text="选择"/>
    <globalconsole id="console" w="*" h="*"/>
</vertical>
`
    }

    onCreate(savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.ui.选择.on("click", e => {
            this.openImageChooserActivity()
        })
    }

    onActivityResult(requestCode, resultCode, data) {
        if (requestCode == 1) {
            if (resultCode == -1) {
                var uri = data.getData();
                var path = getFileForUri(uri)
                console.log(path);
            }
        }
    }

    openImageChooserActivity() {
        const { android } = require('rhino').Packages;
        const Intent = android.content.Intent;

        var intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        this.startActivityForResult(intent, 1);
    }

}

ui.setMainActivity(TestActivity);

