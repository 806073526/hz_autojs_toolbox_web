"ui";
//hh
importClass(org.autojs.autojs.ui.widget.EWebView);
importClass(android.webkit.CookieManager);
importClass(android.webkit.CookieSyncManager);
importClass(android.webkit.WebViewClient);
$ui.layout(
    <vertical w="*" h="*">
        <org.autojs.autojs.ui.widget.EWebView id="web" />
    </vertical>
);
let sourceFile = "/data/data/org.autojs.autojspro/app_webview_script/Default/Cookies";
let targetFile = "/data/user/0/org.autojs.autojspro/app_webview/Default/Cookies";

let webView = $ui.web.getWebView();
let settings = webView.getSettings();

let mUserAgent = webView.getSettings().getUserAgentString();
let newUserAgent = mUserAgent.replace(/Auto\.jsPro\/Pro\s[\d.-]+/g,
    "Auto.jsPro/Pro 9.3.16-0");
settings.setUseWideViewPort(true);
settings.setLoadWithOverviewMode(true);
settings.setJavaScriptEnabled(true);
settings.setJavaScriptCanOpenWindowsAutomatically(true);
settings.setDomStorageEnabled(true);
settings.setUserAgentString(newUserAgent);
webView.setWebViewClient(new JavaAdapter(WebViewClient, {
    shouldOverrideUrlLoading: function (view, url) {
        log(url.getUrl().toString())
        if (url.getUrl().toString() == "https://pro.autojs.org/"||url.getUrl().toString() == "https://pro.autojs.org/welcome") {
            toastLog("注入cookie", files.copy(sourceFile, targetFile));
        }
        return false;
    }
}));

webView.loadUrl("https://pro.autojs.org/login");