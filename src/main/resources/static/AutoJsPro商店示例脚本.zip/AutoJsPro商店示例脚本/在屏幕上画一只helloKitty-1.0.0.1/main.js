
/*
唱跳rep打篮球
QQ：565947467

遍历一张图片，根据返回的色值在画布上相应的坐标绘制就可实现。下面以画一只hellokitty为例

*/ 


let url= 'https://img.puchedu.cn/uploads/1/253/1668620959/3892715744.jpg'

let img  = images.load(url);

let w = img.getWidth();

let h = img.getHeight();

var window = floaty.rawWindow(
    
    <canvas id = "board"
    h = "{{h}}"
    w = "{{w}}"
    />
    
);

window.setTouchable(false);

window.setPosition(device.width/3, device.height/3);

setInterval(() => {}, 1000)

var paint = new android.graphics.Paint;

paint.setStrokeWidth(1)

paint.setStyle(Paint.Style.STROKE);

paint.setColor(colors.RED);



window.board.on('draw',function(canvas) {
    for(let i = 100; i < w-80; i++){
        for(let j = 10; j < h; j++){
             let num = images.pixel(img, i, j)
            if(num != -1 && num != 0){
             canvas.drawPoint( i, j,paint);  }  //群里I’m zz大佬说用drawImage方法更好，我没试过，大家可以了解一下
        }    }
    img.recycle()
} )
    