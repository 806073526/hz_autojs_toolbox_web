/*

 * @Version: 1.0

 * @Author: Hann1balLecter
 * @Date: 2021-10-20 16:53:27
 * @LastEditors: Hann1balLecter
 * @LastEditTime: 2021-10-20 18:19:47
 * @FilePath: \Code\JavaScript\v0.7\SearchView.js
 * Copyright (C) 2021 Hann1balLecter. All rights reserved.
 */
"ui";
importClass( android.widget.ArrayAdapter );
importClass( android.R );
ui.layout(
    <vertical>
        <SearchView id="search" w="*" h="50" />
        <ListView id="list" />
    </vertical>
);
strArr = [ "唐僧", "孙悟空", "猪八戒", "沙和尚", "白龙马", "白骨精" ];
let adapter = new ArrayAdapter( context, android.R.layout.simple_expandable_list_item_1, strArr );
ui.list.setAdapter( adapter );
ui.list.setTextFilterEnabled( true );//启动过滤
ui.list.setVisibility( 8 );//一开始不显示ListView
ui.search.setIconified( false );
ui.search.setQueryHint( "请输入查询内容..." );//搜索的hint
ui.search.setOnQueryTextListener( {
    onQueryTextChange ( text ) {
        if ( text.length > 0 ) {
            ui.list.setVisibility( 0 );
            // ui.list.setFilterText( text );//设置过滤器
            adapter.getFilter().filter( text );
        } else {
            ui.list.setVisibility( 8 );
            ui.list.clearTextFilter();
        }
        return true;
    }
} );