const FloatyConsole = require('./FloatyConsole.js');
setInterval(() => {}, 1000);

let s = new FloatyConsole();
/*
   悬浮窗有以下事件
   bear-move  窗口拖动时触发，会连续触发很多次
   ok  点击确定或按下回车触发，参数为输入的内容
   close 悬浮窗关闭时
   print 向控制台打印内容时，参数为打印的内容
   print-*  以*向控制台打印内容时，如log
   print-clear  控制台清空时
   show  悬浮窗显示完时
   hide  悬浮窗隐藏完时
*/
s.on('print-clear', function() {
    toast('内容清空了');
});
s.on('ok', function(k) {
    s.log(k);
    toast('点击了确定');
});
s.on('close', function() {
    exit();
});
s.info('作者:selp');
s.info('QQ:201228773');
s.warn('------------');
s.info('提示:长按"确定"两秒可以调整大小')

s.setMaxContent(10); //设置储存条目数，默认100
s.showDate(true); //设置显示时间
s.showSign(true); //设置显示标志
s.setTextSize(12); //设置文字大小
s.log('打印日志');
s.info('打印信息');
s.warn('打印警告');
s.error('打印错误');
s.verbose('打印不重要日志');
//获取日志框内容，-1表示最后一条，0为第一条
s.getContent(-1);

setTimeout(() => {
    s.clear(); //清空
    s.error('两秒后隐藏控制框');
    setTimeout(() => {
        s.hide();//其实是移动到屏幕外
        toast('两秒后显示控制框')
        setTimeout(() => {
            s.show();
            s.warn('两秒后关闭');
            setTimeout(() => s.close(), 2000);
        }, 2000);
    }, 2000)
}, 5000)