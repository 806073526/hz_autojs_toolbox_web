/*
* @Author: 枫慕
* @QQ:766158258
* @versioin: 1.0
* @Date: 2021-02-7 15:43:13
*/
"ui";
var builder = new android.app.AlertDialog.Builder(activity)
builder.setTitle("提示：");
builder.setMessage("是否确定退出程序");
builder.setIcon(drawable_Id("ic_view_list_black_48dp"));
builder.setCancelable(true);

//设置正面按钮
builder.setPositiveButton("加入群聊", new android.content.DialogInterface.OnClickListener({
    onClick: function (dialog, which) {
        dialog.dismiss();


    }
}))
//设置反面按钮
builder.setNegativeButton("确定", new android.content.DialogInterface.OnClickListener({
    onClick: function (dialog, which) {
        dialog.dismiss();


    }
}))
//创建AlertDialog对象
dialog = builder.create();
//显示监听事件
dialog.setOnShowListener(new android.content.DialogInterface.OnShowListener({
    onShow: function (dialog) {
        toast("对话框显示了");

    }
}))
//对话框消失的监听事件
dialog.setOnCancelListener(new android.content.DialogInterface.OnCancelListener({
    onCancel: function (dialog) {
        toast("对话框消失了")
    }
}))
dialog.show();
dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(android.graphics.Color.RED);
dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(android.graphics.Color.BLUE);

function drawable_Id(imageName) {
    var id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
    return id;
}