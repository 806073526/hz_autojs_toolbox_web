class Consts {
    /**
     * 该方法用于存放系统所需常亮以及自定义类型
     */
}

export default Consts