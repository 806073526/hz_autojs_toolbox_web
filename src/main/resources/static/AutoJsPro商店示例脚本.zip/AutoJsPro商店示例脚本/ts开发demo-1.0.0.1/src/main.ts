import { showToast } from 'toast';
import utils from './util/util';

utils.changeScreenState(true);
setTimeout(() => {
    utils.changeScreenState(false);
}, 60000);
