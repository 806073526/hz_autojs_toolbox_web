/*
 * @Author: 抠脚本人
 * @QQ: 742374184
 * @Date: 2022-06-09 20:12:21
 * @LastEditTime: 2022-06-09 21:47:35
 * @Description: 悬浮窗接口
 * 灵感来之不易,积累创造奇迹
 */
let console_floaty = floaty.rawWindow(
	<card cardCornerRadius="10" cardBackgroundColor="#00000000" cardElevation="0">
		<horizontal id="root" gravity="center" padding="10dp" marginBottom="20dp">
			<console id="console" w="*" h="*" />
		</horizontal>
	</card>
);
let console_floaty_options = {
	gravity: "bottom", //位置，可选值:top、bottom 默认值:bottom
	size: "middle", //大小，可选值:small、middle、big 默认值:middle
	alpha: 0.7, //透明度，可选值:0.0-1.0 默认值:0.6
	frontColor: "#00ff00", //文字颜色，可选值:颜色代码 默认值:"#ffffff"
	frontSize: 15, //文字大小，单位sp，可选值:0+ 默认值:16
};
ui.run(() => {
	let scale = 0.25;
	switch (console_floaty_options.size) {
		case "small":
			scale = 0.1;
			break;
		case "big":
			scale = 0.5;
		default:
			break;
	}
	let bg = colors.parseColor("#66000000");
	if (console_floaty_options.alpha < 1 && console_floaty_options.alpha > 0) bg = colors.parseColor("#" + parseInt(console_floaty_options.alpha * 255).toString(16) + "000000");
	console_floaty.setSize(device.width, device.height * scale);
	console_floaty.setPosition(0, console_floaty_options.gravity == "top" ? 0 : device.height * (1 - scale));
	console_floaty.root.setBackgroundColor(bg);
	console_floaty.setTouchable(false);
	console_floaty.console.setConsole(runtime.console);
	console_floaty.console.setColor("D", console_floaty_options.frontColor || "#ffffff");
	console_floaty.console.setTextSize(console_floaty_options.frontSize || 16);
	console_floaty.console.setInputEnabled(false);
});
sleep(500);
console.log("console_floaty_options中配置项均可自定义\n请自行尝试");
sleep(1000);
console.log("模拟脚本开始");
sleep(1000);
console.log("开始第一个操作");
sleep(1000);
console.log("第一个操作结束");
sleep(1000);
console.log("开始第二个操作");
sleep(1000);
console.log("第二个操作结束");
sleep(1000);
console.log("开始第三个操作");
sleep(1000);
console.log("第三个操作结束");
sleep(1000);
console.log("脚本结束");
sleep(1000);
exit();
setInterval(() => {}, 1000);
