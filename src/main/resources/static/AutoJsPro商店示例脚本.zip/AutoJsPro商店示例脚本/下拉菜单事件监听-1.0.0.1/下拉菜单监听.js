"ui";
importClass("android.widget.AdapterView");
ui.layout(
<vertical padding="16">
    <text  text="诚实的年轻人哟！你掉的是什么钥匙呢？"/>
    <spinner id="t1" entries ="银钥匙|金钥匙|铁钥匙|铜钥匙|钢钥匙|我全都要" spinnerMode="dialog"/>
    <horizontal> <text  text="你选择了："/><text  id="t"/></horizontal>
</vertical>
);
let listener = new AdapterView.OnItemSelectedListener({
    onItemSelected: function(parent, view, pos, id) {
      console.log('attached:'+view.attr("text"));
      ui.t.setText(view.attr("text"));
      if(view.attr("text").equals("我全都要"))
        ui.t.setText("贪心可不好");
    },
    onNothingSelected: function(parent) {
      console.log('detached'+pos);
    }
  });
ui.t1.setOnItemSelectedListener(listener);
