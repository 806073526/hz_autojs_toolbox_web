importClass(android.widget.Toast);
importClass(android.view.Gravity);
importClass(android.graphics.Color);
importPackage(android.content);
var mToast = Toast.makeText(context.getApplicationContext(), "toast", Toast.LENGTH_LONG);
var toastView = ui.inflate(
    <vertical bg="#000000">
        <vertical h="160" w="200" >
            <text margin="10 6" text="布局展示" textStyle="italic" textColor="#ffffff" textSize="20" layout_gravity="center|left" gravity="center"></text>
        </vertical>
        <img margin="3 0" id="course" src="@drawable/ic_insert_emoticon_black_48dp" tint="#55deee" w="40" h="40" circle="true"layout_gravity="center" />
        <vertical layout_gravity="center|bottom" gravity="center|bottom" h="auto">
            <text text="显示三秒" bg="?attr/selectableItemBackground" margin="0 0" textStyle="italic" textColor="#ffffff" textSize="16" layout_gravity="center|left" gravity="center"></text>
        </vertical>
    </vertical>
)
mToast.setView(toastView);
mToast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
mToast.show();
setTimeout(function () { mToast.cancel(); }, 3000)