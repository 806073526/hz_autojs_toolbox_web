# Lux Light Meter

## Screenshot

![screen_shot.jpg](./screen_shot.jpg)
