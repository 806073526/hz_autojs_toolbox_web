importPackage(android.content)

function 发送广播(a, b) {
    var i = new Intent(a)
    for (var key in b) {
        i.putExtra(key, b[key])
    }
    context.sendBroadcast(i)
}

function 监听广播(action, event) {
    var b = new BroadcastReceiver({
        onReceive: function(context, intent) {
            var i = intent.getExtras().keySet().iterator()
            var t = {}
            while (i.hasNext()) {
                var n = i.next()
                t[n] = intent.getExtra(n)
            }
            event(context, intent, t)
        }
    })
    context.registerReceiver(b, new IntentFilter(action));
    return b
}

function 销毁广播(b) {
    context.unregisterReceiver(b)
}




//创建广播观察者
var 广播对象 = 监听广播("小明", function(context, intent, data) {
    print(data.消息)
})

//发送广播
发送广播("小明", {
    消息: "你好吖"
})

//脚本结束，销毁广播
events.on("exit", function() {
    销毁广播(广播对象)
});

//保持脚本运行
setInterval(() => {}, 1000);