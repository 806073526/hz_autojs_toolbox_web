"ui";

ui.layout(

    <ScrollView>

    <vertical gravity="center_horizontal">

        <card margin="20">

            <ScrollView h="375" margin="5" bg="#EFEFEF">

                <text id="ts" margin="10" text="可视区域:" textSize="15"/>

            </ScrollView>

        </card>

        <card margin="20 0 20 0" cardCornerRadius="2dp" cardElevation="1dp">

            <vertical>

                <horizontal marginTop="10">

                    <text marginLeft="5" text="请输入第一个IP地址:" textSize="15"/>

                    <input w="*" marginRight="5" text="" hint="例：192.168.0.1" padding="50 0" id="ip1"/>

                </horizontal>

                <horizontal marginTop="10">

                    <text marginLeft="5" text="请于此输入子网掩码:" textSize="15"/>

                    <input w="*" marginRight="5" text="" hint="例：255.255.0.0" padding="50 0" id="zwym"/>

                </horizontal>

                <horizontal marginTop="10">

                    <text marginLeft="5" text="请输入第二个IP地址:" textSize="15"/>

                    <input w="*" marginRight="5" text="" hint="例：192.168.0.1" padding="50 0" id="ip2"/>

                </horizontal>

            </vertical>

        </card>

        <button id="ks" margin="25 35 25 0" w="*" text="开始对比 (计算并输出过程及结果)" bg="#EFEFEF"/>

        <card w="auto" marginTop="25">

            <text id="gy" margin="3" w="auto" text="关于" textSize="14" bg="#F9F9F9"/>

        </card>

    </vertical>

    </ScrollView>

)

//调整所有对话框为自适应前台对话框
$dialogs.setDefaultDialogType("foreground-or-overlay");

if (floaty.checkPermission() == false) {
    app.openAppSetting("com.tencent.lc.ipwdpd");
    toast("请手动开启悬浮窗权限");
}

//定义一个限制数组长度的函数
function 取最小数组(sz1, sz2) {
    if (sz1.length>sz2.length) {
        for(let i = 0, len = sz1.length-sz2.length; i < len; i++) {
            sz1.shift();
        }
    }if (sz1.length<sz2.length) {
        for(let i = 0, len = sz2.length-sz1.length; i < len; i++) {
            sz2.shift();
        }
    }if (sz1.length!=sz2.length) {
        exit();
    }
}

//定义一个逻辑与运算的函数
let 临时文本="";
function 与运算(sz1, sz2) {
    临时文本="";
    for(let i = 0, len = (sz1.length+sz2.length)/2; i < len; i++) {
        if (sz1[i]==1&sz2[i]==1) {
            临时文本=临时文本+"1";
        }else {
            临时文本=临时文本+"0";
        }
    }
}

ui.ks.on("click",()=>{
    //重置可视化窗格内容
    ui.ts.text("可视区域:");
    //判断三个输入框是否为空
    if (ui.ip1.text()!=""&ui.ip2.text()!=""&ui.zwym.text()!="") {
        //最初变量存放输入内容
        let data1=ui.ip1.text();
        let data2=ui.ip2.text();
        let data3=ui.zwym.text();
        //打印与调试
        ui.ts.text(ui.ts.text()+"\n↓↓↓原IP与子网掩码(十进制)↓↓↓\nIP1："+data1+"\nIP2："+data2+"\n子网掩码："+data3);
      //log(data1+"\n"+data2+"\n"+data3);
        //变量存放分割数组，分割符→ .
        let DataArray1=data1.toString().split('.');
        let DataArray2=data2.toString().split('.');
        let DataArray3=data3.toString().split('.');
      //log(DataArray1+"\n"+DataArray2+"\n"+DataArray3);
        if (DataArray1.length==4&DataArray2.length==4&DataArray3.length==4) {
            //定义空数组
            let DataMiddle1=[];
            let DataMiddle2=[];
            let DataMiddle3=[];
            //将分割后的数组成员依次转换为二进制再依次存入空数组中
            for(let i = 0, len = DataArray1.length; i < len; i++) {
                DataMiddle1.push((DataArray1[i]-0).toString(2));
            }for(let i = 0, len = DataArray2.length; i < len; i++) {
                DataMiddle2.push((DataArray2[i]-0).toString(2));
            }for(let i = 0, len = DataArray3.length; i < len; i++) {
                DataMiddle3.push((DataArray3[i]-0).toString(2));
            }
            //打印与调试
            ui.ts.text(ui.ts.text()+"\n\n↓↓↓转换后的IP与子网掩码(二进制)↓↓↓\nIP1："+DataMiddle1+"\nIP2："+DataMiddle2+"\n子网掩码："+DataMiddle3);
          //log(DataMiddle1+"\n"+DataMiddle2+"\n"+DataMiddle3);
            //强迫症……
            let 平均数=(DataArray1.length+DataArray2.length+DataArray3.length)/3;
            //定义空数组
            let DataEnd1_1=[];
            let DataEnd1_2=[];
            let DataEnd1_3=[];
            let DataEnd1_4=[];
            let DataEnd2_1=[];
            let DataEnd2_2=[];
            let DataEnd2_3=[];
            let DataEnd2_4=[];
            let DataEnd3_1=[];
            let DataEnd3_2=[];
            let DataEnd3_3=[];
            let DataEnd3_4=[];
            //额外定义一套空数组
            let DataEnd4_1=[];
            let DataEnd4_2=[];
            let DataEnd4_3=[];
            let DataEnd4_4=[];
            //将每个数组进行再分割，分为四份
            for(let i = 0, len = 平均数; i < len; i++) {
                if (i==0) {
                    DataEnd1_1=DataMiddle1[i].toString().split('');
                    DataEnd2_1=DataMiddle2[i].toString().split('');
                    DataEnd3_1=DataMiddle3[i].toString().split('');
                    DataEnd4_1=DataMiddle3[i].toString().split('');
                }if (i==1) {
                    DataEnd1_2=DataMiddle1[i].toString().split('');
                    DataEnd2_2=DataMiddle2[i].toString().split('');
                    DataEnd3_2=DataMiddle3[i].toString().split('');
                    DataEnd4_2=DataMiddle3[i].toString().split('');
                }if (i==2) {
                    DataEnd1_3=DataMiddle1[i].toString().split('');
                    DataEnd2_3=DataMiddle2[i].toString().split('');
                    DataEnd3_3=DataMiddle3[i].toString().split('');
                    DataEnd4_3=DataMiddle3[i].toString().split('');
                }if (i==3) {
                    DataEnd1_4=DataMiddle1[i].toString().split('');
                    DataEnd2_4=DataMiddle2[i].toString().split('');
                    DataEnd3_4=DataMiddle3[i].toString().split('');
                    DataEnd4_4=DataMiddle3[i].toString().split('');
                }
            }log();
            //对比IP1与子网掩码的数组长度
            取最小数组(DataEnd1_1, DataEnd3_1);
            取最小数组(DataEnd1_2, DataEnd3_2);
            取最小数组(DataEnd1_3, DataEnd3_3);
            取最小数组(DataEnd1_4, DataEnd3_4);
            //对比IP2与子网掩码的数组长度
            取最小数组(DataEnd2_1, DataEnd4_1);
            取最小数组(DataEnd2_2, DataEnd4_2);
            取最小数组(DataEnd2_3, DataEnd4_3);
            取最小数组(DataEnd2_4, DataEnd4_4);
            //定义空文本
            let zz1_1="";
            let zz1_2="";
            let zz1_3="";
            let zz1_4="";
            let zz2_1="";
            let zz2_2="";
            let zz2_3="";
            let zz2_4="";
            //对比IP1与子网掩码的数组结果
            与运算(DataEnd1_1, DataEnd3_1);
            zz1_1=临时文本;
            与运算(DataEnd1_2, DataEnd3_2);
            zz1_2=临时文本;
            与运算(DataEnd1_3, DataEnd3_3);
            zz1_3=临时文本;
            与运算(DataEnd1_4, DataEnd3_4);
            zz1_4=临时文本;
            //对比IP2与子网掩码的数组结果
            与运算(DataEnd2_1, DataEnd4_1);
            zz2_1=临时文本;
            与运算(DataEnd2_2, DataEnd4_2);
            zz2_2=临时文本;
            与运算(DataEnd2_3, DataEnd4_3);
            zz2_3=临时文本;
            与运算(DataEnd2_4, DataEnd4_4);
            zz2_4=临时文本;
            //打印与调试
            ui.ts.text(ui.ts.text()+"\n\n↓↓↓逻辑'与'运算的结果(二进制)↓↓↓\nIP1与子网掩码："+zz1_1+"."+zz1_2+"."+zz1_3+"."+zz1_4+"\nIP2与子网掩码："+zz2_1+"."+zz2_2+"."+zz2_3+"."+zz2_4);
          //log(zz1_1+"."+zz1_2+"."+zz1_3+"."+zz1_4);
          //log(zz2_1+"."+zz2_2+"."+zz2_3+"."+zz2_4);
            //将最终数组进行对比
            if (zz1_1==zz2_1&zz1_2==zz2_2&zz1_3==zz2_3&zz1_4==zz2_4) {
                //打印与调试
                ui.ts.text(ui.ts.text()+"\n\n↓↓↓对比结果↓↓↓\n对比数据一致，IP1与IP2属于同一网段");
                alert("最终结果","同一网段");
            }else {
                //打印与调试
                ui.ts.text(ui.ts.text()+"\n\n↓↓↓对比结果↓↓↓\n对比数据不一致，IP1与IP2属于不同网段");
                alert("最终结果","不同网段");
            }
        }else{
            ui.ts.text("可视区域:");
            alert("温馨提示","请输入正确的IP信息");
        }
    }else {
        ui.ts.text("可视区域:");
        alert("温馨提示","请输入完整的信息");
    }
})

ui.gy.on("click",()=>{
    alert("关于","作者：冷辰 → (非计算机专业の摆烂大学生)\n开发目的：代替重复枯燥没必要的脑力活动\n适用范围：给出两个IP 给出子网掩码 求网段\n思路：\n  1.转二进制\n  2.IP1,IP2分别与子网掩码进行逻辑与运算\n  3.对比结果");
});