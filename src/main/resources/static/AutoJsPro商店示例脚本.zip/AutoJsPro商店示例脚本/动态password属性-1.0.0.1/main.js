/*
 * Author:有人@你
 * QQ: 745884528
*/
"ui";
Data = storages.create("test");
Pwd = Data.get("pwd", true)
importClass(android.text.method.HideReturnsTransformationMethod)
importClass(android.text.method.PasswordTransformationMethod)
ui.layout(
    <vertical paddingLeft="3" paddingRight="3" bg="#000000">
        <relative marginTop="5">
            <text textSize="13sp" textColor="white" text="密码:" layout_alignParentLeft="true" layout_centerInParent="true" margin="10 0 0 0" />
            <input paddingLeft="30" paddingRight="30" textSize="13sp" text="有人@你" id="password" w="*" gravity="center" maxLines="1" textColor="white" layout_alignParentLeft="true" layout_centerInParent="true" password="{{Pwd}}" />
            <img id="hide" w="30" h="30" padding="5" margin="8" tint="#FFFFFF" clickable="true" foreground="?android:attr/selectableItemBackgroundBorderless" src="@drawable/ic_visibility_black_48dp" layout_alignParentRight="true" layout_centerInParent="true" />
        </relative>
    </vertical >
)
ui.hide.click(function () {
    if (Data.get("pwd", true)) {
        ui.password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        Data.put("pwd", false)
    } else {
        ui.password.setTransformationMethod(PasswordTransformationMethod.getInstance());
        Data.put("pwd", true)
    }
})