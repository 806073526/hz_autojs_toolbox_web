// var win0 = floaty.rawWindow(
//   <vertical alpha="0.8" >
//       <text text="作者邮箱：qssyz@qq.com"textSize="20sp"  textColor="#ffff00"id='t'/>
//       <text text="点击展开"textSize="20sp"  textColor="#ffff00"id='t'/>
//       <text text="拖动改变位置"textSize="20sp"  textColor="#ffff00"id='t'/>
//       <text text="长按三秒关闭"textSize="20sp"  textColor="#ffff00"id='t'/>
//   </vertical>
// );
// setTimeout(()=>{
//   win0.close();
// }, 5*1000);
// //悬浮穿透  
// win0.setTouchable(false);
// //悬浮窗起点坐标
// win0.setPosition(device.width/5,device.height/3);
// //时钟死循环
// setInterval(() => {}, 1000);


/**********************************************************************************************************************/
/*
叉 
@drawable/ic_highlight_off_black_48dp

关闭
@drawable/ic_power_settings_new_black_48dp

缩放
@drawable/ic_code_black_48dp

设置
@drawable/ic_settings_black_48dp

开始
@drawable/ic_play_circle_outline_black_48dp

向右 
@drawable/ic_keyboard_arrow_right_black_48dp

笑脸
@drawable/ic_sentiment_satisfied_black_48dp



*/

/**********************************************************************************************************************/

// 
var win = floaty.rawWindow(
    <relative id="win"alpha="0.8">
      <img id="cd_1" layout_gravity="left|top" w="1px" h="1px" src="@drawable/ic_keyboard_arrow_right_black_48dp" />
      <img id="cd_2" layout_gravity="left|top" w="1px" h="1px" src="@drawable/ic_settings_black_48dp" />
      <img id="cd_3" layout_gravity="left|top" w="1px" h="1px" src="@drawable/ic_power_settings_new_black_48dp" />
      <img id="cd_4" layout_gravity="left|top" w="1px" h="1px" src="@drawable/ic_add_circle_black_48dp" />
      <img id="cd_0" layout_gravity="left|top" w="150px" h="150px" tint="yellow" src="@drawable/ic_sentiment_satisfied_black_48dp" />
    </relative>
);


setInterval(() => {}, 100);
win.setPosition(0,0.2*device.height)
win.setSize(150,150)

win.cd_1.setTranslationX(75)
win.cd_2.setTranslationX(75)
win.cd_3.setTranslationX(75)
win.cd_4.setTranslationX(75)
win.cd_1.setTranslationY(75)
win.cd_2.setTranslationY(75)
win.cd_3.setTranslationY(75)
win.cd_4.setTranslationY(75)

/**********************************************************************************************************************/


/**********************************************跟随手指移动************************************************************************/
// win.win.setOnTouchListener(
//   function (view,event){
//     switch (event.getAction()){
//       case event.ACTION_DOWN:
//         x=event.getRawX()
//         y=event.getRawY()
//         windowX=win.getX()
//         windowY=win.getY()
//         return true
//       case event.ACTION_MOVE:
//       //移动手指调整悬浮窗位置
//        win.setPosition(windowX+(event.getRawX()-x),windowY+(event.getRawY()-y))
//     }
   
//     return true

//   }
// )

/**********************************************************************************************************************/

/**********************************************************************************************************************/
var Y=1
win.cd_0.setOnTouchListener(function(view, event) {
  switch (event.getAction()) {
      case event.ACTION_DOWN:
          x = event.getRawX();
          y = event.getRawY();
          windowX = win.getX();
          windowY = win.getY();
          downTime = new Date().getTime();
          return true;
      case event.ACTION_MOVE:
          //移动手指时调整悬浮窗位置
          win.setPosition(windowX+(event.getRawX()-x),windowY+(event.getRawY()-y))
          
          if(Y==1){
            threads.start(function() {
              sleep (200)
              靠近屏幕边缘(win)
            });
          }
          if(new Date().getTime() - downTime > 1000){
          exit();
          }
          return true;
      case event.ACTION_UP:
          //手指弹起时如果偏移很小则判断为点击
          if (Math.abs(event.getRawY() - y) < 5 && Math.abs(event.getRawX() - x) < 5) {
              threads.start(function() {
                
                按钮控制();
              });
          }
          return true;
  }
  return true;
});


/*************************************************控制按钮*********************************************************************/

function 按钮控制(){
  if(Y==1){
    Y=0
    展开()
  }else{
    Y=1
    隐藏()
  }
}
  


/**********************************************************************************************************************/
var x = win.getX();
var y = win.getY();
var w = win.getWidth();
var h = win.getHeight();
log(x)
log(y)
log(w)
log(h)

/******************************************展开和隐藏****************************************************************************/
function 展开(){
  for (let i =0; i <30; i++) {
    i0=(i+1)*5
    // 翻转
    // win.cd_0.setRotationX(c0++)
    // win.cd_0.setRotationY(c0++)
    // 旋转
    win.cd_0.setRotation(2.4*i0)
     //缩放
     win.cd_1.setScaleY(i0)
     win.cd_1.setScaleX(i0)
     win.cd_2.setScaleY(i0)
     win.cd_2.setScaleX(i0)
     win.cd_3.setScaleY(i0)
     win.cd_3.setScaleX(i0)
     win.cd_4.setScaleY(i0)
     win.cd_4.setScaleX(i0)
    // Y轴平移
    win.cd_1.setTranslationY(i0+75)
    win.cd_2.setTranslationY(i0*2+75)
    win.cd_3.setTranslationY(i0*3+75)
    win.cd_4.setTranslationY(i0*4+75)
    win.setSize(150,150+4*i0)
   sleep (0.5)
  }
  var x = win.getX();
  var y = win.getY();
  var w = win.getWidth();
  var h = win.getHeight();
 
}
/**********************************************************************************************************************/
function 隐藏(){
  for (let i = 0; i <30; i++) {
    i0=5*(i+1)
    // 翻转
    // win.cd_0.setRotationX(c0++)
    // win.cd_0.setRotationY(c0++)
    // 旋转
    win.cd_0.setRotation(-2.4*i0)
    // Y轴平移
    win.cd_1.setTranslationY(-i0+75)
    win.cd_2.setTranslationY(-i0*2+75)
    win.cd_3.setTranslationY(-i0*3+75)
    win.cd_4.setTranslationY(-i0*4+75)
  //缩放
    win.cd_1.setScaleY(1-i0/150)
    win.cd_1.setScaleX(1-i0/150)
    win.cd_2.setScaleY(1-i0/150)
    win.cd_2.setScaleX(1-i0/150)
    win.cd_3.setScaleY(1-i0/150)
    win.cd_3.setScaleX(1-i0/150)
    win.cd_4.setScaleY(1-i0/150)
    win.cd_4.setScaleX(1-i0/150)
    win.setSize(150,750-4*i0)
  }
    var x = win.getX();
    var y = win.getY();
    var w = win.getWidth();
    var h = win.getHeight();
}
/**********************************************************************************************************************/


win.cd_1.on("click", () => {
  toast (1)
})
win.cd_2.on("click", () => {
  toast (2)
})
win.cd_3.on("click", () => {
  exit();
})
win.cd_4.on("click", () => {
  toast ("作者邮箱：qssyz@qq.com")
})

function 靠近屏幕边缘(win){
 
  var x=win.getX()
  var y=win.getY()
  var w=win.getWidth()
  var h=win.getHeight()
  var centerX=x+w/2
  var centerY=y+h/2
  threads.start(function() {
  if(centerX>device.width/2 ){
    win.setPosition(device.width-100,y)
  }
  })
threads.start(function() {
  if(centerX<720 )
  {
    win.setPosition(-50,y)
  }
  })


  var x=win.getX()
  var y=win.getY()
  var w=win.getWidth()
  var h=win.getHeight()
  var centerX=x+w/2
  var centerY=y+h/2
  threads.start(function() {
  if(centerY>device.height*7/8){
    win.setPosition(x,device.height*7/8)
  }
  })
  var x=win.getX()
  var y=win.getY()
  var w=win.getWidth()
  var h=win.getHeight()
  var centerX=x+w/2
  var centerY=y+h/2
  threads.start(function() {
  if(centerY<0){
    win.setPosition(x,0)
  }
  })
}
