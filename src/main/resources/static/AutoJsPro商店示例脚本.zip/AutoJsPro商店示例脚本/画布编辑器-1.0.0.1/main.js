"ui";
//开发者 QQ 1105310045
//文本编辑器半成品
//没办法监听输入法
//写内置输入法太麻烦了
//谁能完成监听输入法请联系我有偿
importClass(android.graphics.Typeface); //字体
importClass(java.lang.Character); //分中英文
ui.layout(
    <vertical>
        <horizontal>
            <text id="字"/>
            <button id="删除"text="删除"/>
            <input id="输入框"w="600px"/>
            <button id="写入"text="写入"/>
        </horizontal>
        <canvas id="board" w="*" h="*"/>
    </vertical>
);
dm = ""
threads.start(function() {
    var r = http.get("http://www.baidu.com");
    代码 = r.body.string()
    for (var i = 0; i < 12; i++) {
        代码 += 代码 + "\n"
    }
    dm = 代码.split("> <");
    toastLog(dm.length+"行")
})
//画笔
字位置 = 0
删位x = 0
横行 = 0
删行y = 0 //可以设置跳转行数
屏幕X = 0
屏幕Y = 0
坐标差x = 0
坐标差y = 0
画布x = 160
画布y = -(70 * 删行y)
按压时间 = 0
光标坐标 = [画布x, 70]
光标时间 = 0
行号 = 1
画布开关 = true
var paint = new Paint();
paint.setStrokeWidth(1);
var paint1 = new Paint(); //画光标
paint1.setStrokeWidth(5);
paint.setTextSize(50); //字体大小
paint.setTypeface(Typeface.MONOSPACE); //字体样式
ui.board.on("draw", function(canvas) {
    if (dm && 画布开关) {
        try {
            canvas.drawColor(-14868703);
            画代码和行号(canvas)
            画光标(canvas)
            //paint.setARGB(255,229,54,49)
            //canvas.drawText(删位x + " " + 字位置 + " " + Math.floor(删位x), 100, 50, paint);
        } catch (e) {
            log("报错了" + e)
        }
    }

});
ui.board.setOnTouchListener(function(view, event) {
    switch (event.getAction()) {
        case event.ACTION_DOWN:
            屏幕X = event.getX();
            屏幕Y = event.getY();
            按压时间 = 0
            zwz = 字位置
            gbzb = 光标坐标[0]
            hh = 行号
            return true;
        case event.ACTION_MOVE:
            移动a = event.getX();
            移动b = event.getY();
            坐标差x = 移动a - 屏幕X
            坐标差y = 移动b - 屏幕Y
            if (坐标差x > 15 || 坐标差x < -15 || 坐标差y > 15 || 坐标差y < -15) {
                画布x += 坐标差x * 1.3
                if (画布x > 160) {
                    画布x = 160
                }
                画布y += 坐标差y * 1.3
                if (画布y * 1.3 > 30) {
                    画布y = 0
                }
                屏幕X = 移动a
                屏幕Y = 移动b
            }
            按压时间++
            return true;
        case event.ACTION_UP:
            屏幕X = event.getX();
            屏幕Y = event.getY();
            删行y = Math.floor((Math.abs(画布y)) / 70)
            if (删行y > 40) {
                删行y -= 30
            } else {
                删行y = 0
            }
            行号 = Math.floor((Math.abs(画布y - 70) + 屏幕Y) / 70)
            光标坐标[1] = 行号 * 70
            计算横行光标()

            return true;
    }
    return true;
});

function 画代码和行号(canvas) {
    paint.setARGB(255, 197, 200, 198)
    for (let i = 1 + 删行y; i < 100 + 删行y; i++) {
        if (i > dm.length - 1) {
            break;
        }
        //画代码
        字宽 = 画布x
        for (let l = 0; l < dm[i - 1].length; l++) {

            if (字宽 > 1600) {
                break;
            }
            if (分中英文(dm[i - 1][l])) {
                if (字宽 > 160 - 10) {
                    canvas.drawText(dm[i - 1][l], 字宽, 画布y + i * 70, paint);
                }
                字宽 += 50
            } else {
                if (字宽 > 160 - 10) {
                    canvas.drawText(dm[i - 1][l], 字宽, 画布y + i * 70, paint);
                }
                字宽 += 30
            }
        }
        //画线
        canvas.drawLine(0, 画布y + i * 70 + 10, 3000, 画布y + i * 70 + 10, paint);
    }
    //行号背景颜色
    paint.setARGB(255, 37, 40, 44)
    canvas.drawRect(0, 0, 160, canvas.getHeight(), paint);
    paint.setARGB(255, 198, 200, 199)
    for (let i = 1 + 删行y; i < 100 + 删行y; i++) {
        if (i > dm.length - 1) {
            break;
        }
        //画行号
        canvas.drawText(i, 10, 画布y + i * 70, paint);
    }
}

function 画光标(canvas) {
    if (行号 + 1 > dm.length) {
        return
    }
    if (光标坐标[0] < 160) {
        return
    }
    paint1.setARGB(255, 198, 200, 199)
    //画光标
    if (光标时间 > 14) {
        canvas.drawLine(光标坐标[0], 画布y + 光标坐标[1] - 40, 光标坐标[0], 画布y + 光标坐标[1] + 5, paint1);
        if (光标时间 == 28) {
            光标时间 = 0
        }
    }
    光标时间++
    //选择行颜色
    paint.setARGB(50, 255, 255, 255)
    canvas.drawRect(0, 画布y + 光标坐标[1] - 60, 3000, 画布y + 光标坐标[1] + 10, paint);
}

function 计算横行光标() {
    if (行号 > dm.length) {
        return
    }
    删位x = Math.floor(Math.abs(画布x - 160))
    let 横行 = 160
    for (let i = 0; i < dm[行号 - 1].length; i++) {
        if (分中英文(dm[行号 - 1][i])) {
            横行 += 50
        } else {
            横行 += 30
        }
        if (横行 > 删位x + 屏幕X) {

            if (分中英文(dm[行号 - 1][i])) {
                横行 -= 50
            } else {
                横行 -= 30
            }

            光标坐标[0] = 横行 - 删位x
            字位置 = i
            ui.字.setText(dm[行号 - 1][字位置])
            return
        }
    }

    字位置 = dm[行号 - 1].length
    光标坐标[0] = 横行 - 删位x
}
ui.写入.click(() => {
    let s = ui.输入框.text()
    if (!s) {
        return
    }
    画布开关 = false
    dmx = dm
    if (s.includes("\n")) {
        let 行数 = 行号 - 1
        if (行数 < 0) {
            行数 = 0
        }
        if (字位置) {
            前段 = dmx[行数].slice(0, 字位置)
        } else {
            前段 = ""
        }
        log(dmx[行数], 行数)
        //exit()
        let 内容 = 前段 + s + dmx[行数].slice(字位置)
        let 数组 = 内容.split("\n")
        log(dmx)
        for (let i = 0; i < 数组.length; i++) {
            dmx.splice(i + 行数, 0, 数组[i]);
        }
        dmx.splice(行数 + 数组.length, 1);
        log(dmx)
    } else {
        if (字位置) {
            前段 = dmx[行号 - 1].slice(0, 字位置)
        } else {
            前段 = ""
        }
        dmx[行号 - 1] = 前段 + s + dmx[行号 - 1].slice(字位置)
        for (var i = 0; i < s.length; i++) {
            if (分中英文(s[i])) {
                光标坐标[0] += 50
            } else {
                光标坐标[0] += 30
            }
        }
        字位置 += s.length
    }
    ui.输入框.setText("")
    dm = dmx
    画布开关 = true
})
ui.删除.click(() => {
    let 长度 = dm[行号 - 1].length
    if (长度 == 1) {
        dm[行号 - 1] = ""
        字位置 = 0
        if (分中英文(dm[行号 - 1])) {
            光标坐标[0] -= 50
            //画布x+=50
        } else {
            光标坐标[0] -= 30
            //画布x+=30
        }
        return
    }
    if (字位置 > 0) {
        if (分中英文(dm[行号 - 1][字位置 - 1])) {
            光标坐标[0] -= 50
            //画布x+=50
        } else {
            光标坐标[0] -= 30
            //画布x+=30
        }
        dm[行号 - 1] = dm[行号 - 1].slice(0, 字位置 - 1) + dm[行号 - 1].slice(字位置)
        字位置--
    }

})

function 分中英文(c) {
    let ub = "1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM,.()/=,;{}[]<>-+|:_*%\\#$&!?^ " + "'" + '"'
    if (ub.includes(c)) {
        return false;
    }
    return true;

}