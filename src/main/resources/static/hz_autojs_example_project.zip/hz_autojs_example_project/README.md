# 华仔AutoJs图色脚本示例项目

1、项目集成utils.js必要的依赖引入以及配置

```
// 等待无障碍服务开启
auto.waitFor()

if (!$floaty.checkPermission()) {
    // 没有悬浮窗权限，提示用户并跳转请求
    toast("本脚本需要悬浮窗权限来显示悬浮窗，请在随后的界面中允许并重新运行本脚本。");
    $floaty.requestPermission();
}

// 配置类
let config = require("./common/config.js")
// 工具类
let utils = require("./common/utils.js")
// 公共储存对象
var commonStorage = storages.create("zjh336.cn" + config.commonScriptKey);
// 业务储存对象
var serviceStorage = storages.create("zjh336.cn" + config.serviceScriptKey);

// 不同品牌申请截图权限的文字描述不一样 可在这里修改
let 截图允许点击文字 = "允许";

// 点击立即开始
threads.start(function() {
    while (true) {
        let 立即开始 = text("立即开始").findOne(1000);
        if (立即开始) {
            立即开始.click();
        }
        let 点击文字 = text(截图允许点击文字).findOne(1000);
        if (点击文字) {
            点击文字.click();
        }
    }
});
sleep(1000)
// 请求截图权限
try {
    images.stopScreenCapture()
    images.requestScreenCapture()
} catch (error) {
    console.error("请求截图错误", error)
}

// 初始化文字识别插件
let 文字识别插件 = commonStorage.get("文字识别插件") || "谷歌"
utils.initOcr(文字识别插件)


// 开启调试模式 找图、找色、识字绘制效果
commonStorage.put("debugModel", true)

// 开启调试模式 绘制延时
commonStorage.put("debugSleep", 500)
```

2、示例代码调用，详情见main.js中代码

```

let 官方api = {};

官方api.灰度化grayscale = () => {
    let img = captureScreen();
    let afterImg = images.grayscale(img);
    utils.recycleNull(img);
    let newFilepath = "/sdcard/autoJsTools/imageHandlerAfter.png";
    files.createWithDirs("/sdcard/autoJsTools/");
    files.remove(newFilepath);
    images.save(afterImg, newFilepath);
    toastLog("图片已存入本地:" + newFilepath)
    sleep(500);
    app.viewFile(newFilepath);
    utils.recycleNull(afterImg);
    utils.textFindOneClick("仅此一次", 2000);
}

let 进阶api = {};
进阶api.区域找图点击regionalClickImg2 = () => {
    let img = captureScreen();
    // 可自行换个能找到的小图
    let targetImg = images.read(targetImgPath);
    /**
     * 灰度化、阈值化 区域点击图片2
     * @desc 在大图的区域坐标范围内,进行灰度化阈值化处理后 再进行区域找图 寻找与目标图片匹配的坐标位置 再点击坐标
     * @param {Image} img 大图对象(一般为截全屏的图片对象)
     * @param {int} x1 区域坐标x1 
     * @param {int} y1 区域坐标y1
     * @param {int} x2 区域坐标x2
     * @param {int} y2 区域坐标y2
     * @param {int} threshold 阈值化相似度
     * @param {int} maxVal 阈值化最大值
     * @param {String} matchingImgPath 匹配图片路径
     * @param {String} imgThreshold 图片相似度
     * @param {boolean} isOpenGray 是否开启灰度化
     * @param {boolean} isOpenThreshold 是否开启阈值化
     * @param {Function} successCall 成功回调
     */
    utils.regionalClickImg2(img, 28, 1013, 1053, 1596, 60, 255, tempImgPath, 0.7, false, false, () => {
        toastLog("找到图片")
    });
    utils.recycleNull(img);
}
```

参考测试方法中的调用，如灰度化测试的使用代码

```
let img = captureScreen();
    let afterImg = images.grayscale(img);
    utils.recycleNull(img);
    let newFilepath = "/sdcard/autoJsTools/imageHandlerAfter.png";
    files.createWithDirs("/sdcard/autoJsTools/");
    files.remove(newFilepath);
    images.save(afterImg, newFilepath);
    toastLog("图片已存入本地:" + newFilepath)
    sleep(500);
    app.viewFile(newFilepath);
    utils.recycleNull(afterImg);
    utils.textFindOneClick("仅此一次", 2000);
```

使用之前，必须先按照第一步引入必要文件

进行参数设置和初始化操作

3、api演示功能

运行项目后左上角显示，示例演示按钮

点击按钮，弹出操作选择

![image-20230526150838523](./image-20230526150838523.png)

找图api代码中有小图路径，可本机截取后存放sdcard目录，在设置小图路径中输入对应路径，即可在找图测试时，使用自定义的图片

​		可在选择官方api、基础api、进阶api后，再进行具体的api选择

![image-20230526151133271](./image-20230526151133271.png)

![image-20230526151204527](./image-20230526151204527.png)

![image-20230526151232960](./image-20230526151232960.png)