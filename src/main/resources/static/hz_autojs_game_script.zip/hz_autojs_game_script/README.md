# 华仔AutoJs游戏脚本脚手架

华仔AutoJs游戏脚本脚手架，快速产出游戏脚本
[简单使用教程，请看文档](https://gitee.com/zjh336/hz_autojs_game_script/wikis/pages)

[实战视频教程-哔哩哔哩](https://space.bilibili.com/69729485/channel/collectiondetail?sid=999283&ctype=0)

![输入图片说明](%E8%B5%9E%E8%B5%8F.png)