//
// Created by Sean Zhou on 11/13/18.
//

#ifndef DROIDCAST_STRING_UTIL_H
#define DROIDCAST_STRING_UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#endif //DROIDCAST_STRING_UTIL_H

char* filter_apk_path(char* result);