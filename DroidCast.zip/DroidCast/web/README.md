# WebSocket test

After [setting up the tool properly](../README.md#quick-start), you could also view the synchronous screenshot
with `image.html` as the connected device gets rotated.
